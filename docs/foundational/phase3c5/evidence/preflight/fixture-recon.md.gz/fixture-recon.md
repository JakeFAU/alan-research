# Phase 3C.5 executable design reconnaissance

Status: scratch design evidence, not qualification, not an independent formal proof, not a runtime result. No repository files were edited. The proposed monitor pair works as a strict coarsening witness, but its core K/D family is entirely blocking. A same-size variant supplies productive and blocking examples in both context families, but a later focused check shows its strict language differences are disabled by the actual plant. Prefer the original if legal-plant relevance is the research objective; keep its blocked K/D outcomes visible.

## Inputs and explicit reuse

Read `00-contract.md`, `01-argument.md`, `02-evidence-schema.md` and `tools/audit.py` in `docs/foundational/phase3c4/`. Decoded only descriptors from `docs/foundational/phase3c4/evidence/task1/export.json.gz`; compressed SHA256 `35115c3104cddd8a789c80a8c0e73eb7c7f173632af512776ba8502b61b9afc9`, raw SHA256 `b40f1d5ac0aea0f43999502ea318cb128f545eb8fb1fd129451915a5aa84bf1f`. Both pins were asserted. Old verdict/count/product fields were not the operational oracle. Imported Phase 3C.4 `Automaton`, `subsets`, `product` and prior descriptor constructors. These transitively import Phase 3C.3 and 3C.2 utilities; exact Python hashes appear in raw output. Thus the scratch inclusion/reduction logic is new but shares predecessor graph mechanics. This is useful design reconnaissance, not an independently implemented auditor.

No old audit main, campaign, Go suite, runtime, or SQLite was executed. Complete scratch products were reconstructed from the 72 K, 324 D and seven old plus two new M descriptors.

## Original proposal

Let r=reserve-capacity:AB, a=apply:AB, c=commit:BC; O is the other five labels, with a self-loop at every state. All states marked. Original M has initial 0, states 0..3, 0-tau->1, each r/a/c from0->3, 1-r->2, 2-a->3, r/a/c loops at3. N adds4,0-tau->4,4-r->2,4-c->3.

Exact complete subset searches confirm L1 strictly contained in L4 strictly contained in L0. Shortest differences: L4 minus L1 contains c (length1); L0 minus L4 contains a (length1). Full profiles differ at epsilon; MIN and MAX profiles agree at all words (complete five-label-independent/eight-label subset graph has three nodes). Initial marked languages agree.

For each of M and N: 52/72 K contexts nonblocking,20 blocking; all324 core K/D contexts blocking. Productive example `early/shared-1/mask2`; blocking example core `early/shared-1/mask0`, whose initial state can complete but one reachable residual cannot. Thus original pair is not wholly degenerate across the396-context roster, but it cannot demonstrate productive substitution in K/D. The first scratch run deliberately asserted productive/blocking instances in EACH family and failed at that assertion. It was retained as `fixture_recon_attempt1.py`; the observed traceback was `AssertionError` at line91, `assert all(examples[k]['NonblockingCount']>0 and examples[k]['BlockingCount']>0 for k in examples)`. Subsequent original probe retains outcomes rather than hiding this failure.

## Alternative fixture, same state counts; legal-trace limitation below

M: states0,1,2,3; initial0; all marked; O self-loops everywhere. Additional edges, in proposed deterministic order:

- 0-tau->1
- 0-r->2
- 0-a->2
- 0-a->3
- 1-r->2
- 2-a->3
- r/a/c self-loops at3

N adds marked state4 with O loops,0-tau->4,4-r->2,4-a->2. Unlisted r/a/c edges absent.

L1 strictly contained in L4 strictly contained in L0. Shortest reverse-inclusion counterwords are a for L4 minus L1 and a r for L0 minus L4. Each compared proper-inclusion subset graph has six nodes. Full profiles mismatch at epsilon (N has intermediate language L4); initial marked languages and MIN profiles are equal. Full/MIN/MAX complete profile graphs each have five subset pairs, including empty subsets and every alphabet arc. The extra branch produces only pre-existing reach states after the first B event. For epsilon or O-only prefixes the new language is strictly above L1 and therefore removed by MIN.

For EACH M and N:60 K nonblocking,12 K blocking;72 K/D nonblocking,252 K/D blocking. Core K is nonblocking. Productive K/D example `early/shared-1/mask0 || D-04-1`; blocking K/D example `early/shared-1/mask0 || D-00-0`. The latter has no marked completion. Blocking K example `stable-ready/shared-1/mask0` also lacks initial completion. These are finite descriptor outcomes, not unrestricted contexts. Complete selected graphs are retained for four M examples; summaries retain all products.

Predicted relation classes for the strengthened nine-monitor roster:

- Initial language: {free}, {commit-first}, {release-first,release-first-tau,release-first-doomed,release-first-duplicate,release-first-loop}, {M,N}.11 equal unordered pairs.
- FULL: singleton free,commit-first,doomed,M,N, plus {release-first,release-first-tau,release-first-duplicate,release-first-loop}.6 equal pairs.
- MIN: same FULL grouping except {M,N}.7 equal pairs.
- MAX: same as initial-language partition.11 equal pairs.
- J=(initial language,MIN): same as MIN on this roster.7 equal pairs. Equality here was checked for every MIN-equal pair via independent initial-state inclusion decisions; it is not assumed for arbitrary generic automata.

Predicted totals:3564products,38072states,47408arcs,18634CanComplete states,1150initially completable products,920nonblocking products.2772MIN/J substitution rows:924both nonblocking and1848both blocking. All counts are scratch predictions; producer and auditor qualification must compute their own counts. Original-fixture predictions are retained separately in the original raw output.

## MAX negative and generic information-loss controls

Release-first/doomed MAX profiles equal on their complete four-node subset-pair graph, whereas FULL/MIN first mismatch at r. The doomed residual state's O* language is properly contained in healthy state1 language: inclusion holds; shortest reverse witness is a. Exact pair graph has three nodes. Core RF is nonblocking; core doomed is blocking despite both initially completable. Therefore MAX and the pair (initial language,MAX) fail to preserve nonblocking.

Generic MIN-only negative requested by controller: X has marked initial0 with every visible self-loop, tau to unmarked1 with every visible self-loop. Y has unmarked initial0 with every visible self-loop. Complete MIN profiles equal ({empty language}) at all words, but X's initial language is Sigma* and Y's is empty; epsilon is shortest separator. J distinguishes them. These generic monitors are not in the all-marked roster.

The old unmarked X(no edges)/Y(one a edge) control remains J-unequal: equal empty initial languages, but empty profile versus {empty language} after a. Both always block in any pointed conjunctive-mark context because no product state can mark. This retains the distinction between a local reduced-profile separator and a global contextual nonblocking separator.

## Local test controls and certificate recommendations

Checked finite families F={{a},{r}}, targetK={c}. No singleton word set can hit both source languages; H={a,r} hits each source and misses K. Constructed finite marked tries for H and all three residual languages, then reconstructed synchronous products: initial CanComplete results true,true,false. These are INITIAL existential hit tests; do not reinterpret the trie checks as whole-product nonblocking separators. Removing either H leaf makes one source miss. Additional exact finite-set controls cover epsilon, emptyfamily, emptylanguage, equality, proper inclusion, and equal duplicates. A failed coverage certificate with empty source family uses H=[]; an empty-language member is covered by every target and permits no failed-coverage hit witness.

Recommended complete inclusion certificate: bind both automata/start states; retain the entire epsilon-closed subset-pair BFS graph with every alphabet arc; per-node left/right acceptance; separate LeftSubsetRight and RightSubsetLeft booleans with first shortest directional counterwords. Empty counterword epsilon MUST be distinguishable from absent counterword (null or explicit boolean). Inclusion fails only at left-accept/right-reject, not every acceptance disagreement. Reverse direction has its own shortest witness. Equality requires both inclusions.

MIN/MAX require within-automaton residual comparisons as well as cross-automaton comparisons. Collapse equivalent languages before strict filtering; deterministic representative is lowest declared/sorted state ID. Retain the representative class membership, full inclusion relation indices, retained representatives and witness dominators for every removed representative. For MIN discarded L needs retained K proper-subset L; MAX reverses orientation. Every retained candidate must be verified undominated, and every reach-state must map to exactly one equality class. Retain unreachable declared residual states in the global comparison roster but reduce only the reached states per profile node.

At every profile node preserve original reached subsets, class/min/max representatives, complete bidirectional coverage, and all alphabet arcs even after mismatch. Distinguish no reached states from a reached empty-language class. For a failed local coverage target K, provide one directional shortest word in L minus K for EACH source language representative, a deduplicated H, exact acceptance checks for each witness, and trie initial-hit checks if used. A single suffix is insufficient in general. Declare orientation explicitly: target K is uncovered iff no source L is included in K. Failed coverage is a local-hit implication witness, not automatically a global context. Preserve FULL comparisons separately to demonstrate strictness.

## Commands and artifacts

Executed from repository root (absolute scratch output locations):

```
python3 /tmp/alan-phase3c5/fixture_recon.py > /tmp/alan-phase3c5/fixture-recon-stdout.json 2> /tmp/alan-phase3c5/fixture-recon-stderr.txt
python3 /tmp/alan-phase3c5/fixture_recon_variant.py > /tmp/alan-phase3c5/fixture-recon-variant-stdout.json 2> /tmp/alan-phase3c5/fixture-recon-variant-stderr.txt
python3 /tmp/alan-phase3c5/generic_recon.py > /tmp/alan-phase3c5/generic-recon-stdout.json 2> /tmp/alan-phase3c5/generic-recon-stderr.txt
python3 /tmp/alan-phase3c5/extra_inclusion_probe.py > /tmp/alan-phase3c5/extra-inclusion-stdout.json 2> /tmp/alan-phase3c5/extra-inclusion-stderr.txt
```

These final commands all exited0. First stricter original-fixture attempt exited1 as described above; source preserved. Source/probe outputs are all in this directory. `fixture-recon-output.json` and `fixture-recon-variant-output.json` contain human-readable summaries, input pins, reused Python hashes, classes, counts and examples. Corresponding `*-certificates.json.gz` retain complete FULL/MIN/MAX profile subset graphs, proper inclusion graphs, all product summaries, four selected product graphs, and exact fixture descriptors. `generic-recon-output.json` retains full generic/trie certificates; `rf-doom-inclusion.json` retains the proper inclusion graph. No qualification, formal proof, runtime capture, or repository delivery claim follows.


## Follow-up tradeoff: legal-plant relevance (supersedes initial variant preference)

The controller challenged whether the variant improves the research witness or merely makes core K green. A focused exact check marks every core-K state, forms K/legal-trace products with residuals0,1,4, then performs complete inclusion searches. Marking every K state tests legal finite traces, not marked-completion paths. Original pair: L4 minus L1 has shortest legal difference c; L0 minus L4 has shortest legal difference commit:AB,r,c. Both strict inclusions therefore survive intersection with actual core legal traces. Variant: neither strict difference survives that intersection. Its only extra initial action is a; legitimate K cannot apply AB before reserving AB, and a prior r already moves these monitor branches to2. This also explains structurally why the variant's syntactic strictness does not affect legal K histories. Both N variants reach redundant state4 by one real private tau at initial K, with visible prefix epsilon.

Recommendation after this check: retain the original M/N as the more substantive strict-coarsening fixture, since its extra residual language includes legal plant continuations, and52 productive K contexts already rule out an all-blocking witness. Retain all324 blocked K/D outcomes explicitly. The variant answers a different, syntactic boundary and should not replace the original solely for productive core/KD counts. Adding both pairs is unnecessary unless the scope explicitly includes that distinction. No intrinsic theorem or algorithm blocker was found.

Executed `python3 /tmp/alan-phase3c5/legal_trace_probe.py > /tmp/alan-phase3c5/legal-trace-stdout.json 2> /tmp/alan-phase3c5/legal-trace-stderr.txt` (exit0). Source, complete legal-language inclusion certificates and one-tau reach paths are retained in `legal_trace_probe.py`, `legal-trace-output.json` and stdout. This focused probe shares the attributed predecessor graph utilities.
