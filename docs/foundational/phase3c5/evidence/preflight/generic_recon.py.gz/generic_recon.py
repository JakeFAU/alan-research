#!/usr/bin/env python3
"""Scratch generic controls; attributed reuse as fixture_recon_variant.py."""
import pathlib,json,gzip
source=pathlib.Path('/tmp/alan-phase3c5/fixture_recon_variant.py').read_text()
exec(source[:source.index('M,N=')])
exec(source[source.index('cache={}'):source.index('comparisons=[]')])
def descriptor(name,marks,edges):return old.prior.descriptor(name,'generic',{},'0',[old.prior.atom(i,m) for i,m in enumerate(marks)],edges)
def loop(s):return [old.prior.edge(s,l,s) for l in A]
x=descriptor('generic-min-loses-language-X',[True,False],loop(0)+loop(1)+[old.prior.edge(0,'tau',1)])
y=descriptor('generic-min-loses-language-Y',[False],loop(0))
xold=descriptor('generic-always-blocking-X',[False],[])
yold=descriptor('generic-always-blocking-Y',[False,False],[old.prior.edge(0,a,1)])
comparisons=[]
for l,rr in [(x,y),(xold,yold)]:
    comp={'Left':l,'Right':rr,'InitialLanguage':inclusion(l,'0',rr,'0'),'ReverseInitialLanguage':inclusion(rr,'0',l,'0'),**{k:profile(l,rr,k) for k in ('full','min','max')}}
    comp['JEqual']=comp['min']['Equal'] and comp['InitialLanguage']['Included'] and comp['ReverseInitialLanguage']['Included']
    comparisons.append(comp)
assert comparisons[0]['min']['Equal'] and not comparisons[0]['JEqual'] and comparisons[0]['InitialLanguage']['Word']==[]
assert not comparisons[1]['min']['Equal'] and not comparisons[1]['JEqual'] and comparisons[1]['min']['Word']==[a]
# Construct singleton-word monitors/trie for required multiword local H; source F={{a},{r}}, K={c}.
def trie(name,words):
    prefixes={()}
    for word in words:
        prefixes.update(word[:i] for i in range(1,len(word)+1))
    order=sorted(prefixes,key=lambda w:(len(w),w));ids={w:i for i,w in enumerate(order)}
    return descriptor(name,[w in words for w in order],[old.prior.edge(ids[w[:-1]],w[-1],ids[w]) for w in order if w])
H=trie('H',[(a,),(r,)])
local=[]
for name,word in [('F0',(a,)),('F1',(r,)),('K',(c,))]:
    lang=trie(name,[word]);g=old.product(lang,H)
    local.append({'Source':lang,'H':H,'Product':g})
assert [v['Product']['Nodes'][0]['CanComplete'] for v in local]==[True,True,False]
# No singleton H can hit both distinct singleton languages. Removing either leaf kills one source hit.
for kept in ((a,),(r,)):
    h=trie('singleton-H',[kept]);assert not all(old.product(trie(n,[w]),h)['Nodes'][0]['CanComplete'] for n,w in [('F0',(a,)),('F1',(r,))])
output={'GenericComparisons':comparisons,'MultiwordTrie':local}
pathlib.Path('/tmp/alan-phase3c5/generic-recon-output.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'Generic':[{'Left':v['Left']['ID'],'Right':v['Right']['ID'],'MinEqual':v['min']['Equal'],'JEqual':v['JEqual'],'MinMismatch':v['min']['Word'],'InitialInclusion':v['InitialLanguage']['Included'],'InitialCounterword':v['InitialLanguage']['Word']} for v in comparisons],'MultiwordInitialCanComplete':[v['Product']['Nodes'][0]['CanComplete'] for v in local]},indent=2))
