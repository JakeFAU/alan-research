from pathlib import Path
import copy,json,gzip
s=Path('/tmp/alan-phase3c5/generic_recon.py').read_text();exec(s[:s.index('def descriptor')])
core=copy.deepcopy(next(p for p in data['Plants'] if p['ID']=='early/shared-1/mask0'))
for state in core['States']:state['Marked']=True
# Mark all K states to test legal finite traces, not marked-completion continuations.
def language_product(m,start,identifier):
    m=copy.deepcopy(m);m['Initial']=start
    g=old.product(core,m)
    return {'ID':identifier,'Role':'generic','Signature':{},'Initial':g['Initial'],'States':[{'ID':n['ID'],'Tuple':None,'Marked':n['Marked']} for n in g['Nodes']],'Edges':[{'From':n['ID'],'Label':e['Label'],'To':e['To']} for n in g['Nodes'] for e in n['Arcs']]}
results=[]
for fixture in ('fixture-recon','fixture-recon-variant'):
    cert=json.load(gzip.open('/tmp/alan-phase3c5/'+fixture+'-certificates.json.gz'));n=cert['Monitors'][1]
    p={state:language_product(n,state,fixture+'-'+state) for state in ['0','1','4']}
    rows=[]
    for left,right in [('4','1'),('0','4')]:
        v=inclusion(p[left],p[left]['Initial'],p[right],p[right]['Initial'])
        rows.append({'Left':left,'Right':right,'IncludedOnCoreLegalTraces':v['Included'],'ShortestLegalDifference':v['Word'],'Certificate':v})
    g=old.product(core,n);path=old.shortest(g,g['Initial'],lambda x:x['Tuple'][1]=='4')
    results.append({'Fixture':fixture,'LegalDifferences':rows,'ShortestPathToRedundantState4':path})
Path('/tmp/alan-phase3c5/legal-trace-output.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps([{**x,'LegalDifferences':[{k:v for k,v in r.items() if k!='Certificate'} for r in x['LegalDifferences']]} for x in results],indent=2))
