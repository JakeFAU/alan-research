from pathlib import Path
import json
s=Path('/tmp/alan-phase3c5/generic_recon.py').read_text();exec(s[:s.index('def descriptor')])
rf=next(m for m in data['Monitors'] if m['ID']=='release-first')
doom=next(m for m in data['Monitors'] if m['ID']=='release-first-doomed')
x=inclusion(doom,'3',rf,'1');y=inclusion(rf,'1',doom,'3')
assert x['Included'] and not y['Included']
Path('/tmp/alan-phase3c5/rf-doom-inclusion.json').write_text(json.dumps({'DoomedInHealthy':x,'HealthyInDoomed':y},indent=2)+'\n')
print(json.dumps({'DoomedInHealthy':x['Included'],'HealthyInDoomed':y['Included'],'ShortestHealthyOnlyWord':y['Word'],'SubsetPairs':len(x['Pairs'])}))
