from itertools import combinations
from collections import deque
U = frozenset('abc')
langs = tuple(frozenset(c) for n in range(4) for c in combinations(U,n))
families = tuple(frozenset(c) for n in range(9) for c in combinations(langs,n))
def amin(F): return frozenset(L for L in F if not any(J < L for J in F))
def hit(F,H): return all(L & H for L in F)
def covered(F,G): return all(any(L <= K for L in F) for K in G)
for F in families:
    for G in families:
        implication = all(not hit(F,H) or hit(G,H) for H in langs)
        assert implication == covered(F,G)
        assert (amin(F)==amin(G)) == (covered(F,G) and covered(G,F))
        prod = frozenset(L&H for L in F for H in G)
        redprod = frozenset(L&H for L in amin(F) for H in amin(G))
        assert amin(prod) == amin(redprod)
print('finite-universe algebra: 256 families, 65536 ordered pairs, all 8 hit tests each; passed')

alphabet = ('r','a','c','o')
def model(extra=False):
    n=5 if extra else 4
    edges={(q,'o'):{q} for q in range(n)}
    for x in ('r','a','c'): edges[(0,x)]={3}; edges[(3,x)]={3}
    edges[(1,'r')]={2}; edges[(2,'a')]={3}
    if extra: edges[(4,'r')]={2}; edges[(4,'c')]={3}
    return n, edges, {0:{1,4} if extra else {1}}
M,N=model(),model(True)
def close(A,S):
    ans=set(S); stack=list(S)
    while stack:
        for t in A[2].get(stack.pop(),()):
            if t not in ans: ans.add(t); stack.append(t)
    return frozenset(ans)
def step(A,S,a): return close(A,{t for q in S for t in A[1].get((q,a),())})
def includes(A,q,B,p):
    start=(close(A,{q}),close(B,{p})); queue=deque([start]); seen={start}
    while queue:
        S,T=queue.popleft()
        if S and not T: return False
        for a in alphabet:
            pair=(step(A,S,a),step(B,T,a))
            if pair not in seen: seen.add(pair); queue.append(pair)
    return True
# includes(A,q,B,p) denotes L_A(q) subset L_B(p).
def profile_cover(A,S,B,T): return all(any(includes(A,q,B,p) for q in S) for p in T)
def profile_equal(A,S,B,T):
    return all(any(includes(A,q,B,p) and includes(B,p,A,q) for p in T) for q in S) and all(any(includes(A,q,B,p) and includes(B,p,A,q) for q in S) for p in T)
start=(close(M,{0}),close(N,{0})); queue=deque([(start,())]); seen={start}; full_mismatch=[]
while queue:
    (S,T),w=queue.popleft()
    assert profile_cover(M,S,N,T) and profile_cover(N,T,M,S)
    if not profile_equal(M,S,N,T): full_mismatch.append(w)
    for a in alphabet:
        pair=(step(M,S,a),step(N,T,a))
        if pair not in seen: seen.add(pair); queue.append((pair,w+(a,)))
assert full_mismatch == [()]
assert includes(N,1,N,4) and not includes(N,4,N,1)
assert includes(N,4,N,0) and not includes(N,0,N,4)
print(f'proposed M/N: complete paired subset graph has {len(seen)} nodes; reduced profiles equal at every node; full-profile mismatch at initial/O-only node; strict L1 < L4 < L0 passed')
