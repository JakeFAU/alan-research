#!/usr/bin/env python3
"""Design reconnaissance only; explicitly reuses Phase 3C.4 automata/product utilities."""
import copy,gzip,hashlib,importlib.util,itertools,json,pathlib,sys
sys.dont_write_bytecode=True
ROOT=pathlib.Path('/Users/jacob/.codex/worktrees/phase3b4-research/alan-research')
OUT=pathlib.Path('/tmp/alan-phase3c5')
p=ROOT/'docs/foundational/phase3c4/tools/audit.py'
spec=importlib.util.spec_from_file_location('reuse3c4',p); old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
rawpath=ROOT/'docs/foundational/phase3c4/evidence/task1/export.json.gz';compressed=rawpath.read_bytes();raw=gzip.decompress(compressed)
assert hashlib.sha256(compressed).hexdigest()=='35115c3104cddd8a789c80a8c0e73eb7c7f173632af512776ba8502b61b9afc9'
assert hashlib.sha256(raw).hexdigest()=='b40f1d5ac0aea0f43999502ea318cb128f545eb8fb1fd129451915a5aa84bf1f'
data=json.loads(raw);assert data['Schema']=='alan/phase3c4/v1'
A=old.ALPHABET;r,a,c='reserve-capacity:AB','apply:AB','commit:BC'
def fixture(aug):
    n=5 if aug else 4
    edges=[old.prior.edge(s,l,s) for s in range(n) for l in A if l not in (r,a,c)]
    edges += [old.prior.edge(0,'tau',1)]+[old.prior.edge(0,l,3) for l in (r,a,c)]
    edges += [old.prior.edge(1,r,2),old.prior.edge(2,a,3)]+[old.prior.edge(3,l,3) for l in (r,a,c)]
    if aug:edges += [old.prior.edge(0,'tau',4),old.prior.edge(4,r,2),old.prior.edge(4,c,3)]
    return old.prior.descriptor('antichain-augmented' if aug else 'antichain-baseline','M',old.prior.CORE,'0',[old.prior.atom(s,True) for s in range(n)],edges)
M,N=fixture(False),fixture(True);monitors=data['Monitors']+[M,N]
cache={}
def inclusion(ld,ls,rd,rs):
    key=ld['ID'],ls,rd['ID'],rs
    if key in cache:return cache[key]
    left,right=old.Automaton(ld),old.Automaton(rd)
    pairs,words,arcs=old.subsets(left,right,ls,rs)
    bad=next((i for i,(x,y) in enumerate(pairs) if left.accepts(x) and not right.accepts(y)),None)
    out={'Included':bad is None,'Word':None if bad is None else words[bad], 'Pairs':[{'Left':list(x),'Right':list(y),'LeftAccept':left.accepts(x),'RightAccept':right.accepts(y),'Arcs':row} for (x,y),row in zip(pairs,arcs)]}
    cache[key]=out;return out
def sub(ld,s,rd,t):return inclusion(ld,s,rd,t)['Included']
def eq(ld,s,rd,t):return sub(ld,s,rd,t) and sub(rd,t,ld,s)
def reduced(d,states,kind):
    reps=[]
    for s in states:
        if not any(eq(d,s,d,t) for t in reps):reps.append(s)
    return [s for s in reps if not any(t!=s and (sub(d,t,d,s) if kind=='min' else sub(d,s,d,t)) for t in reps)]
def profile(ld,rd,kind):
    pairs,words,arcs=old.subsets(old.Automaton(ld),old.Automaton(rd),ld['Initial'],rd['Initial'])
    nodes=[]
    for (ls,rs),row in zip(pairs,arcs):
        l=list(ls) if kind=='full' else reduced(ld,ls,kind)
        rr=list(rs) if kind=='full' else reduced(rd,rs,kind)
        okay=all(any(eq(ld,s,rd,t) for t in rr) for s in l) and all(any(eq(ld,s,rd,t) for s in l) for t in rr)
        nodes.append({'Left':list(ls),'Right':list(rs),'LeftReduced':l,'RightReduced':rr,'Equal':okay,'Arcs':row})
    first=next((i for i,n in enumerate(nodes) if not n['Equal']),None)
    return {'Equal':first is None,'Word':None if first is None else words[first],'Pairs':nodes}
comparisons=[]
for ld,rd in itertools.combinations(monitors,2):
    comparisons.append({'Left':ld['ID'],'Right':rd['ID'],'LanguageEqual':eq(ld,ld['Initial'],rd,rd['Initial']),**{k:profile(ld,rd,k) for k in ('full','min','max')}})
core=next(p for p in data['Plants'] if p['ID']==old.prior.plant_id(old.prior.CORE))
contexts=[(p,None) for p in data['Plants']]+[(core,d) for d in data['Controllers']]
rows=[];graphs={}
for plant,controller in contexts:
    for m in monitors:
        bound=copy.deepcopy(m);bound['Signature']=plant['Signature']
        g=old.product(plant,bound,*([controller] if controller else []))
        cid=plant['ID']+(' || '+controller['ID'] if controller else '')
        rows.append({'Context':cid,'Monitor':m['ID'],'Nonblocking':g['Nonblocking'],'InitialCanComplete':g['Nodes'][0]['CanComplete'],'States':g['States'],'Arcs':g['Arcs'],'CanComplete':g['CanComplete']})
        graphs[cid,m['ID']]=g

def classes(kind):
    groups=[]
    for m in monitors:
        name=m['ID']
        for group in groups:
            match=next(x for x in comparisons if {x['Left'],x['Right']}=={name,group[0]})
            if match['LanguageEqual'] if kind=='language' else match[kind]['Equal']:
                group.append(name);break
        else:groups.append([name])
    return groups
counts={k:sum(x['LanguageEqual'] if k=='language' else x[k]['Equal'] for x in comparisons) for k in ('language','full','min','max')}
counts.update({'Products':len(rows),'ProductStates':sum(x['States'] for x in rows),'ProductArcs':sum(x['Arcs'] for x in rows),'ProductCanComplete':sum(x['CanComplete'] for x in rows),'InitialCanComplete':sum(x['InitialCanComplete'] for x in rows),'NonblockingProducts':sum(x['Nonblocking'] for x in rows)})
minsub=[]
for comp in comparisons:
    if not comp['min']['Equal']:continue
    for plant,d in contexts:
        cid=plant['ID']+(' || '+d['ID'] if d else '')
        l=graphs[cid,comp['Left']]['Nonblocking'];rr=graphs[cid,comp['Right']]['Nonblocking'];assert l==rr
        minsub.append(l)
counts.update(MinSubstitutions=len(minsub),MinNonblockingSubstitutions=sum(minsub),MinBlockingSubstitutions=len(minsub)-sum(minsub))
mn=next(x for x in comparisons if x['Left']==M['ID'] and x['Right']==N['ID'])
rfdoom=next(x for x in comparisons if x['Left']=='release-first' and x['Right']=='release-first-doomed')
assert not mn['full']['Equal'] and mn['min']['Equal'] and mn['LanguageEqual']
assert rfdoom['max']['Equal'] and graphs[core['ID'],'release-first']['Nonblocking'] and not graphs[core['ID'],'release-first-doomed']['Nonblocking']
assert sub(N,'1',N,'4') and not sub(N,'4',N,'1') and sub(N,'4',N,'0') and not sub(N,'0',N,'4')
examples={}
for dtype in ('K','KD'):
    selected=[x for x in rows if x['Monitor']==M['ID'] and (' || ' in x['Context'])==(dtype=='KD')]
    examples[dtype]={'NonblockingCount':sum(x['Nonblocking'] for x in selected),'BlockingCount':sum(not x['Nonblocking'] for x in selected),'NonblockingExample':next((x for x in selected if x['Nonblocking']),None),'BlockingExample':next((x for x in selected if not x['Nonblocking']),None)}
assert all(examples[k]['NonblockingCount']>0 and examples[k]['BlockingCount']>0 for k in examples)
selected_graphs={k+'-'+str(nb):graphs[next(x for x in rows if x['Monitor']==M['ID'] and (' || ' in x['Context'])==(k=='KD') and x['Nonblocking']==nb)['Context'],M['ID']] for k in examples for nb in (False,True)}
proper={f'{s}<={t}':inclusion(N,s,N,t) for s,t in [('1','4'),('4','1'),('4','0'),('0','4')]}
# finite-language local-hit test controls; tokens use inherited visible labels.
controls=[]
for name,F,K in [('multiword',[{(a,)},{(r,)}],{(c,)}),('epsilon',[{()}],set()),('empty-family',[],{(a,)}),('empty-language',[set()],set()),('equal',[{(a,)}],{(a,)}),('proper',[{(a,)}],{(a,),(r,)}),('duplicates',[{(a,)},{(a,)}],{(c,)})]:
    cover=any(L<=K for L in F)
    H=set() if cover else {min(L-K,key=lambda w:(len(w),w)) for L in F}
    hitF=all(bool(L&H) for L in F);hitK=bool(K&H)
    assert cover or (hitF and not hitK)
    controls.append({'Name':name,'F':[[list(w) for w in sorted(L)] for L in F],'K':[list(w) for w in sorted(K)],'Covered':cover,'H':None if cover else [list(w) for w in sorted(H)],'HitsF':None if cover else hitF,'HitsK':None if cover else hitK})
summary={'Attribution':'Design reconnaissance reuses Phase3C4 Automaton/subsets/product utilities; no independent-proof or fresh qualification claim.','Inputs':{'CompressedSHA256':hashlib.sha256(compressed).hexdigest(),'RawSHA256':hashlib.sha256(raw).hexdigest(),'ReusedPython':{str(q.relative_to(ROOT)):hashlib.sha256(q.read_bytes()).hexdigest() for q in [p,ROOT/'docs/foundational/phase3c3/tools/audit.py',ROOT/'docs/foundational/phase3c2/tools/audit.py']}},'Classes':{k:classes(k) for k in ('language','full','min','max')},'PredictedCounts':counts,'FixtureContexts':examples,'CoreOutcomes':[x for x in rows if x['Context']==core['ID']],'Controls':controls}
(OUT/'fixture-recon-output.json').write_text(json.dumps(summary,indent=2)+'\n')
with gzip.open(OUT/'fixture-recon-certificates.json.gz','wt') as f:json.dump({'Monitors':[M,N],'Comparisons':comparisons,'ProperInclusions':proper,'ProductSummaries':rows,'SelectedGraphs':selected_graphs},f,separators=(',',':'))
print(json.dumps(summary,indent=2))
