# Phase 3C.5 theoretical reconnaissance

Status: design exploration and conditional source argument, not qualification, independent acceptance, mechanized proof, novelty claim, or runtime result. No repository files changed. I read the proposed brief and Phase 3C.4 contract, argument, and results. No external literature was needed or consulted; no new literature claim follows.

## Recommendation and load-bearing correction

Use the paired interface

    J_X = (Lm(X), w ↦ A(P_X(w))),
    A(F) = the distinct inclusion-minimal languages in finite F.

The reduced profile alone is sufficient for universal contextual nonblocking and is closed under the declared product. It does **not**, on arbitrary marked automata, preserve initial marked language or initial existential completion. J retains both initial completion and universal nonblocking while remaining strictly coarser than the old full residual profile. For all-marked leaves the Lm component is redundant, but that shortcut cannot govern an induction containing K or other conjunctively marked composites.

Concrete negative control: X has a marked initial state s and unmarked d, every visible label loops at both, and s-tau->d. Y is the unmarked complete one-state sink d. At every word, P_X={Sigma*,empty-language}, P_Y={empty-language}, so both minima are {empty-language}. Nevertheless Lm(X)=Sigma* and Lm(Y)=empty-language. With a one-state all-marked universal context, initial CanComplete differs. Both products are blocking because d is reachable. Thus A equality and Lm equality are incomparable in the generic marked domain: this example refutes A⇒Lm, while the inherited release-first/doomed witness refutes Lm⇒A.

## Minimal source argument

Keep the Phase 3C.4 assumptions verbatim: finite pointed marked epsilon-NFAs, exact compatible signatures and common visible alphabet, full visible synchronization, independent private tau, conjunctive marks, finite-path acceptance, no fairness/priorities/inevitability premise. Retain exactly one shared K in ALAN instantiations. The old Cartesian weak-reachability and residual-intersection lemmas apply unchanged.

### 1. Finite coinitiality lemma

For each L in a finite family F, some M in A(F) satisfies M subseteq L: descend strict inclusions until no smaller family member remains. If F is empty the assertion is vacuous. Equality classes must be collapsed, or equivalent languages explicitly treated as ties; deleting a language whenever another state has a non-strict subset can incorrectly delete every copy.

More generally, if B subseteq C are finite language families and every C member contains some B member, then A(B)=A(C). This is the clean auxiliary lemma for product closure.

### 2. Universal hit tests

For any suffix language H, not necessarily finite,

    [forall L in F: L intersect H != empty]
      iff
    [forall M in A(F): M intersect H != empty].

Forward is restriction. Reverse chooses a minimal M subseteq L and uses a witness in M intersect H. Consequently the old nonblocking criterion may replace either or both profiles by their minima. Equality of reduced profiles at **every** finite visible prefix preserves nonblocking in every compatible finite context, in both directions. It does not assert every run completes.

### 3. Product closure

For finite F,G define F tensor G = {L intersect H | L in F,H in G}. Then

    A(F tensor G) = A(A(F) tensor A(G)).

The reduced product is a subfamily of the full product. Every full intersection L intersect H contains M intersect N for some minimal M subseteq L, N subseteq H. Apply the finite coinitiality lemma. Both families empty when either input family is empty; empty intersections are retained as the empty language, never dropped. Distinct factor intersections can become equal or empty; strict factor inclusion need not remain strict after intersection.

The Phase 3C.4 product-profile equation now yields

    A(P_(X||Y)(w)) = A(A(P_X(w)) tensor A(P_Y(w))).

Therefore reduced-profile equality is itself closed under the product, not merely a sufficient test for NB. Separately Lm(X||Y)=Lm(X) intersect Lm(Y). Thus J equality is closed under compatible product and permits induction through a finite product expression. J preserves initial CanComplete because that is nonemptiness of the initial marked language; J also preserves all derivative unions through Lm equality. No claim about exact costs, refusal, divergence, runtime compilation, effects, or full-agent contexts is added.

### 4. Exact local characterization and inclusion direction

Define T_F(H) := forall L in F, L intersect H != empty. For finite F,G:

    [for every finite H subseteq Sigma*: T_F(H) implies T_G(H)]
       iff
    [for every K in G, there exists L in F with L subseteq K].

The direction is important: to derive the test for the target K, a **source** L must be a subset of K. Checking K subseteq L reverses the contract and is unsound. Forward coverage-to-implication follows immediately from the subset witness. For the contrapositive of the other direction, choose K in G with no source L subseteq K. For every L in F choose u_L in L minus K, and set H={u_L | L in F}. This H is finite, hits every L, and is disjoint from K. Choose shortest words under length then a fixed alphabet order for reproducible witnesses; regular-language inclusion decides their existence exactly. Duplicates in H collapse. Choosing from A(F) instead is sufficient after proving the reduction lemma and can reduce witness count.

The logical implication direction is T_F⇒T_G. Do not reverse it because the inclusion preorder is written with F first. A simple orientation control is F={{a}}, G={{a,b}}: implication holds, reverse implication fails at H={b}.

Equivalence under every local finite suffix-set test is consequently exactly equality of minimal language families. For completeness, mutual coverage yields minimal-family equality: for minimal L in F find K in G subseteq L, then L' in F subseteq K; minimality forces L'=L=K, and K is minimal in G. Reverse direction is immediate from reduction.

Only F needs to be finite for the finite-separator argument for a fixed G member. Keep both families finite in the public theorem to match the automata domain and the antichain result. Do not imply that the argument extends to arbitrary infinite families: F={{a^n}:n>=0} has no finite hitting H, so T_F⇒T_{ {empty-language} } holds vacuously for every finite H although no F member is contained in the empty language. Separately an infinite strict descending chain may have no minimal elements at all.

## Empty, epsilon and equality boundaries

- A(empty-family)=empty-family. T_empty-family(H) is true even for H=empty-set. An absent weak reach set is vacuous at that prefix.
- A({empty-language})={empty-language}. Its hit test is false for every H. A reachable dead residual cannot be discarded.
- If F contains empty-language, A(F)={empty-language}; the universal test is impossible regardless of productive alternatives. This explains why A alone can lose existential completion information.
- If F is empty and G nonempty, coverage fails, and H=empty-set is the correct finite separator. The witness has no suffixes; it is not a missing or invalid witness.
- If F contains empty-language, coverage from F to any G always holds, matching vacuous implication from a false antecedent.
- epsilon is an ordinary suffix word. H={epsilon} is distinct from H=empty-set. A finite trie for H marks its root iff epsilon belongs to H.
- Equal residual languages at distinct states are one family member. Strict-minimal filtering must preserve that equivalence class. Mutual non-strict inclusion is equality, not evidence for deleting both representatives.

## Local necessity is not global contextual necessity

The exact theorem concerns arbitrary H at a **fixed family**, with the ability to test each member independently. A separator H is not automatically a context distinguishing whole-system NB: a global context must reach the prefix and have every reachable earlier/later/nondeterministic branch completable. A finite trie for H only certifies the local intersections by initial CanComplete for each separately rooted residual.

Even a true initial hit test need not yield a nonblocking product with that trie. An unmarked state q has two a-transitions, one to marked f and one to unmarked dead d. Its residual language is {a}, so H={a} hits it and the initial product with the H trie is completable; the product also reaches d and blocks. This is a minimal control against confusing local CanComplete with whole-product NB.

The inherited generic unmarked X/Y witness remains decisive for J necessity: X has one unmarked state and no edges; Y has unmarked states 0,1 and one a-edge from 0 to 1. Both have Lm=empty-language, hence every pointed context product lacks any completion and is blocking. Their minima differ after a (empty family versus {empty-language}). Thus J is not necessary even for the joint global observations (initial CanComplete, NB). This control is outside the all-marked monitor roster and proves no corresponding strictness within that restricted roster.

## Proposed all-marked strict-coarsening fixture

The proposed M/N construction is sound. Let O denote all five other labels and Sigma the complete alphabet. At the relevant states:

    L3 = Sigma*
    L2 = O* union O* a Sigma*
    L1 = O* union O* r L2
    L4 = L1 union O* c Sigma*
    L0 = Sigma*

Thus L1 proper-subset L4 proper-subset L0: c witnesses the first strict inclusion and a the second. Before any r/a/c event, M's profile has L0,L1 and N adds L4; both minima are {L1}. After the first r/a/c, extra state 4 has either disappeared or reached a state already reached by an old branch. Hence all later weak reach-state subsets agree on old states. Both initial marked languages are Sigma*, so J is equal but full profiles differ. This yields strict coarsening inside the role-restricted, all-marked roster.

I independently checked this with a scratch exact epsilon-closure/subset search, treating the five indistinguishable O self-loop labels as one representative only in the scratch probe. The complete paired weak-reach graph has three nodes; reduced profiles agree at each, while the initial/O-only node has unequal full profiles. The probe also exhaustively checked the strict residual inclusions using full subset searches. This is design reconnaissance, not the eventual eight-label exporter/audit qualification.

The fixture still needs actual inherited-plant/context checks to exhibit both nonblocking and blocking products and avoid an entirely vacuous empirical roster. Initial Lm equality alone ensures neither outcome. Intuitively the liberal initial branch realizes K while the restrictive branch is release-first-like, but this is not a substitute for measured full graphs.

## Maximum-profile negative control

Keeping maximal languages reverses the needed dominance direction. Tiny algebra control: F={{a},{a,b}}, G={{a,b}} have equal maxima, while H={b} hits G but not F. This tests the incorrect algorithm even before connecting it to a whole automaton.

I inspected the current constructors in `research/componentinterfaces/fixtures.go`. The inherited RF/doomed control admits an exact all-word case argument. Words in O* reach state 0 in both. Words in O* r O* reach healthy state 1 versus doomed states {1,3}, where L1=O* union O* a Sigma* and L3=O* is a proper subset. Words in O* r O* a Sigma* reach state 2 in both. Every other word is unreachable in both. The doomed tau alternative adds no accepted word to states 0 or 1 because its O* language was already accepted. Maximal profiles therefore agree in each exhaustive case, while minimal profiles differ after reserve. Combine this source argument with the inherited opposite core NB outcomes, clearly attributed to existing evidence. The eventual new packet should additionally certify maximal-profile equality using its exact eight-label finite subset graph; that executable certification and the inherited product campaign were not rerun by this reconnaissance.

## Recommended narrow evidence and adversarial controls

1. Directed language inclusion certificates must retain complete reachable subset-pair graphs and a shortest witness of L minus K when inclusion fails, including epsilon, empty subsets, nondeterminism and tau cycles. Equality is two inclusions. The mismatch predicate is left acceptance AND NOT right acceptance, not XOR.
2. Reduced profiles can be compared by mutual coverage directly; materializing a canonical antichain is unnecessary for the equality decision. If actual minima are emitted, include same-monitor state comparisons and collapse equal-language classes before strict dominance.
3. At a profile mismatch retain the failing target residual K, each source residual's word outside K, and the deduplicated finite H. The checker should verify both coverage failure and every local hit/miss, not merely trust pairwise separators. This is more informative than a lone acceptance separator.
4. Required controls: empty family; empty language; epsilon suffix; equivalent duplicate states; strict versus non-strict inclusion; direction reversal; multiple-word separator F={{a},{b}}, K={c}, H={a,b}; dominated bad branch hidden by maxima; J's marked-language component missing; source argument finite-family hypothesis.
5. A synthetic local trie can illustrate the separator, but label its outcome only as initial CanComplete per rooted residual. Preserve a local-hit/whole-product-NB mismatch as above.
6. Keep whole-graph evidence and blocked contexts. Neither shallow prefix sampling nor equal finite-roster outcomes establishes the universal argument or global necessity.

## Scratch checks actually executed

`python3 /tmp/alan-phase3c5/theory-probe.py` completed successfully. It exhaustively checked all 256 families over the eight subsets of a three-element word universe: 65,536 ordered family pairs, all eight finite hit-test sets per pair, coverage/implication equivalence, mutual-coverage/minima equivalence, and product/minima identity. It then checked the proposed M/N fixture by complete paired subset searches, with the three-node outcome described above. This is a finite sanity check of the reasoning, not a proof of arbitrary-language statements or repository qualification. The script is scratch only.

## Remaining limits

No novelty claim; no necessity claim for global conflict equivalence; no minimal automaton or cheaper decision-procedure claim; no runtime code/evidence, distributed recovery, exact-cost, divergence, fairness, universal liveness, dynamic authority, or full-agent substitution result. The source argument remains conditional on the synchronized finite automata grammar. The paired interface corrects the generic marked-language loss without resolving any of these wider obligations.
