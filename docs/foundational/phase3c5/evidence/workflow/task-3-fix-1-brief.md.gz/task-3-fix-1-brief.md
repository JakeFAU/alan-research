# Task 3 fix round 1 / 5

Base: fbcedaee554582ec9b2ca5b6ea8f873458516894. Correct only R1 below. Keep semantic/model/checker sources and original captures unchanged. Preserve original manuscript script bytes and command/manifest records, bind their historical identities to those snapshots, and provide safe active tools. The committed PDF and manuscript prose need not change for this repair. Do not rerun Go/Python model suites or root checks.

Covering checks: actual fresh output build/render success, repeated existing-output refusal before writes, refusing historical entrypoints, and exact unchanged committed evidence/PDF hashes. Use a new capture directory for these checks. Source/artifact verifier changes must preserve original records and validate explicit historical snapshots, not silently discard failed identities. Add a focused CLI regression test if necessary; do not introduce a general capture framework.

R2 sparse Contents continuation and seven inherited warnings are logged as nonblocking presentation debt for final review. Do not mix a layout rewrite into R1. The single PDF operation marker already ran; do not invoke it again. If you discover a substantive issue beyond R1, report it to controller.

Append a fix report with exact commands, outputs and checked source identities to task-3-report.md; self-review and commit narrow correction. Do not spawn agents. Controller supplies scoped re-review.

## Review finding (verbatim)

### Important — R1 / P2: reproduction overwrites frozen manuscript evidence and the delivered PDF

- `docs/foundational/phase3c5/evidence/manuscript/render_pdf.py:5–12` sets its output directory to the committed evidence directory and immediately overwrites `build-commands.json` and the archived baseline/current logs, extracted text and pdfinfo. Lines 16, 21 and 26 also overwrite the baseline PDF archive, comparison and render-command record. These writes occur before rendering has successfully completed and without any fresh-directory guard.
- `docs/foundational/phase3c5/evidence/manuscript/build_pdf.py:9,20,27–34` reuses a fixed scratch directory with `exist_ok=True`, replaces earlier attempt records/sources and unconditionally copies a newly timestamped PDF over `paper/alan-dissertation.pdf`. A rerun therefore changes the delivered artifact and subsequently replaces the evidence describing the original reviewed build; the retained manifest and visual-review statement then describe different bytes until manually repaired.
- This conflicts with `docs/foundational/phase3c5/00-contract.md` under “Capture, independent challenge and qualification”: capture helpers must live in `tools/`, require a fresh output directory and refuse overwrite. It also undermines Task 3's requirement to retain failures and archive attributable commands/exits/hashes. This is a concrete reproduction behavior, not evidence that the accepted model captures were altered.
- Minimal correction: preserve these exact historical script bytes and original command records as historical execution evidence; add safe active helpers under `tools/` with explicit fresh output paths and refusal before any write when outputs already exist. Build/render only into the new run directory. Installing a rebuilt PDF into `paper/` or publishing a new accepted evidence set must be an explicit, separate authoring action. Ensure old executable locations cannot silently perform the unsafe behavior (for example, retain their original bytes under an explicitly historical inert snapshot name and leave a refusing entrypoint). Update links/manifests and qualify only fresh-output success, existing-output refusal, and unchanged committed evidence/PDF hashes; no model or unchanged suite rerun is needed.

