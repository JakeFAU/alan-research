# Controller proof precheck (source reasoning only)

Rechecked the finite-family implication direction and empty cases. Coverage is forall K in target G, exists L in source F with L subseteq K. If F is empty and G nonempty, H empty separates; if F contains empty language, antecedent T_F is always false and coverage holds via empty language. Equal classes collapse before proper dominance.

Product reduction follows because the reduced intersection family is a subfamily and every full intersection contains a reduced intersection; finite coinitiality gives equal minima. Intersection may collapse proper inclusions or yield empty language, which must remain.

Cartesian weak reachability relies on full visible synchronization and freely interleavable independent private steps. It supports NB at every reachable pair, not inevitability of every execution. J's initial marked language separately preserves initial possible completion and all derivative unions.

MIN-only generic witness has A={empty language} everywhere but distinct initial languages. Generic J nonnecessity uses two always-unmarked automata: no context can conjunctively mark any product state, so both observations false even though reach-profile presence differs after a. These do not prove strictness or optimality in all-marked leaves.

Local finite-H construction tests initial completion per rooted residual. Internal nondeterminism can still produce a dead branch under its trie. The 2011 primary paper likewise warns that global nonblocking constraints can involve later prefixes; no global necessity claim follows.

This precheck does not replace independent task/final review, model execution, or a mechanized proof.
