# Phase 3C.5 Task 3 handoff

Status: preparation. Task 2 review/commit pointer will be appended before dispatch. Do not start without controller dispatch.

Merged base: 347d93ba25a5f7a10f75144b1a44107be09a2f39. Task 1 reviewed source: a036b4a6133f1285fd52dc52db2eb782a3ae8439. Independent specification and quality APPROVE is recorded in task-1-review.md. Keep its sources, argument, schema and captures immutable.

## Controller qualification

All four root commands actually ran on that frozen Go commit:

- go build ./...: exit 0, 13.584 seconds, empty outputs.
- go mod verify: exit 0, all modules verified, empty stderr.
- go mod tidy -diff: exit 0, empty outputs.
- go list ./...: exit 0, 80 packages, empty stderr.

Exact records are under /tmp/alan-phase3c5/qualification/{build,module-verify,module-tidy-diff,package-list}/{job.json,result.json,stdout.log,stderr.log}. Driver: /tmp/alan-phase3c5/run-root-check.py. Archive them with actual attribution; do not rerun. No whole-root suite, global Staticcheck or go vet ran.

Source/provenance artifacts under /tmp/alan-phase3c5/:

- baseline-inputs.json: 695 baseline Go/module inputs matched to actual merged blobs and current bytes.
- embedded-inputs.json: five embedded targets matched likewise.
- new-go-inputs.json: 15 new Go files including tests, matched to accepted Task 1 commit.
- baseline-package-list.txt and baseline-package-provenance.json: actual merged historical 78-package capture.
- package-comparison.json: fresh 80-package roster, only model/exporter added.
- module-cache-seed.json: existing pinned SQLite source/archive copied into writable cache before successful module verification; no dependency update or network fetch.

The initial predecessor roster read guessed output.log.gz and failed. Its actual tracked name was output.log, then located and read. This preparation correction is retained in the provenance record.

Caches: GOCACHE=/tmp/alan-phase3c5/go-cache; GOMODCACHE=/tmp/alan-phase3c5/mod-cache; STATICCHECK_CACHE=/tmp/alan-phase3c5/staticcheck-cache.

## Accepted Task 1 evidence

Final captures 3/4: raw 14097260 bytes, SHA256 ab3cbdfda577a3ae804eb76a94a8c7ac665cf00c69f992ad6804b6e0d0e27b8a. There are 54 semantic read inputs and 10 compiled local files. Earlier captures 1/2 have identical semantic bytes but dependency-cache warnings, preserved unchanged. The helper-only repair changed no Go, argument, schema or embedded semantic source identity. Do not call every capture pristine.

Task 1 passed 12 ordinary/race top-level tests. The intentional false-hypothesis selector is skipped in normal qualification; its three separately selected runs fail as intended. Scoped Staticcheck has empty output. Consult owning records for exact counts and commands.

## Research and manuscript boundaries

J = (initial marked language, MIN residual profile) strictly coarsens FULL under the exact finite synchronized grammar with independent private steps. The finite-H hit implication has an exact local coverage characterization, not a global necessity theorem. The all-marked leaf shortcut cannot govern arbitrary marked composites.

Retain generic MIN information loss, generic J nonnecessity, MAX failure and local-hit/global-NB counterexamples. Legal-K control marks change only that separate control; original paid-completion products are unchanged. Preserve all blocked new-fixture K/D contexts. No optimality, speedup, runtime refinement or general Phase 3C closure claim.

Read task3-preparation.md for bundled PDF paths. Controller read the PDF skill but HAS NOT RUN the operation marker. Task 3 worker owns one edit/count1/pdf invocation immediately before first manuscript source authoring. Use bundled Python for Pillow. Build fresh baseline/current PDFs and measure actual pages/warnings; prior 51 pages/7 warnings are historical only.

Primary-literature.md records actual controller browser inspection: Ware and Malik (2011), arXiv:1108.0230, EPTCS 58, pp.34–48, DOI 10.4204/EPTCS.58.3. Read abstract, preliminaries, conflict and certain-conflict definitions, section 3.1, and start of 3.2. Brief related-work attribution is appropriate. Do not import its termination-event/partial-alphabet theorem as this packet's proof. Existing Tang/Moor metadata was already verified. Add BibTeX only as warranted; do not invent a conference title.

Preserve eleven instruction forms, corrected historical congruence wording, open Theorem 4.8, and disclosed inherited Markdown/TeX numbering differences. Controller owns review/workflow/delivery records. Task 3 owns results, qualification/verifier, manuscript/PDF and roadmap. Verify archived identities without repeating unchanged suites.

## Final Task 2 acceptance (supersedes preparation status)

Task 2 initial commit b079c67db3298688f32f2c5c8218a01f81d45601 was REJECTED for a demonstrated source-hash/bytecode-cache gap. Repair commit 208e1411dd9074f4d97eb9fbba4fb9b8755b3236 has scoped independent APPROVE (task-2-rereview-1.md). The earlier review, exact successful cache-substitution reproduction and pre-fix source snapshots are retained. This does not show qualification-1 actually executed stale code; it disproves its unconditional source-to-execution guarantee.

Use evidence/task2/qualification-2 as the accepted corrected Python qualification. It has 13 passing tests, nine poisoned-cache boundary controls, two valid CLI acceptances and 56 JSON/wire rejections. All 59 child source manifests match the nine-entry source-buffer manifest. Original qualification-1 remains immutable historical evidence, with its source identities resolved to pre-fix snapshots rather than falsely required to equal current checker files. The initial auditor serialization error and successful cached-code attack are different failures and both must remain visible.

The accepted test command is python3 docs/foundational/phase3c5/tools/run_audit_tests.py. A recorded controller ruling permits this source-only entrypoint to replace bare unittest discovery, because test imports also need the execution binding. Do not claim the old discovery command is source-only. Read the updated 03-independent-audit.md and appended task-2-report.md for exact import/trust boundaries. Python installation/stdlib are trusted; historical C4/C3/C2 entrypoints are not retroactively repaired.

The Python repair reused the unchanged producer export; no Go command or root check was repeated. Go inputs and all model semantic bytes remain at reviewed a036b4a6, so controller root qualification still applies. The earlier fresh producer export is under qualification-1/fresh-export and remains validly attributed to that run.

Task 3 base is 208e1411. Proceed after controller dispatch. Marker still not run. Independent Task 3 and final review remain pending.
