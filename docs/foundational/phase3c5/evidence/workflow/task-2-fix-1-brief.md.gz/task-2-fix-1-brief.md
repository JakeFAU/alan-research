# Task 2 fix round 1 / 5

Base: b079c67db3298688f32f2c5c8218a01f81d45601. Correct the executable provenance finding below. The initial task review REJECT is preserved. Keep predecessor and producer files unchanged. Do not modify existing semantic or qualification captures; preserve pre-fix checker/test/helper bytes separately and obtain fresh corrected qualification in a new directory. Covering tests belong to test_audit.py and, if useful for separation, a focused source-loading regression file. Capture/script entrypoint changes are in scope only to close this demonstrated gap. No Go or root checks need repeating.

Ruling: A source-only test runner may replace bare unittest discovery for accepted qualification if necessary to authenticate the test import itself. The original command/result remain historical. The contract requires trustworthy checker tests, not a cache-capable entrypoint. Explain the precise command change in the account/report; do not quietly claim the original command gained this guarantee.

Execute exact verified source buffers throughout the declared import chain, retaining the trust boundary for the Python installation/stdlib. Do not expand this into a general sandbox or security platform. Append commands, outputs and covering tests to task-2-report.md. Self-review and commit narrowly; controller supplies scoped re-review. Do not spawn agents.

## Review finding (verbatim)

## Important / P2 — verified source bytes are not necessarily executed

**Primary location:** `docs/foundational/phase3c5/tools/audit.py:29–36`.

The code hashes each `.py` file and then executes a `SourceFileLoader` through `spec_from_file_location(...).loader.exec_module(...)`. That loader may use a pre-existing `.pyc` whose timestamp and size match the source. `sys.dont_write_bytecode = True`, `PYTHONDONTWRITEBYTECODE=1`, and `-B` prevent writing caches; they do not prevent reading them. Consequently the predecessor source hashes and `checker-sources.json` can accurately describe the disk files while a different automaton, product, strict-comparison or descriptor implementation actually executes. This violates the task's source-bound executable reuse claim, including `docs/foundational/phase3c5/03-independent-audit.md:28–35`.

**Reproduced:** In a temporary tree containing exact copies of the four auditor source files, I compiled a same-length alteration of the C4 module's `ALPHABET` assignment, restored the original source bytes and mtime, asserted its published SHA-256, and imported C5 under `python3 -B`. The import exited zero and reported `ALPHABET: ('CACHE',)`. All predecessor source-pin checks passed. The experiment executed no full reconstruction or test suite and changed no repository source/evidence. This establishes a source-to-execution mismatch, not that the existing capture actually used a stale cache.

**Affected import boundaries:**

- `docs/foundational/phase3c5/tools/audit.py:34–36`: C5 loads C4.
- `docs/foundational/phase3c4/tools/audit.py:27–29`: reused C4 loads C3.
- `docs/foundational/phase3c3/tools/audit.py:20–22`: reused C3 loads C2.
- `docs/foundational/phase3c5/tools/capture_audit.py:15–16`: capture imports local `audit` and `test_audit` before recording source identities at `:42–44`.
- `docs/foundational/phase3c5/tools/test_audit.py:5`: test module imports local `audit`; unittest discovery itself normally imports `test_audit` through the standard cache-capable machinery. The capture's `PYTHONDONTWRITEBYTECODE` override at `capture_audit.py:22` does not close these boundaries.

**Required correction:** Execute the exact verified source buffers, bypassing bytecode caches throughout the predecessor import chain and the local capture/test imports. Make the source identity bind the bytes compiled, rather than hashing and subsequently reopening through a cache-capable loader. Keep predecessor files unchanged as required by the contract; implement source-only loading/isolation in the new task-owned code. A source-only outer import that still permits cached transitive imports is insufficient. Mere `-B`, setting `dont_write_bytecode`, or repeating the existing hashes is insufficient.

**Required regression/evidence:** Add focused temporary-copy controls with timestamp-valid same-size stale bytecode at each inherited boundary and the local capture/test boundaries, asserting that the intended source semantics execute (or that the input is rejected before execution). Retain the reproduced failure. Preserve the current qualification directory; capture corrected checker/tests/helper identities and fresh results in a new directory, with a precise account of what was rerun. Unchanged Go suites need not be repeated for this Python repair. Re-review the actual corrected diff and evidence before accepting Task 2.

**Reproduction artifacts:**

- `.superpowers/sdd/phase3c5-plan/task-2-review-cache-repro.py`: exact successful experiment source, originally supplied to `python3 -B -` on stdin.
- `.superpowers/sdd/phase3c5-plan/task-2-review-cache-repro.command.json`: original invocation, replay argv, cwd, source SHA-256 and exit.
- `.superpowers/sdd/phase3c5-plan/task-2-review-cache-repro.stdout`: exact observed successful experiment output.
- `.superpowers/sdd/phase3c5-plan/task-2-review-cache-repro.stderr`: empty output.

Replay from the repository root with `python3 -B .superpowers/sdd/phase3c5-plan/task-2-review-cache-repro.py`. The script confines temporary sources and caches to its temporary directory. Initial harness attempts encountered the host's default cache write restriction and then a `/var` versus `/private/var` cache-path alias; the retained successful script explicitly isolates the cache and resolves the temporary path.

