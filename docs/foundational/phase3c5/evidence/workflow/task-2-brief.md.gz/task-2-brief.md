### Task 2: Independent antichain, finite-hit and product audit

**Files:** Create `docs/foundational/phase3c5/tools/audit.py`, `test_audit.py`, `03-independent-audit.md`, `evidence/task2/` and any focused audit helper needed.

**Interfaces:** Consume accepted Task 1 schema/contract/export; output `python3 docs/foundational/phase3c5/tools/audit.py PATH`, valid plain/gzip exit 0, malformed/false input nonzero with specific reason. Reuse unchanged predecessor Python descriptors/automaton utilities only with explicit exact hash attribution. New inclusion/reduction/coverage/hit checks are independent from Go; old verdicts never oracle. Keep source/archive manifests and exact accepted/hostile CLI bytes and results.

- [ ] Read schema/contract before auditor implementation. Reconstruct all descriptors from written fixtures and source-bound predecessor Python constructors; verify compressed/raw predecessor pins, inherited hashes, and new source manifest. Enforce exact keys/types, duplicate-key rejection and bool/int distinction.
- [ ] Independently rebuild inclusion graphs, both directional shortest witnesses, equality classes, MIN/MAX, every complete profile comparison, coverage target and finite H. Independently rebuild all products, initial/NB labels, J substitutions and generic/trie/legal-trace/real-path witnesses. No producer verdict serves as oracle.
- [ ] Add hostile cases for removed non-tree arcs with superficial counts repaired, reversed inclusion, dropped equivalent minima, MAX-as-MIN, empty-family confusion, missing/forged H members, bad shortest words/prefixes, wrong generic observations, forged products/marks/tau/signatures/roots, source changes, unknown keys, duplicate keys and JSON nonfinite/type attacks. Retain any initially accepted hostile inputs before repair.
- [ ] Capture a third fresh export, verify identical semantic bytes and source bindings, and run `python3 -m unittest discover -s docs/foundational/phase3c5/tools -p 'test_*.py' -v`. Execute valid plain/gzip and each exact hostile CLI input, archiving argv/environment/output/exit and hashes. Use a fresh capture directory, never overwrite Task 1 evidence.
- [ ] Write independent-audit account with measured counts, reuse boundaries, actual failures and scope. Inspect full task diff and commit only Task 2; report evidence paths and source freeze for controller qualification.

