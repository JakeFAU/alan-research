package residualantichains

import "testing"

// Catches FULL equality used in place of strict antichain reduction.
func TestStrictReduction(t *testing.T) {
 ms:=extraMonitors([]byte(`{}`)); c:=compareProfiles(ms[0],ms[1])
 if c.FULL || !c.MIN || !c.MAX || !c.InitialLanguage.Equal || !c.J {t.Fatalf("strict reduction: FULL=%v MIN=%v MAX=%v initial=%v J=%v",c.FULL,c.MIN,c.MAX,c.InitialLanguage.Equal,c.J)}
}
// Catches using MIN alone for initial possibility in the generic marked domain.
func TestGenericMINInformationLoss(t *testing.T) {
 x,y:=genericMINLoss(); c:=compareProfiles(x,y)
 if !c.MIN || c.InitialLanguage.Equal || c.J {t.Fatalf("MIN loses initial information: MIN=%v initial=%v J=%v",c.MIN,c.InitialLanguage.Equal,c.J)}
}
