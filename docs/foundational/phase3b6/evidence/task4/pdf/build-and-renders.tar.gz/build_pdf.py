#!/usr/bin/env python3
"""Build the reviewed Phase 3B.6 manuscript using only cached TeX inputs."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import time

ROOT = pathlib.Path('/Users/jacob/.codex/worktrees/phase3b4-research/alan-research')
BUILD = pathlib.Path('/tmp/alan-phase3b6/pdf-final')
BUILD.mkdir(parents=True, exist_ok=False)
SOURCES = ('alan-dissertation.md', 'alan-dissertation.tex', 'references.bib')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

before = {name: digest(ROOT / 'paper' / name) for name in SOURCES}
for name in SOURCES:
    shutil.copyfile(ROOT / 'paper' / name, BUILD / name)
argv = ['/opt/homebrew/bin/tectonic', '--only-cached', '--keep-logs', 'alan-dissertation.tex']
started = time.monotonic()
result = subprocess.run(argv, cwd=BUILD, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
elapsed = time.monotonic() - started
(BUILD / 'build.log').write_bytes(result.stdout)
after = {name: digest(ROOT / 'paper' / name) for name in SOURCES}
record = {
    'research_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'argv': argv, 'cwd': str(BUILD), 'exit': result.returncode,
    'elapsed_seconds': elapsed,
    'source_sha256_before': before, 'source_sha256_after': after,
    'build_log_sha256': digest(BUILD / 'build.log'),
    'previous_pdf_sha256': digest(ROOT / 'paper' / 'alan-dissertation.pdf'),
    'source_unchanged': before == after,
    'pdf_sha256': digest(BUILD / 'alan-dissertation.pdf') if result.returncode == 0 else None,
    'operation_marker': {'already_run_once': True, 'tool_chunk': 'e5232e', 'exit': 0},
}
(BUILD / 'build-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
if result.returncode:
    print(result.stdout.decode(errors='replace'))
    raise SystemExit(result.returncode)
assert before == after
for argv, output in [
    (['/opt/homebrew/bin/pdfinfo', str(BUILD / 'alan-dissertation.pdf')], 'pdfinfo.txt'),
    (['/opt/homebrew/bin/pdftotext', '-layout', str(BUILD / 'alan-dissertation.pdf'), '-'], 'paper-text.txt'),
    (['/opt/homebrew/bin/tectonic', '--version'], 'tectonic-version.txt'),
    (['/opt/homebrew/bin/pdftoppm', '-v'], 'poppler-version.txt'),
]:
    check = subprocess.run(argv, cwd=BUILD, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (BUILD / output).write_bytes(check.stdout)
    assert check.returncode == 0, (argv, check.returncode)
print((BUILD / 'pdfinfo.txt').read_text())
