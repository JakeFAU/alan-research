package effectobservation

// Ledger separately represents event-derived custody and lifecycle facts.
// Historical admission is fixed at the declared initial cut.
type Ledger struct {
	PacketSent bool `json:"packet_sent"`
	Contact bool `json:"contact"`
	World Result `json:"world"`
	Inbox Result `json:"inbox"`
	Stored Result `json:"stored"`
	Used Result `json:"used"`
	Opportunity bool `json:"opportunity"`
	Dead bool `json:"dead"`
	Restarted bool `json:"restarted"`
	Revoked bool `json:"revoked"`
	CValid bool `json:"c_valid"`
	Refused bool `json:"refused"`
}

func AuditTrace(events []Event) (Ledger, error) { return Ledger{}, nil }
