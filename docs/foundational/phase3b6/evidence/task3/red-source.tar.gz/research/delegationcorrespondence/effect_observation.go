package delegationcorrespondence

// EffectObservationCaseReport is the opt-in source-conditioned relation.
type EffectObservationCaseReport struct {
 Legacy CaseReport
 RawValid, ContinuityValid, ProtocolValid, Supported bool
 Physical ExternalReport
 Reasons []string
}

func CheckEffectObservationDirectory(dir string) (EffectObservationCaseReport, error) {
 legacy, err := CheckBindingDirectory(dir)
 return EffectObservationCaseReport{Legacy: legacy, Supported: true}, err
}
