package delegationcorrespondence

import (
 "encoding/json"
 "os"
 "path/filepath"
 "testing"
)

func effectObservationFixture(t *testing.T, mode, name string) string {
 t.Helper()
 root:=os.Getenv("ALAN_EFFECT_OBSERVATION_CORPUS")
 if root=="" { t.Skip("ALAN_EFFECT_OBSERVATION_CORPUS is not set") }
 data,err:=os.ReadFile(filepath.Join(root,"manifest.json"));if err!=nil {t.Fatal(err)}
 var manifest map[string]struct { Cases map[string]string }
 if err=json.Unmarshal(data,&manifest);err!=nil {t.Fatal(err)}
 member:=manifest["raw-"+mode+".tar.gz"].Cases[name]
 if member=="" {t.Fatal("missing corpus case",name)}
 return filepath.Join(root,"raw-"+mode,member)
}

func TestEffectObservationPositive(t *testing.T) {
 for _,mode:=range []string{"normal","race"} {for _,name:=range []string{"N07","applied-unknown-revoked-before-fresh-gate"} {
 t.Run(mode+"/"+name,func(t *testing.T){
 r,e:=CheckEffectObservationDirectory(effectObservationFixture(t,mode,name));if e!=nil {t.Fatal(e)}
 if !r.RawValid||!r.ContinuityValid||!r.Physical.Valid||!r.ProtocolValid||!r.Supported {t.Fatalf("semantic assertion: genuine sealed cut must be supported: raw=%v continuity=%v physical=%v protocol=%v supported=%v reasons=%v",r.RawValid,r.ContinuityValid,r.Physical.Valid,r.ProtocolValid,r.Supported,r.Reasons)}
 })}}
}

func TestEffectObservationCausalAckRequired(t *testing.T) {
 parent:=effectObservationFixture(t,"normal","applied-unknown-revoked-before-fresh-gate")
 var ack map[string]json.RawMessage
 if err:=json.Unmarshal(readRevocationTestFile(t,parent,"acknowledgments.json"),&ack);err!=nil {t.Fatal(err)}
 delete(ack,"Endpoint")
 dir:=editRevocationDirectory(t,parent,map[string][]byte{"acknowledgments.json":bytesJSON(ack)})
 r,e:=CheckEffectObservationDirectory(dir);if e!=nil {t.Fatal(e)}
 if r.Supported {t.Fatal("semantic assertion: final application without endpoint causal acknowledgment must not certify application-before-loss")}
}
