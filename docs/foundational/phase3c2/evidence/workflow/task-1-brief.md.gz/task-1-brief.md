### Task 1: Model, concrete adapter and frozen export

**Files:**
- Create: `research/capacitycomposition/{model,compose,concrete,explore}.go` and focused `_test.go` files.
- Create: `research/capacitycomposition/cmd/export/{main,main_test}.go` and package README.
- Create: `docs/foundational/phase3c2/{01-argument,02-evidence-schema}.md`.
- Create: `docs/foundational/phase3c2/evidence/task1/` (raw export, source hashes, RED/verification logs).

**Interfaces:**
- Consume unchanged `contractcomposition.NewConfig("chain",mask)`, its types, component functions and concrete transport relation.
- Produce package `capacitycomposition`: `NewConfig(layout, policy string, mask uint8) (Config,error)`, `Initial(Config) State`, `Successors(Config,State) []Step`, `Explore(Config) Graph`, `NewConcrete(Config) (ConcreteState,error)`, `Project(Config,ConcreteState) State`, `ConcreteSuccessors(Config,ConcreteState) []MicroStep`, `Lift(Config,ConcreteState,Action) ([]MicroStep,error)`.
- Produce `Leaf(Config,string) (Component,error)`, `Join(Component,Component) (Component,error)`, `Close(Component) (Config,error)`, validated full root/membership records, and deterministic JSON export via `go run ./research/capacitycomposition/cmd/export`.
- JSON schema version is `alan/phase3c2/v1`; document exact keys/types, roster, witness/probe meanings and CLI output in the schema. Task 2 consumes this schema and checked export, not Go implementation helpers.

- [ ] Write failing tests for exact root accounting, aggregate-equal/different-CanComplete holders, ready-now invalidation, stable-ready every-reachable completion, and the excluded old AB-apply trace. Execute and retain RED output before implementation.
- [ ] Implement the finite relation and complete BFS/reverse reachability, rejecting malformed configs/states and keeping all arcs. Include shared-two/separate-one and all-servicing controls, two regroupings and invalid joins. No cap values or counts may be silently coerced.
- [ ] Implement concrete wrapping and finite-path lifting with all old transport/crash behavior intact. Test every enabled abstract action from declared factored custody/availability representatives; enumerate the representative domain explicitly and validate full projection, legal adjacency and no unrelated progress. Include both real opaque result values, retry/ACK behavior and crash-held witnesses. Report that this is not exhaustive concrete-product enumeration.
- [ ] Construct genuine witness prefixes/suffixes from the transition relation for both holders and ready-now invalidation; compare full base states and pool totals. Keep the old-trace restriction witness. Emit full post-states/events and source-bound probe summaries.
- [ ] Write conditional source proof and schema. Explain what composition joins, what it cannot join, and why the universal lifting claim refers to the new resource-aware abstraction.
- [ ] Run `go test ./research/capacitycomposition/...`, `go test -race ./research/capacitycomposition/...`, `staticcheck ./research/capacitycomposition/...`, deterministic export comparison, formatting/diff checks. Inspect full diff and commit narrowly with imperative subject. Return exact command logs, coverage counts and concerns.

