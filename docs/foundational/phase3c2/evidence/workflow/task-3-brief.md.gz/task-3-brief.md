### Task 3: Qualification and manuscript reconciliation

**Files:**
- Create: `docs/foundational/phase3c2/{04-results,05-qualification}.md`, `evidence/qualification/`, `evidence/manuscript/`.
- Modify: `docs/foundational/phase3/README.md`, `paper/alan-dissertation.{md,tex,pdf}`; update `paper/references.bib` only if verified citations change.
- Modify: `research/capacitycomposition/README.md` to address Task 1 review M1: copy the verified `-timeout 30m` into the race reproduction command.

**Interfaces:**
- Consume reviewed model/export/checker/proof and exact captured evidence from Tasks 1/2.
- Produce source-bound qualification manifest, result table with measured counts, scoped claims, aligned manuscript text and rebuilt/render-inspected PDF.

- [ ] Inspect actual source/evidence and verify export/audit hashes against final source. Reuse this task's reviewed unchanged-source scoped ordinary/race/Staticcheck and audit runs; rerun only for fixes or unresolved concerns. Run root `go build ./...`, `go mod verify`, `go mod tidy -diff`, and formatter/diff checks; record actual commands, versions, exits and outputs. Existing broad lint findings are historical, not silently green.
- [ ] Correct the README race command to use the recorded explicit timeout. This documentation-only correction needs comparison to the passing command log, not a new long race run; README is outside the export source-hash set.
- [ ] Verify all prior Go/dependency inputs against retained Phase 3C.1 manifests and merged base. Attribute its unchanged full-suite evidence explicitly instead of claiming a new full-suite run. Any changed old input invalidates reuse and requires appropriate fresh checks. Reconcile `go list ./...` package coverage with inherited plus new packages; no hidden missing packages.
- [ ] Write results distinguishing elementary resource-wait counterexample, source proof, finite checked roster, factored concrete probes and selected histories. Explain stable-ready's cost and the new-versus-old abstraction boundary. Preserve open obligations and current runtime distinction. Cite primary background accurately if needed; do not invent metadata or novelty.
- [ ] Update both manuscript forms and roadmap with the same claims, assumptions, counts, controls and exclusions; preserve prior theorem scope. Use the PDF skill and existing build tools to rebuild, extract text and render/inspect changed pages. Record inherited differences/warnings and check for new ones. No wholesale manuscript repair.
- [ ] Archive source-bound manifests/logs without temporary artifacts or secrets. Inspect complete diff, run applicable final checks and commit narrowly. Return exact fresh/historical qualification split, PDF evidence and limitations.
