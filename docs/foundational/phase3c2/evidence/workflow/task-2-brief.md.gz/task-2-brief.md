### Task 2: Independent audit and adverse evidence

**Files:**
- Create: `docs/foundational/phase3c2/tools/{audit,test_audit}.py`.
- Create: `docs/foundational/phase3c2/03-independent-audit.md`.
- Create: `docs/foundational/phase3c2/evidence/task2/` (capture tooling, immutable export, exact hostile records/rejections, manifest, logs).

**Interfaces:**
- Consume Task 1's `02-evidence-schema.md`, `01-argument.md`, exported `alan/phase3c2/v1` document and declared CLI.
- Produce `python3 docs/foundational/phase3c2/tools/audit.py EXPORT` with nonzero failure for malformed/incorrect evidence, deterministic summary JSON on success.
- Produce standard-library unittest suite and reproducible hostile generation/capture commands; keep all original evidence and source hashes.

- [ ] Implement from the frozen spec/schema a separate declarative graph generator, reverse completion solver, root/grouping validation and concrete trace replay. Do not import or shell out to Go helpers or reuse their guards; independent algorithmic validation is not an independently discovered specification.
- [ ] Regenerate all roster graphs/all arcs and compare exact complete labels, parent reachability, CanComplete and counts. Reconstruct holder-equality witnesses and legal ready-now invalidation; verify the stable-ready trace restriction under the stated erased observation.
- [ ] Replay actual histories from empty initial custody with actor/availability, exact binding, root membership, reservation/apply/release and result/ACK constraints. Do not infer receipt truth from claimed labels or final states. Validate every provided concrete post-state and projected action.
- [ ] Add hostile tests for all spec-listed corruption classes, plus strict schema/duplicate keys/unknown fields/types. Each mutation must be rejected for its intended reason; preserve exact mutated input and output, not only a test name. Demonstrate all-arc checking by removal of a non-tree arc. Do not call a record mutation an operational counterexample.
- [ ] Run `python3 -m unittest discover -s docs/foundational/phase3c2/tools -p 'test_*.py' -v`, audit a fresh Go export, and verify retained manifests. Inspect full diff and commit. Return exact evidence paths, measured totals, independence limits and any spec/model disagreements.

