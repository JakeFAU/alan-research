### Task 1: Boundary automata, substitution attack and model captures

**Files:**
- Create `research/componentinterfaces/automaton.go`, `language.go`, `product.go`, `plant.go`, `concrete.go`, `evidence.go` and focused `_test.go` files; a small `fixtures.go` or `capture.go` split is permitted if responsibilities require it.
- Create `research/componentinterfaces/cmd/export/main.go` and `README.md`.
- Create `docs/foundational/phase3c3/01-argument.md`, `02-evidence-schema.md`, and `evidence/task1/`.

**Interfaces:**
- Consumes unchanged `capacitycomposition.NewConfig`, `Initial`, `Successors`, `Complete`, `NewConcrete`, `ConcreteSuccessors`, `Project`, `Lift`; `contractcomposition.Action/Binding` supplies exact visible bindings.
- Produces `Export(w io.Writer) error`, called by `go run ./research/componentinterfaces/cmd/export`; stdout is deterministic versioned JSON, diagnostics go to stderr. No timestamps or temporary paths in semantic export.
- Produces a complete versioned schema in `02-evidence-schema.md` for Task 2: exact alphabet/signatures, five monitor descriptors, 72 plant descriptors, 324 D descriptors, 1,980 full product graphs, all ten language comparisons, normalized grouping checks, eight concrete histories with event/post-state/cut metadata, counts, and producer source manifest. Full declared arcs and markings are retained; no counts-only certificate.
- Internal Go types/function names are the implementer's responsibility; keep them focused and expose only the exporter boundary needed downstream.

- [ ] Read the spec, owning old functions, relevant Go/testing skills and write focused failing tests before implementation. Retain raw RED command/output/exit; distinguish compile failures from falsified semantic hypotheses.
- [ ] Implement strict automaton/signature/role validation, shared-visible/private-tau product, complete BFS/reverse CanComplete and every-reachable nonblocking classification. Keep source-state keys stable and grouping tuples explicitly normalizable.
- [ ] Implement exact epsilon-NFA language comparison by closure/subset-pair exploration, including shortest distinguishing words and acceptance checks. Tests cover epsilon acceptance mismatch, tau cycle, empty subset, nondeterministic equivalent branches and changed post-prefix behavior beyond a shallow sample.
- [ ] Construct the five exact M fixtures and 324 exact D fixtures. Enumerate the contract's 360 + 1,620 full products and all ten language comparisons. Check both parenthesizations against the flat triple relation for the 1,620 D cases. Retain both successful and blocked equal-language substitutions.
- [ ] Implement the concrete M wrapper and eight genuine captured histories, using old custody preparation and real successor steps. Test common-cut full old state/holds/config equality with opposite product CanComplete; positive suffix; shared-two/separate/servicing controls; private B-up requirement; retained PC after crash/recovery; successful and doomed branches. No post-capture state rewriting.
- [ ] Write the source argument: exact product-language intersection in both directions; conditional substitution for pointed components; ALAN instantiation and concrete projection/lifting premises; source proof versus finite evidence; nonblocking counterexample; no necessity/full abstraction for the role-restricted grammar. Preserve the stable-ready restriction boundary.
- [ ] Freeze schema and capture the complete deterministic export twice from final producer source. Bind all actual producer inputs, including imported old model files and relevant Go module files. Record actual measured totals; do not invent expected graph sizes.
- [ ] Run `go test -v -timeout 30m ./research/componentinterfaces/...`, the same command with `-race`, and `staticcheck ./research/componentinterfaces/...` with writable task caches. Capture exact argv/environment/exit/output. After checks pass, do not rerun unchanged suites merely for repetition.
- [ ] Inspect full task diff and status, commit only this task, and write the task report with semantics, evidence, counts, limitations and all concerns. Leave root-wide checks/manuscript to controller/Task 3.

