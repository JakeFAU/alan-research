### Task 2: Independent interface and history audit

**Files:**
- Create `docs/foundational/phase3c3/tools/audit.py`, `test_audit.py`, `03-independent-audit.md`, and `evidence/task2/`.

**Interfaces:**
- Consumes Task 1's frozen `02-evidence-schema.md` and exporter stdout, not Go helpers or operational predicates.
- Produces CLI `python3 docs/foundational/phase3c3/tools/audit.py PATH` accepting plain JSON or gzip. Valid complete export exits 0; malformed/false evidence exits nonzero with a precise reason.
- Produces exact captured accepted/rejected inputs, command records, source/archive manifest and an audit report for Task 3. Fresh Go export may be invoked to capture bytes but cannot serve as the independent transition oracle.

- [ ] Read contract/schema first; implement a separate declarative plant, fixture generator, complete synchronous product, epsilon-language comparison, marking/reverse reachability and concrete replay. Do not import, translate mechanically from, or call Go guards; use the shared written semantics. Reject duplicate/unknown records and invalid types, including Python bool-as-int accidents.
- [ ] Independently regenerate all 1,980 graphs with all arcs, marks and CanComplete values, ten comparisons, 324 descriptors and normalized parenthesizations. Check distinguishing words by independent acceptance and shortestness as the schema promises. Validate equal-language substitution in the entire declared roster.
- [ ] Replay all eight concrete histories from genuine empty initial custody. Recompute every post-state, actual-result provenance, monitor step/role, physical eligibility and cut equality. Tie concrete projections to product states and verify positive suffixes/negative graph labels. No hidden Q changes, result invention or PC reset.
- [ ] Write positive and hostile tests that cover every Review Focus and all hostile categories in the contract. At least one omitted non-tree-arc attack must retain reachability parents and correct superficial counts. Include forged equivalence, tau/mark changes, external veto, signature/binding/root changes, fabricated completion and altered common-cut/recovery evidence. Keep rejected fixtures exact and reasons meaningful; preserve any initially accepted attack before fixing checker.
- [ ] Capture a fresh producer export and confirm source-bound byte equality with Task 1. Run `python3 -m unittest discover -s docs/foundational/phase3c3/tools -p 'test_*.py' -v` plus valid plain/gzip and every hostile CLI input, retaining argv, outputs and exit status. Hash every accepted/rejected input and checker source.
- [ ] Write audit scope and measured findings. Explicitly separate independent abstract reconstruction and concrete replay from the conditional source proof and any unexecuted runtime claims. Inspect full diff and commit only Task 2; report exact paths/commits/checks and concerns.

