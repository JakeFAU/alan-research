# Phase 3C.3 design reconnaissance: completion-preserving continuation interfaces

Status: preparatory source analysis, not an approved implementation design, executed experiment, checked proof, runtime qualification, or delivery claim. No repository file was edited and no test was run. The parent supplied merged base `ab01204a0b5121b81379043576ee7bbe46118a19` (tree equal to `6576a203`) and current branch `codex/phase3c3-component-interfaces`; this note does not independently verify delivery.

## Research question and recommendation

Can a component's exact obligations, capacity holdings, and release dependencies determine possible completion when its private continuation controls which otherwise legal action happens next? If not, can an interface that retains the component's successful boundary sequences support a precisely limited substitution result?

Use the existing Phase 3C.2 fixed-chain relation as an unchanged shared plant K and add a replaceable finite continuation monitor M for B-owned progress actions. Expose every old named commit/reserve/apply/consume action and its exact binding, including applications whose endpoints are grouped internally. Hide only independent private bookkeeping steps of M. Give a same-snapshot/opposite-CanComplete counterexample and a marked-boundary-language substitution argument. This is **continuation-monitor substitution over a retained ALAN research plant**, not substitution of an entire agent, extraction of its transport/custody implementation, or runtime refinement.

This narrower statement is the cleanest packet supported by the code. `capacitycomposition.Config.Validate` hard-codes the A/B/C chain, two originals, three layouts and three policies; `Component`/`Join` are static declarations, and dynamic state remains one global relation. There is no existing open-component implementation to extract faithfully. Calling the new monitors full agents would silently move responsibility for service/custody out of K without a factorization proof.

## Sources inspected and decisive facts

- `AGENTS.md` and Phase 3C.1/3C.2 contracts, source arguments and results.
- `research/contractcomposition/model.go`: exact AB/BC binding, U/W/P/D state, serial gate true when outgoing original is U or D; commit can invalidate that gate.
- `research/capacitycomposition/model.go`: exact holder bits and root identity; reserve/apply/consume rules; apply atomically frees the original's Q unit; consume does not require Q.
- `research/capacitycomposition/compose.go`: retained static declarations, exact close, no behavioral replacement.
- `research/capacitycomposition/concrete.go`: actual actor for reserve/apply is callee; commit/consume belong to caller; universal-representative lifting prepares transport without another progress action or holder change.
- `research/capacitycomposition/explore.go`: whole finite BFS retaining all arcs and reverse completion classification.
- `paper/alan-dissertation.md`, sections 6.16/6.17: visible internal application labels, existence of finite completion, no contextual substitution/runtime refinement claim.

Prior results are read, not rerun. The proposal deliberately goes beyond debt erasure (3C.1) and exact-holder erasure (3C.2): both compared components retain the **same exact stages and holders**, while their permitted future ordering differs.

## Model and boundary ownership

Freeze K first to `early/shared-1`, serial B, fixed A/B/C and original AB/BC bindings. All effect resources remain distinct and permanently authorized; Q is the single reusable capacity root. Reuse old definitions of Complete and CanComplete.

The visible alphabet consists of eight exact actions: commit/reserve/apply/consume for each named original. A label carries kind, original, full immutable binding, and enough configuration/signature information to disambiguate Q membership and actor. Capacity is never represented by a copied local pool. Either keep immutable root descriptors/memberships in the shared signature or include their references in labels, but do not count root values twice. Existing apply stays the atomic effect/receipt-retention/Q-release transition; receipt ACK release is not a capacity release.

B controls only:

- commit BC and consume BC (caller B);
- reserve AB and apply AB (callee B).

A/C/context controls commit/consume AB and reserve/apply BC. A B monitor must accept these external actions without veto: use self-loops or observation updates that cannot reject a legal external action. Invalid binding/configuration is rejected before composition. K enforces all original stage, service and capacity rules. The monitor may remove B-owned choices but cannot create K transitions, change a binding, grant permission, or mutate Q independently. Private tau moves alter only monitor state and cannot read/write an unexposed K field or effect result.

A product state is (k,m). A visible step exists iff K and M both allow the same exact label. A private M tau step changes only m. K completion requires both originals D. Monitor acceptance means its declared private continuation has no outstanding local completion obligation. For the concrete attack monitors, every private phase is accepting: the only completion obligations are already retained in K. This prevents an arbitrary acceptance flag from manufacturing the negative result. Successful product states satisfy both predicates.

## Smallest attack: same holdings, different continuation order

Define both monitors with an initial phase `await-reserve`, accepting all external A/C events. They initially allow reserve AB but block commit BC. Legal K rules ensure reserve AB follows commit AB. On reserve AB, both enter private phase `after-reserve`.

- M_commit: in `after-reserve`, allow commit BC and suppress apply AB; after commit BC, permit all B-owned actions.
- M_release: in `after-reserve`, allow apply AB and suppress commit BC; after apply AB, permit all B-owned actions.

Their declared snapshot interface contains the same exact original inventory/bindings, stages, root identity and limit, original memberships, held bits, service policies, and static release rule: AB can apply/release only when BC is U or D. Private continuation choice is omitted by the candidate interface. The models have the same public interface both at initial empty state and after their common prefix:

`commit AB; reserve AB`

The cut has AB=W/held, BC=U/unheld, occupancy Q=1, and currently true AB service guard. It is a genuine prefix under the unchanged plant. No holder/debt difference is used.

From M_commit, the only enabled progress is commit BC. Then AB=W/held and BC=W/unheld. AB cannot apply because B waits on BC; BC cannot reserve the occupied Q. Neither can consume. No stage-changing suffix exists, so CanComplete is false already at the common cut (and at its initial product state). M_release instead applies AB, releasing Q, then admits the finite visible continuation `commit BC; reserve BC; apply BC; consume BC`, with `consume AB` placed whenever legal after apply AB. Both originals reach D. Thus CanComplete is true.

This attacks **the sufficiency of a snapshot plus static release dependencies**, not a claim that the exact continuation transition relation is insufficient. Naming the omitted monitor state in the static dependency graph would simply change the proposed interface into a behavioral one. The final packet should compare captured public states directly, not construct equality by rewriting exports.

Controls: shared-2, separate-1, or servicing B makes M_commit's delayed release completable. Under serial-B stable-ready, both reserve-first monitors are initially blocked: AB cannot reserve until BC=D, while the monitor suppresses BC commit until AB reserve. This is a useful explicit boundary: the 3C.2 all-state stable-ready theorem does not survive arbitrary additional continuation restrictions. It is not a contradiction of that theorem's original transition system.

A concrete witness can be built by lifting the projected legal progress prefixes with the existing old Lift routine, then filtering only the final progress actions with the new monitor. All preparation must leave the monitor unchanged. If this bridge is implemented, prove that its monitor uses only projected labels and that stuttering transport remains enabled. No old runtime inference follows. A pure abstract packet can omit this bridge and honestly remain a research-plant interface result.

## Chosen interface and conditional substitution target

Represent each monitor as a finite marked epsilon-NFA over the exact boundary alphabet. Export initial state, complete transition relation, accepting states, role signature, and the absence of private effects/shared writes. Define L_success(M) as visible finite words admitting a path with finitely many private tau steps from the initial monitor state to an accepting state. Do not put the answer CanComplete into the interface.

For a finite compatible context K (which can itself have private transitions), define its successful language in the same way. Under product synchronization on the complete shared visible alphabet and independent private steps:

`L_success(K || M) = L_success(K) intersection L_success(M)`.

Consequently, equal successful boundary languages yield equal **initial existential CanComplete** in every compatible K. This result is about the declared monitor interface and context grammar; it neither proves that a smaller constant-size contract exists nor reduces verification cost.

For the ALAN-specific packet, K is an unchanged fixed-chain capacity plant multiplied by a finite A/C continuation controller that can restrict only A/C-owned actions, plus optional pure observation bookkeeping. Grouping is parenthesization of this same synchronized product with disjoint private states and one shared root. All configurations must agree on fixed original bindings, owners, root identity/limit/membership and service/reservation policy. There are no extra private shared stores, timeout/cost observations, dynamic identities, revocation, or undisclosed readiness tests.

A general finite-product lemma may quantify over arbitrary alphabet-compatible K. State separately the narrower family actually instantiated as ALAN contexts. Necessity or full abstraction would require sufficiently expressive word testers; do not assert that the ALAN-admissible family supplies those testers without a proof.

This proof is a standard automata construction applied to a declared ALAN boundary, not a new general semantic theorem. The packet's research contribution is the precise boundary/factorization contract and retained ALAN counterexample. No new bibliography is necessary unless making literature claims; any added attribution must be checked against primary sources.

## Positive pair and nontrivial context roster

Use a fixed successful release-first protocol with two implementations:

- M_before executes private prepare bookkeeping before accepting reserve AB, then has the protocol's next boundary state.
- M_after accepts reserve AB first and executes the same private bookkeeping before enabling the next B-owned action.

External A/C events remain input-enabled in both; if bookkeeping remembers such events, its update must commute with those external observations. The simplest monitor keeps this bookkeeping independent of all plant state and allows external self-loops throughout. Both have a terminating private preparation path. Retain structurally distinct state graphs, compare their marked boundary languages exactly, and exhibit a nonempty successful trace in the core compatible context. They differ in private control, not just state numbering. Do not call this an optimization or claim cost equivalence.

Also retain a pair formed by taking a successful monitor and adding a nondeterministic tau branch into a nonaccepting sink that accepts external actions but blocks all B-owned actions. Its successful language can be unchanged while a reachable branch has no successful suffix. This is the explicit failure of the stronger assertion that language equality preserves every-reachable-state nonblocking. Internal divergence can similarly be added without changing finite successful language. Neither is covered by the positive theorem.

Qualification roster should remain small and declared before capture:

1. The 72 unchanged plant configurations, paired with the attack monitors and language-equivalent positive pair, starting at their genuine initial states.
2. A small fixed generated roster of A/C continuation controllers with bounded state counts: unrestricted, fixed-order, and one nondeterministic branch; enumerate all controllers only if grammar and bounds are explicitly frozen and practical. Do not call a hand-picked roster exhaustive arbitrary contexts.
3. Reachable product-state cuts with reset-to-current residual monitors, where useful. Check language equality of those *specific residuals* before applying the theorem there; initial language equality does not relate arbitrary post-history states.

Bounded contexts must contain both completable and noncompletable products. The whole point is to preserve the classification, not force every admitted context to complete. Include same positive-equivalent pair in a context whose service/capacity/continuation requirements block both. Never remove blocked contexts simply to make substitution checks trivial.

Exact epsilon-NFA language equivalence can be checked by epsilon closure and on-the-fly subset-product search for an acceptance mismatch. Report an actual distinguishing word on failure. Counting sampled traces or comparing finite prefix sets up to an arbitrary depth does not establish equality. The phase-progress alphabet bounds meaningful plant words, but the monitor equivalence algorithm must either cover its full declared language or clearly state plant-relative equivalence and prove its own substitution scope.

## Proof obligations before a positive claim

1. Role correctness: classify each old visible action by actual physical owner; M cannot veto external actions or introduce any transition absent from K.
2. Signature/resource consistency: product uses one Q; all exact memberships, bindings and limits match; join checks reject conflicting or missing records.
3. Observation fidelity: all existing named applications remain visible, including internal endpoints; value abstraction is inherited and stated. No claim about arbitrary payload or effect-result equivalence.
4. Private-step independence: tau neither changes shared holdings/debt/effects nor observes an unexposed variable; it cannot synchronously require a private step of the context.
5. Completion accounting: K and monitor success predicates jointly account for every declared debt; private nonacceptance is genuine unfinished continuation, not invented evidence of a capacity deadlock.
6. Product language equality: project each finite successful product path; conversely zip equal visible words while interleaving finite independent tau segments. Preserve final acceptance in both directions.
7. Substitution: equality of successful languages yields equal nonemptiness after context intersection. State explicitly that this quantifies initial pointed components or separately compared residuals.
8. Counterexample closure: enumerate all outgoing progress arcs from the trap product and reverse completion classification, not just a stalled selected trace. Validate positive suffix by legal adjacency.
9. Optional concrete bridge: old projection/lifting plus monitors that update only on labels; all transport preparation remains legal and cannot move the monitor. This is research-model correspondence only.
10. Refuse stronger conclusions: marked language equality need not preserve refusals, bad branching, fairness, divergence, inevitability, exact cost, or every-reachable-state completion. No automatic full-agent or production-runtime refinement.

## Three reviewable tasks

**Task 1 — freeze semantics, attack and candidate interface.** Write contract and source argument; add a new research package wrapping old K without editing historical model files; exact role/label signatures, two attack monitors, positive private-bookkeeping pair, product explorer and language-equivalence checker; capture genuine prefix/cut/suffix and complete adjacency. Freeze schema and roster. RED evidence is the false snapshot-substitution proposition and its explicit counterexample, not a deliberately left-failing repository test. Include nondeterministic badbranch control.

**Task 2 — independent relation and export audit.** A separate Python standard-library checker reconstructs the plant/product rules and monitor epsilon closure independently, verifies complete arcs and reverse CanComplete, recomputes language equivalence and witnesses, and checks actual common-prefix state equality. Hostile controls: missing non-tree arc, changed private gate, lost apply label, hidden reservation/holder update, copied root, forged accepting mark, mismatched binding, external-action veto, invented completion, malformed schema. If context grammar permits only external-input-enabled monitors, reject violations rather than quietly treating them as admitted contexts. Export exact producer/checker source hashes and commands. This audit cannot call Go operational predicates or trust producer labels/counts.

**Task 3 — scoped qualification and manuscript reconciliation.** Fresh affected ordinary/race tests, scoped Staticcheck, build/module checks according to repository commands. Reuse only explicitly source-identical historical baseline evidence where permitted; avoid re-running the 3C.2 million-case probes without a changed dependency. Reconcile Markdown, LaTeX, roadmap and PDF to the precise continuation-monitor theorem, optional concrete bridge scope, counterexample, successful-language limitations and unchanged open boundaries. Independent review must distinguish an argument from mechanized proof and fresh experiments from read historical records. Draft PR default; no merge authorization implied.

## Remaining design choices for parent

- Decide whether concrete transport lifts add enough value for this packet; the simplest theorem needs only the unchanged abstract plant, whereas a few genuine concrete histories can demonstrate compatibility without another million-case campaign.
- Freeze exact generated context grammar/bounds and monitor signature/schema before implementation. The general algebraic lemma and tested finite ALAN roster are different evidence categories.
- If the user's term component must mean a full replacement agent rather than a continuation controller over retained K, this is only an intermediate packet. A genuine ownership/factorization model for service, custody, cross-boundary observations and shared capacity would be additional work; do not rename the monitor result into that stronger claim.
