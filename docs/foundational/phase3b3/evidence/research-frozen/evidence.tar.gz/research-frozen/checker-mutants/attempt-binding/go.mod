module phase3b3-checker-mutant

go 1.27.3

require github.com/JakeFAU/alan-research v0.0.0
replace github.com/JakeFAU/alan-research => /Users/jacob/dev/personal/alan-research
