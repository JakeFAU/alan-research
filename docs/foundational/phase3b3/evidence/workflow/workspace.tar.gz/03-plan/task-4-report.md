# Phase 3B3 Task 4 implementation report

Status: implementation, full ordinary module verification, focused ordinary/race integration qualification, and Staticcheck complete. Parent independent review, source freeze/commit and final re-export remain required. No core primitive defect was found. No commit, baseline edit, core primitive edit, model edit, or subagent was made by this worker.

## Question and bounded result

Does the public retained runtime realize the two-principal A-servicing/B-serial reciprocal witness with genuine program-issued request-bound authority, original result custody, fresh physical gates and honest same-Store recovery? Both the ordinary and race 48-case corpora pass. This is a bounded tested implementation result under the frozen v3 contract, not an arbitrary-program or every-state progress theorem.

The actual tested service relation has two different actions: A serves BA at endpoint-B using B/ba-service; B serves AB at endpoint-A using B/ab-service. It is not literally the frozen model's same B/b action on both edges. Any model correspondence requires a declared whole-action abstraction. Separate grant retention plus ready handshake is a LateGrant subset, not atomic S2/Explicit. An authentic BA selection followed by ready selection before service is refused by the runtime's immediate-next-reduction requirement; the unchanged model permits that delay. This control is an explicit narrowing, not an invalid original request and not evidence of full model/runtime equivalence.

## Exact sources and interface

Runtime worktree: `/private/tmp/alan-phase3b3-runtime`, branch `codex/phase3b3-request-delegation`. Reviewed primitive source ancestor: `4f6f5f2`. Current tested HEAD: `347094a7b18d351c6ad18df526ef6133777bca44` (intervening commits are evidence/documentation). The eight new files remain untracked pending parent review/commit. Each case's `source.json` hashes all new fixture/qualification sources, including untracked files. Parent additionally froze all 304 Go/module inputs in `.superpowers/sdd/03-plan/task-4-source.json`; parent review diff is `task-4-review.diff`.

New files only:

- `examples/delegation/reciprocal.go`
- `examples/delegation/reciprocal_test.go`
- `internal/durabletest/phase3b3_runtime_test.go`
- `internal/durabletest/phase3b3_cuts_test.go`
- `internal/durabletest/phase3b3_controls_test.go`
- `internal/durabletest/phase3b3_temporal_test.go`
- `internal/durabletest/phase3b3_adapter_test.go`
- `internal/durabletest/phase3b3_mutations_test.go`

Public API:

```go
type Scenario string
const (
    S1Own Scenario = "s1-own"
    S2Handshake Scenario = "s2-handshake"
    S3Missing Scenario = "s3-missing"
    S3Claim Scenario = "s3-claim"
)
type Options struct {
    EndpointA, EndpointB string
    Scenario Scenario
    TerminalHandshake bool
}
type Manifest struct {
    Version string // alan/reciprocal-fixture/v1
    Options Options
    A, B runtime.RunID
    ABRequest, BARequest, Grant, Ready, BAService, BAReply, ABService, ABReply string
    BAServiceRoot, ABServiceRoot runtime.AuthorityRoot
    Claim runtime.DelegationClaim
}
func Reciprocal(Options) (runtime.Provision, Manifest, error)
```

Positive S2 locators are A1 AB request, B1 BA request, B2 grant, B5 ready, A4 BA service, A7 BA reply, B9 AB service, B12 AB reply. S1 has the same service/request/reply locators but `Manifest.Grant == ""`; two ordinary set reductions replace B's unused lifecycle emit/receive, so own-authority completion has no grant dependency or lifecycle result. No hidden broad A permission is present in S2. S3Missing retains the genuine B grant but omits A's selector; S3Claim retains the genuine grant but selects the actual request ID as GrantID. These are precisely labeled missing-selector and request-as-grant controls. Genuine absent-grant evidence is the pre-grant prefix of the separate late-grant control.

The fixture uses the public Artifact JSON route and local wire structs, without importing the executor AST. It has exactly a/1 and b/1, static roots, generation/revision 1, MaxEffects=1 and MaxInFlight=1 per serving root. Full positive defaults in tests use TerminalHandshake=true. Received values are bound from retained original receipts, and replies carry actual accepted/mutation/total/service_operation/request_id values. Terminal observation permission is exactly Kind=observation, Operation=terminal, source a, target b, revision1, obligation a-complete.

Test-only derived provisions implement temporal, identity, Cartesian, reversed-service and serial/serial controls; they are not additional public builder scenarios. Their actual modified code and manifests are exported. The revocation variant changes B's own service/reply to B12/B15; the actual-prior-result variant uses B7/B10 and A5/A8; Cartesian/generic A's service is A3. No controller writes authority rows or live permissions.

## Raw artifact schema and safe snapshots

`ALAN_PHASE3B3_EVIDENCE` selects an output root. `case-index.json` is a JSON array of explicit case records with Version, Name, Schedule, Directory, Classification, Manifest, optional Interpretation and Cut. Every record also has `case.json` in its own directory. Tests use separate unique directories, not inferred naming as identity.

Every indexed case has `provision.json`, `manifest.json`, exact `programs/<artifact-ID>.json`, `source.json`, and `digests.json` (SHA256 of all other case files). `source.json` contains HEAD, source SHA256 map, actual executable/test arguments, test name, Go version/GOOS/GOARCH, race-child setting and selected nonsecret toolchain/cache environment. Adapter cases additionally export immutable `deployment-adapters.json`.

Ordinary cases have separate Run outcome/report, raw and typed final inspections, all paged history and Replay report/outcome. Process cases additionally have initial/stopped/final snapshots, `first-owner` and `fresh-owner` Open/Run outcomes, all passive boundary JSONL events, acknowledged runtime/endpoint cut records, verified SIGKILL PID/wait/command, fresh-owner process exit, and stopped/final endpoint snapshots. The fresh owner's `post-open` directory contains the complete raw/typed/history/Replay snapshot **before Run**, plus coherent SQLite bytes from SQLite's online backup API. It is not a live-file copy. Run-state Open records are separate from Replay and Inspect outcomes.

Each `reciprocalCapture` operates on complete disposable copies including all existing WAL/SHM sidecars. Stopped/closed source bytes are copied into the archive after inspecting a different disposable copy. Archived originals are never opened with SQLite. Endpoint database files are archived only after verified process stop; endpoint JSON snapshots are read while the endpoint is live before that stop. All endpoint ingress/commit records are retained in passive JSONL journals. Endpoint contact count and application count remain separate.

For hostile-store mutations, raw `raw-tables.json` is exported using ordinary read-only SQL against a disposable copy without depending on runtime validation. Complete mutated SQLite bytes/sidecars, exact before/after descriptor bytes and SQL are retained. Inspect, InspectExecution, Replay and Open each receive separate complete disposable copies, and each rejection is recorded separately. No attempt is made to repair invalid stores.

## Corpus and real process cuts

Final ordinary root: `/tmp/alan-phase3b3-runtime-development/qualified-ordinary`.
Final race root: `/tmp/alan-phase3b3-runtime-development/qualified-race`.

The ordinary index contains **48 cases**:

- 4 ordinary S1/S2/missing-selector/request-as-grant paths.
- 15 public binding controls: removed original tuple; issuer generation/root/revision; recipient generation/root/revision; wrong request and request generation; service sequence/generation/resource; lifecycle-outcome-shaped GrantID; selected invalid grant despite available own permission; authentic BA selection followed by ready selection.
- 11 process-cut cases covering all ten requested labels and both unknown subcases.
- 4 physically meaningful Cartesian combinations.
- 3 retained-protocol revocation timings.
- 1 true absent-grant first refusal followed by accepted late grant and reopen.
- 1 actual prior B service-result laundering under reversed service ordering.
- 1 genuine serial/serial deadlock.
- 1 generic-adapter applied/unknown process recovery.
- 1 external applied/unknown followed by revocation before fresh-owner gate.
- 1 ordinary mutation-source run and 5 rejected disposable-history mutants.

Observed final A4 gate/contact/application counts for the ordinary process corpus:

| Case | Actual acknowledged boundary | A4 gates | endpoint-B contacts | applications |
|---|---|---:|---:|---:|
| 01 before grant | execution.staged/pre-commit B2 | 1 | 1 | 1 |
| 02 retained grant | lifecycle.decided/accepted B2 | 1 | 1 | 1 |
| 03 before service authorization | execution.committed/post-commit A4 | 1 | 1 | 1 |
| 04 complete decision | dispatch.consider/pre-admission A4 | 1 | 1 | 1 |
| 05 before physical admission | dispatch.consider/pre-admission A4 | 1 | 1 | 1 |
| 06a admitted/no contact | dispatch.admitted/pre-call A4, ordinal1 | 2 | 1 | 1 |
| 06b applied/no local receipt | independent resource.applied/post-commit plus runtime waiting | 2 | 2 | 1 |
| 07 retained result | external.result-recorded/pre-settlement A4 | 1 | 1 | 1 |
| 08 before selection | external.settled/post-record A4 | 1 | 1 | 1 |
| 09 mutual waits | runner.waiting/in-flight plus independently held applied A4 | 2 | 2 | 1 |
| 10 A complete/B pending | execution.committed/terminal A10 | 1 | 1 | 1 |

Rows 04 and 05 deliberately share the same real boundary; no new passive hook or scheduler was introduced. Row01 stopped committed history contains B1, not the uncommitted staged B2. Row02 has the accepted retained grant but not B3's selection. Row03 has the service intent without source authorization/attempt. Rows04/05 have allowed source/authority/reservation plus the serving-root debit but no gate. Row06a has an allowed gate and zero contact before kill; row06b has actual independent endpoint application with no runtime receipt. Row09 independently checks A at receipt receive (sequence4/PC4), B at BA reply receive (sequence5/PC5), both unpaid, and A4 unknown. This is service waiting, not the serial/serial deadlock control. Row10 has both original requester selections complete, A terminal, B awaiting the remaining terminal observation.

Open runs renew epoch; completed A in row10 does not. Request.Epoch remains the epoch of original attempt creation. In rows04–09 it is2; fresh gates where needed use epoch3 and increasing ordinal. In rows01–03 the original attempt first exists after reopen and has Request.Epoch3. No attempt/wire/key is rewritten by recovery. There is one original grant and one effect charge for each allowed original; every raw capture independently checks one Effects=1 charge attributed to the actual serving run's root and zero charge for refusals. Known-result recovery adds no gate/contact. Every success assertion joins full logical run (subject AND generation), original request and its history selection, immediate next effect, original retained receipt and server's history selection, actual reply operation and requester admission/history selection. Opaque receipt fields are compared against the independent endpoint receipt, not only paid flags.

## Temporal, Cartesian and adversarial findings

Revocation is a real B7 RevokeAuthority instruction with its own result selected by B. The controller uses only existing public AdmitInput/Snapshot/Commit/AuthorizeIntent/LoadLifecycleRequest/DecideLifecycle/SettleLifecycle on that fixed program-produced suffix. The controlled timing is labeled separately from automatic Run:

- Before gate: an immutable allowed reservation/debit survives, the fresh gate refuses, and no endpoint contact occurs.
- After allowed admission: the `authority.admission/allowed` callback is outside the writer lock but before worker release; controlled B revocation then occurs, and that already admitted opportunity applies. B's unrelated own-root AB service still completes with its distinct tuple.
- After retained result: revocation precedes settlement/selection, and original result custody completes with no new A gate/contact. B's unrelated tuple remains usable.
- Applied unknown plus reopen: endpoint applied once, runtime had no result when killed; fresh owner selects real B revoke, then A's second/current-epoch gate refuses. One old application/contact remains, no result or reply is invented, the original attempt/debit is unchanged, and RunReport.UnknownExternal retains A4.

The late-grant control starts with **no lifecycle grant result**. A's first original effect decision refuses. A remains open on an explicit hold; later B's program issues an accepted grant. Reopen and later Run leave the exact original attempt refused, with zero gates/contacts. This is not the same as the S3 missing-selector control.

The actual result-laundering control reverses service order: B7 applies, B selects its receipt and emits B10's authentic result-bearing AB reply; A selects it at sequence3, then selects BA and emits A5 with GrantID=B7. B7 names an actually retained original external result, not a nonexistent prediction. A5 refuses; endpoint-A has one legitimate contact/application, endpoint-B zero. This policy differs from positive A-servicing/B-serial and is explicitly labeled.

Cartesian deployment maps R1/R2 to separate immutable endpoints. `effects.Request.Effect` add-one fixes wire Delta1; add-ten fixes Delta10. The declared input is deliberately delta999, which cannot override those trusted operation semantics. Both legitimate pairs apply their distinct totals, with selected grant witness, gate, retained adapter result and exact result selection. Both cross-pairs fail at grant issuance, with no effect/gate/charge/contact. This is not obligation relabeling over an unconditional same-operation adapter.

Generic adapter recovery is separately qualified: an actual application occurs while response is held, then SIGKILL prevents local adapter_result retention. Fresh owner reports the same A3 in UnknownAdapters, zero new Dispatches, one original charge/gate/contact/application, and no result/settlement/selection. Stable endpoint deduplication does not change generic no-retry policy.

Five hostile copies delete the grant, alter grant origin, substitute the selected effect's grant with an actual other result operation, alter a primary admission AttemptDigest (recomputing its record digest), or substitute the retained receipt key. All four public readers reject each. These are evidence/consistency rejection tests; they are not the independent research authority checker, which remains Task3. The immediate-selection control is a model-valid delayed-selection/runtime-refusal narrowing and is separately annotated in its case record.

## Commands and observed verification

All Go commands ran from `/private/tmp/alan-phase3b3-runtime` with:

```sh
GOTOOLCHAIN=local GOCACHE=/tmp/alan-phase3a-go-build GOPROXY=off GOSUMDB=off
```

Toolchain: go1.27.3 darwin/arm64. Loopback/process tests ran with authorized sandbox escalation. Staticcheck used `STATICCHECK_CACHE=/tmp/alan-phase3b3-staticcheck`. No go vet command was used.

1. `go test ./examples/delegation -run TestReciprocalProvision -count=1`: initial RED for missing fixture API retained in `fixture-red.log`; then passed after implementation. An initial default-cache attempt was sandbox-denied and not counted as a semantic failure.
2. An added S1 independence assertion failed before correction (`s1-independent-red.log`: own path unnecessarily requires delegation), then `go test ./examples/delegation -count=1` passed after S1 removed the unused grant dependency.
3. `staticcheck -tags=integration ./examples/delegation ./internal/durabletest`: passed, exit0, empty `staticcheck-final.log`.
4. `go test -tags=integration ./internal/durabletest -run '^TestPhase3B3(Reciprocal|CartesianOperations|GenericUnknown|ActualResultLaundering|SerialSerial|AppliedUnknownRevoked|RetainedMutations)' -count=1 -v`: passed, exit0, 48 indexed cases, `qualified-ordinary.log`; package elapsed21.063s. No selected tests skip.
5. Same command with `-race`: passed, exit0, 48 indexed cases, `qualified-race.log`; package elapsed129.224s. No races or selected-test skips.
6. `ALAN_PHASE3B3_OLD_READER=/tmp/alan-phase3b3-old-reader/alan go test -count=1 ./...`: passed, exit0, `full-module.log`; all ordinary module packages. This was not the whole integration-tagged module suite.
7. `git diff --check`: exit0 (new files still untracked); focused Staticcheck and gofmt covered all new sources.

Development failures are retained, not represented as runtime defects: initial sandbox denied loopback listening; `cuts.log` used a legacy exact filter comparator incorrectly on wildcard filters; `cuts-v2.log`/directory encountered test-only observer recursion when no inherited hook existed (identified processes stopped, no pass claimed); `temporal.log` omitted explicit local input routes and then used a worker callback unsuitable for fatal helper errors. Corrected controls use declared routes and synchronous post-commit admission callback. Subsequent `cuts-v3`, `temporal-v2`, `adapters`, `extra`, `revoked-unknown`, `mutations` and `final-ordinary` development runs passed, but the final qualified roots supersede them because later assertions/export fields changed. No test was weakened to obtain a green result; controller inaccuracies were corrected and stricter custody/accounting assertions added.

## Limits and remaining ownership

- Task4 fixtures create profile13. Profile14/conflict promotion remains covered by the separately reviewed Task2 evidence, not newly claimed process qualification here.
- The ordinary 48-case corpus and ten requested labels do not enumerate all reachable runtime schedules. Open renews both open roots in the same Store; independent-owner/distributed recovery is not established.
- Primary gate records prove retained local opportunity. Independent endpoint/boundary traces support contact/application claims. Unsigned Store-only evidence cannot prove omitted/fabricated exposure completeness or unique returning-exposure attribution; repeated immutable requests do not carry gate ordinal on the wire.
- Exact one application in these traces depends on trusted atomic stable-key idempotent endpoint behavior and eventual successful response when authority permits. It does not prove zero duplicate contacts, arbitrary adapters, or general exactly-once effects.
- Unknown after revocation and generic adapter unknown are explicit completion obstructions. They must not be hidden as atomic model Apply, synthetic failure/success or harmless stuttering.
- Parent owns independent review, Task3 raw checker/model differential classification, manuscript reconciliation, source commit and final frozen re-export. This worker has not independently approved the implementation or claimed manuscript consistency. No substantive production runtime change was needed for Task4.

## Final verification addendum

The final race command completed successfully, exit0, package elapsed129.224s (`qualified-race.log`). It executed the same **48 indexed cases**, with race-built endpoint and runtime children (`RaceChildren=true`), and no race reports or selected-test skips. Both final case indexes contain all 48 cases. Full ordinary module testing and focused Staticcheck also exited0 as recorded above.

Post-run verification reads only JSON/filesystem bytes, never archived SQLite databases. It verified all **1,761 files in each corpus** against per-case SHA256 manifests and every recorded fixture/qualification source digest against current source: zero mismatches in both ordinary and race corpora. Machine-readable results are `/tmp/alan-phase3b3-runtime-development/verification-summary.json`.

Final worker status: **implemented and tested; ready for parent independent review**. The eight new files remain uncommitted. Parent should treat both final qualification directories as development-source evidence, preserve the failed controller runs separately, and regenerate after the reviewed source is committed/frozen. The concrete remaining obligations are independent review, the independent raw checker/model classification, and manuscript reconciliation/final evidence packaging, all owned by the parent/later tasks.
