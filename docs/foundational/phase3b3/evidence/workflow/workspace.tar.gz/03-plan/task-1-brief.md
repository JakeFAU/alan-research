## Task 1: Current-runtime realization attempt

**Files:** runtime `examples/delegation/baseline.go`, its focused test, and
`internal/durabletest/phase3b3_baseline_test.go`; research evidence and gap notes.

**Interfaces:** A public `Baseline(scenario BaselineScenario) (runtime.Provision,
error)` builds two ordinary authored roots. Scenarios are `local`, `missing`,
`claim`, `cartesian`, and `result_launder`. Fixed capability identifiers encode
concrete resource/scope tuples; adapters are supplied separately by the caller.
Tests export raw provision, inspections, Replay outcomes, selected original
result custody and independent endpoint evidence under `ALAN_PHASE3B3_EVIDENCE`.

- [ ] Build the smallest ordinary public-API reciprocal fixture with A servicing and B serial; no production edits or broad A permission in S2 attempts.
- [ ] Run S1 and missing/claim/Cartesian/result-laundering attempts on the unchanged public runtime; retain the genuine refused permission decision and zero unauthorized contacts.
- [ ] Demonstrate that the desired current-API S2 completion assertion fails for the expected authority reason, with a passing S1 apparatus control.
- [ ] Review the fixture and preserved negative evidence before relying on it.

