## Purpose and result

Complete Phase 3B.3: test whether the two-agent authority contract can be realized by ordinary retained public-runtime programs. The bounded realization succeeds under an additional immediate-request-selection condition. A genuine accepted grant plus an earlier authentic request selection and intervening readiness selection produces a runtime refusal where the unchanged LateGrant model permits authorization. That counterexample remains a reported mismatch; expected outcomes do not turn it into agreement.

Companion runtime PR: [JakeFAU/alan#10](https://github.com/JakeFAU/alan/pull/10).

## Scope and contract

Base: `8197683c23a3ca774750fc3c2c389c5a64dd38b8`. Final executable research source: `7894bfae268e6dc0f5418bda3c6022f3a8a55540`. Later commits contain evidence and manuscript/delivery records.

- Add the research-only `research/delegationcorrespondence` package: independent raw-policy/custody/owner checker, selected model corpus, explicit projection boundaries, exhaustive finite progress queries and four CLIs.
- Retain the verified existing-API obstruction, versioned contract, rejected candidates, original review findings, raw witnesses, correction evidence and frozen qualification.
- Reconcile Markdown/LaTeX Abstract, conclusion and Phase 3B.3 section; rebuild and inspect the 39-page PDF. BibTeX is unchanged.
- All 563 pre-existing Go/module inputs and all four prior deterministic model/audit exports remain byte-identical. No research runtime implementation, scheduler, accounting or dependency changes.

Governing invariant: a service uses the exact original request, recipient, operation and complete permission tuple; recovery preserves the logical grant and original decision/debit but requires a fresh current-owner admission on the same selected path. Result custody, physical contact and endpoint application are separate facts. Unknown outcomes, refusals and unsupported projections remain visible.

## Adversarial evidence and review

Preserve the old-API S2 completion RED, impossible literal-root encoding, primitive legacy/binding rejections, five checker false acceptances and their exact corrections. Both independent Task 3 reviews approve the corrected slice; the final whole-change specification, quality and overall verdicts are APPROVE within the declared scope, retained in `docs/foundational/phase3b3/evidence/final-review/`.

Fifteen raw mutation controls reject. Four checker-source mutations fail actual assertions. Each ordinary/race runtime corpus contains 48 cases, 117 captured phases and 1,761 verified digests: 43 raw-valid histories, five hostile rejections and the sole named selection-order mismatch. Raw checking imports no runtime/executor/authorization/Replay/SQLite implementation.

## Verification actually executed

The complete 42-command record, environments, statuses and log digests are in `docs/foundational/phase3b3/evidence/research-frozen/commands.json`; all statuses match their declarations. Fourteen deliberately return nonzero (seven prior model REDs, two unqualified corpus verdicts, four killed checker-source mutants and inherited lint).

```sh
ALAN_TASK3_RAW=/tmp/alan-phase3b3-runtime-frozen/normal ALAN_TASK3_PROGRESS=1 go test -json -count=1 -timeout=60m ./...
ALAN_TASK3_RAW=/tmp/alan-phase3b3-runtime-frozen/race ALAN_TASK3_PROGRESS=1 go test -json -race -count=1 ./research/twoagent/... ./research/mutualobligations/... ./research/authorityservice/... ./research/delegationcorrespondence/...
go test -json -tags=integration -count=1 ./examples/communication/mutual
go test -json -race -tags=integration -count=1 ./examples/communication/mutual
go test -json -tags=integration -count=1 ./internal/durabletest -run '^TestPhase3B2'
go test -json -race -tags=integration -count=1 ./internal/durabletest -run '^TestPhase3B2'
staticcheck -tags=integration ./research/twoagent/... ./research/mutualobligations/... ./research/authorityservice/... ./research/delegationcorrespondence/... ./examples/communication/authority ./examples/communication/mutual
staticcheck ./internal/durabletest
staticcheck -tags=integration ./internal/durabletest
gofmt -l research/delegationcorrespondence
```

Full ordinary suite: 2,382 passing test/subtest events in 48 packages; three unrelated opt-in artifact-export tests skipped, fourteen packages have no tests. Model/checker race: 303 events, no named skips. Prior reciprocal integration: 22 events per ordinary/race run; prior authority: 20 each. Scoped lint is clean; the six existing durable integration diagnostics are byte-identical to baseline, so whole-research integration lint is **not** clean.

Four prior exports compare byte-for-byte. New corpus has 22 cases/eight classes. LateGrant/Revocable exhaustive queries cover 111,065/220,564 states with exact stated predicates and audited longest witnesses. `tectonic --keep-logs alan-dissertation.tex`, the scoped manuscript normalization checker and visual inspection of changed PDF pages completed; no new layout warning. All 1,375 final research archive members were hash-verified.

## Limits and delivery

No universal runtime refinement, independent-owner recovery, arbitrary-program compiler proof, multihop delegation or N-agent closure theorem. The raw exports are unsigned internal-consistency evidence. Whole-process crash mapping, separate-grant revocation and repeated/unknown-result chronology have explicit unsupported model domains. Two controls lack an initial pre-Open capture. The mutation generator requires the complete positive parent and can panic with exit 2 on an incomplete raw-valid prefix; the diagnostic probe and limit are retained.

This is one cohesive research packet. Unrelated changes are absent. Source/evidence/delivery identities are distinct. Draft only; no merge or release.

