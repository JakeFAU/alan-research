## Task 2: Freeze and implement the minimal authority protocol

**Files:** runtime new `internal/executor/request_authority.go`,
`request_authority_admission.go` and focused `request_authority*_test.go`;
existing program/lifecycle/effect/dispatch/composition/format/replay/inspection
integration files listed exactly in contract section7; public aliases in
`runtime/runtime.go` and `runtime/inspection.go`. The three baseline files stay
unchanged. No research production executor changes.

**Interfaces:** Exact public types/fields are frozen in contract sections1–4:
`CompositionProvision.RequestAuthority`, `RequestAuthorityVersion`,
`AuthorityRoot`, `DelegationClaim`, `RevocationClaim`, `AuthorityUse`,
`AuthorityDecision`, `EffectAuthority`, `AuthorityAdmission`; optional
`Effect.Authority`/`Intent.Authority`, lifecycle and effect witness fields.
Authority control uses committed lifecycle operations `DelegateAuthority` and
`RevokeAuthority`, never a host-only grant method. Primary gate facts use kind
`authority_admission`, the existing composition order and exact identities in
section4. Formats13/14 are opt-in; no new table. Expose typed accepted/refused
control and gate evidence through public inspection. Internal helper names may
follow existing package conventions; their policy must implement the frozen
checks, not redefine the contract.

- [ ] Add focused `TestRequestAuthority*` failures for real delegated permission, missing/wrong root, full-tuple mismatch, exact request/generation/next-reduction binding, first refusal and revocation-before-admission. Retain failing commands before implementing the corresponding production path.
- [ ] Add `TestRequestAuthorityFormats*` for old schemas3–12, unsupported feature combinations, version13 creation and14 conflict promotion, and rejection by the frozen old reader.
- [ ] Prove a positive ordinary two-agent Run in focused tests, while using direct public/owned transitions only for deliberately controlled adverse schedules; no alternate scheduler implementation.
- [x] Resolve builder findings and freeze exact representations, boundaries, versioning and scope in `02-contract.md` before production edits.
- [ ] Record precise file/API interfaces in this plan from that freeze; implement through retained ordinary control decisions and existing effect authorization/admission.
- [ ] Attack tuple mixing, source ancestry, original binding, sticky refusal, revocation timing, owner activation and malformed storage first.
- [ ] Qualify unchanged old-format behavior and explicit new-format validation; no speculative migration or framework expansion.
- [ ] Independent authority/minimality and attenuation/request-binding review; correct and re-review substantive findings.


Contract correction before production: use frozen version2, exact RootRun/RecipientRoot logical locators and derived IDs in retained witnesses. Read evidence/contract-v2-review.md for required locator falsifiers. The originally RED literal-ID source/log are preserved in runtime docs/qualification/phase3b3/rejected-literal-root; replace its active test with an accurate expected-rejection regression and add positive two-Store locator construction. No root/tuple validity requirement was relaxed.

Contract v3 supersedes the v2 legacy-name and direct-dispatch wording only: preserve historically inert unknown lifecycle names outside opt-in (no authority interpretation), continue rejecting all typed new authority metadata, and preserve existing composition DispatchExternal refusal while gating every supported physical route. Read evidence/contract-v3-review.md and rejected-contract-v2 reviews; all implementation findings remainopen until corrected/re-reviewed.
