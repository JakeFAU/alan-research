import os,pathlib,json,subprocess,time,hashlib
cwd=pathlib.Path('/Users/jacob/dev/personal/alan-research');out=pathlib.Path('/tmp/alan-phase3b3-task3-evidence/fix-round1');out.mkdir(exist_ok=True);root=pathlib.Path('/tmp/alan-phase3b3-runtime-frozen/normal');entries=json.loads((root/'case-index.json').read_text());invalid={'mutation-missing-grant','mutation-forged-grant-origin','mutation-effect-use-result','mutation-gate-attempt-digest','mutation-result-link'}
expect={x['Name']:{'RawValid':x['Name'] not in invalid,'Mismatch':'immediate_selection_narrows_model_admission' if x['Name']=='control-wrong-prior-selection' else ''}for x in entries};(out/'expectations.json').write_text(json.dumps(expect,indent=2)+'\n')
env=os.environ.copy();env.update(GOTOOLCHAIN='local',GOCACHE='/tmp/alan-phase3b3-task3-build',GOPROXY='off',GOSUMDB='off',STATICCHECK_CACHE='/tmp/alan-phase3b3-task3-staticcheck');commands=[]
def run(name,args,extra={},want=0):
 e=env.copy();e.update(extra);start=time.monotonic()
 with (out/(name+'.json' if name in ['model-corpus','progress','raw-mutations','normal-unqualified','normal-expected','race-unqualified','race-expected'] else name+'.log')).open('wb') as f, (out/(name+'.stderr')).open('wb') as err:p=subprocess.run(args,cwd=cwd,env=e,stdout=f,stderr=err)
 commands.append({'Name':name,'Args':args,'Environment':{k:e[k] for k in ['GOTOOLCHAIN','GOCACHE','GOPROXY','GOSUMDB','STATICCHECK_CACHE']},'ExtraEnvironment':extra,'Exit':p.returncode,'ExpectedExit':want,'ElapsedSeconds':round(time.monotonic()-start,3)})
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,p.returncode,flush=True)
run('normal-tests',['go','test','./research/delegationcorrespondence/...','-count=1','-v'],{'ALAN_TASK3_RAW':str(root),'ALAN_TASK3_PROGRESS':'1'})
run('race-tests',['go','test','-race','./research/delegationcorrespondence/...','-count=1','-v'],{'ALAN_TASK3_RAW':'/tmp/alan-phase3b3-runtime-frozen/race','ALAN_TASK3_PROGRESS':'1'})
run('staticcheck',['staticcheck','./research/delegationcorrespondence/...'])
run('raw-mutations',['go','run','./research/delegationcorrespondence/cmd/mutations','research/delegationcorrespondence/testdata/positive.json'])
run('build-check',['go','build','-buildvcs=false','-o',str(out/'check'),'./research/delegationcorrespondence/cmd/check'])
for label in ['normal','race']:
 args=[str(out/'check'),'-root','/tmp/alan-phase3b3-runtime-frozen/'+label]
 run(label+'-unqualified',args,want=1)
 run(label+'-expected',args+['-expect',str(out/'expectations.json')])

run('review-request-route',[str(out/'check'),'-input',str(out/'review-originals/missing-request-route.json')],want=1)
run('review-continuity',['go','run',str(out/'probes/continuity.go')])
run('review-epoch',['go','run',str(out/'probes/epoch.go')])
