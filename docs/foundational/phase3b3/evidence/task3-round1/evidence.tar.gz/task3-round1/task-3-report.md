# Phase 3B.3 Task 3 — independent raw correspondence checker

Status: implementation complete; final qualification includes both parent P2 corrections and four causal-selection controls. Parent independent source review, frozen whole-module regression, archive packaging and manuscript reconciliation remain parent-owned. No commit, subagent, model/runtime edit or SQLite API open was performed by this worker. Filesystem reads/copies/hash verification of immutable exported bytes are distinct from opening archives through SQLite.

## Question and bounded result

Can independent retained-evidence checking justify the actual request-bound delegation and original result custody in the frozen public runtime fixture, while preserving model mismatches and progress obstructions?

The new research-only package independently checks the actual fixed generation-one two-static-root profile13 corpus. Its raw authority/custody verdict is separate from runtime Run/Replay/Open/Inspect outcomes and from model projection. It checks every supplied captured prefix, including the hostile sparse Tables-only export. No invalid or difficult raw-history case is diverted to an unsupported model verdict as a substitute for raw checking.

The positive generated trace has both originals outstanding and actual BA Delegated authority. Raw ordinary S2 yields a 21-event retained logical service trace accepted by the unchanged model ledger; own-root S1 yields 20 events. This is a bounded trace comparison with explicit action/result abstraction. It is not permission-algebra equivalence, forward refinement, a full process-recovery correspondence, or an all-runtime-state completion theorem.

The genuine delayed-selection witness retains `immediate_selection_narrows_model_admission`: actual valid runtime refusal after BA selection then ready selection, versus unchanged LateGrant allowed delegated authorization. Explicit expectations never relabel that mismatch as agreement. Rejected grants, malformed selectors, reverse service order, separate-grant revocation, repeated exposures, unknown receipt prefixes and unproved shared-process crash expansion are separately unsupported mapping domains.

## Exact source and evidence identity

- Research source base: `31c8af68e818f97a842e790669fbc8f8c98dc8bd`; new files were uncommitted while this worker qualified them. HEAD alone does not identify the new checker.
- Frozen runtime source: `759df6e3d2505f27e1287b2cfeb07bc4290afc0a`.
- Immutable normal raw root: `/tmp/alan-phase3b3-runtime-frozen/normal`.
- Immutable race raw root: `/tmp/alan-phase3b3-runtime-frozen/race`.
- Final exact command records, source hashes and outputs: `/tmp/alan-phase3b3-task3-evidence/final/`.
- Full development RED/failure history: `/tmp/alan-phase3b3-task3-evidence/`, including retained earlier qualification attempts under `pre-sparse`, `pre-terminal-routes`, `pre-policy-edge`, `pre-current-subject`, and `pre-observation-prefix`.
- Committed-in-candidate positive fixture is the actual frozen ordinary S2 raw JSON. SHA256: `e371654a8b8b9def3ab6f29edfd067c7bc418f7c9e58a72da23fed2ff8296d18`.
- Frozen v3 contract SHA256: `f19d9c13f84c17496fabef91cb7575cf52972ff228c0b69e063cdc1c99100e12`.
- Unchanged model SHA256: model.go `11ec7401ade2c4b5b942b70929cc5df8a8f47da4d072a0b5d980b86e19034dbe`; explore.go `3916f87834709dcd7c0d55b2470daf6317fb9ab2ac637a01bcc0723a7eb0e26e`; oracle.go `06bbe53e48084a61b3b16fec8a1f096a4e35e3bb607fc58a678ea2f33f6b01dd`; oracle_corpus.go `5bffdacf8f305cd0e1877ed0142396bf7eb66457cd2828d80212310be79eb49d`.

`source.json` binds all 22 new source/fixture/README files separately from those source bases. Its SHA256 is `9ca9c230e7ebbe3185474fc5a52db07fda36af0a764f006733032bbe9d5477c6`; the qualified checker binary SHA256 is `71ec2d01b3c421550b918dbec06db2e87732010a6eb626cf9649d9465b22e55f`. `commands.json` records exact argv, environment, expected and observed exits and elapsed time. `verification-summary.json` confirms all 14 command exits match expectations, source hashes remain stable and final normal/race test event counts are 41/41 with zero skips. `manifest.json` digests the final evidence files, including complete causal controls and checker-mutant source copies. Final delivery archive/commit identities belong to the parent and must not replace executable/source/input identities.

## New files and callable interfaces

Apart from this task report, only `research/delegationcorrespondence/` repository files were authored by this worker:

- `wire.go`, `schema.go`: own exact-integer DTOs, recursive duplicate-key checks, canonical descriptor handling, closed raw schema/index checks and terminal obligations.
- `check.go`: original deployment/permissions/member roots, ordered fact reconstruction, independent lifecycle/first-effect/fresh-gate policy and serving-root accounting.
- `custody.go`: independent five-instruction slice, causal-prefix observation availability and actual request/result/settlement/reply/selection joins.
- `external.go`: endpoint contact/application reconciliation, declared trusted fixed adapter boundary, ordinal-bearing local boundary evidence, Open/post-open epoch joins and immutable-prefix continuity.
- `corpus.go`, `mutations.go`, `project.go`, `progress.go`: model histories, full retained-input mutations, raw-driven event projection and independent exhaustive progress query.
- `files.go`, `cli.go`, four command packages (`check`, `corpus`, `progress`, `mutations`), focused tests, `README.md`, and exact `testdata/positive.json`.

Public entry points are `CheckRaw([]byte) RawVerdict`, `CheckExternal([]byte,map[string][]byte) ExternalReport`, `CheckContinuity`, `CheckCorpus(root,originalPrefix)`, `ProjectRaw`, `GenerateCorpus`, `RawMutations`, `QueryProgress`, and `RunCheck`. None calls runtime authorization, Replay, a production reducer or SQLite. Model functions are used only by generator/projection/progress, never while evaluating raw authority. Dependency inspection lists only stdlib and the unchanged authorityservice/mutualobligations research packages; no public runtime or database dependency enters this package's dependency graph.

## What the independent checks establish

1. Exact raw input SHA256, canonical original descriptors, primary keys, run/generation/sequence/ordinal agreement, tagged scalar values and complete original/current identity/permission sets. Sparse hostile exports omit known zero-row tables; their absence is interpreted as zero exported rows, never filled from model expectations. Unknown tables/columns remain errors.
2. Original static root membership independently of namespace-derived candidate hashes. Actual committed lifecycle emitter, original complete tuple, source revision, recipient logical run/revision/root, exact original message and future ordinal-zero service locator determine grant/refusal. Grants never insert an A permission.
3. Mirrored facts are reconstructed from source rows and checked in both directions. First effect authority is derived at its original ordered prefix; original source authorization, nested permission witness and resource reservation are distinct. Refusal is sticky and never falls back to an unselected alternative.
4. Fresh primary gates require an original allowed reservation/debit, exact immutable attempt digest, current source state and historical activation bounds, same selected path and contiguous original-local ordinal. Revocation is interpreted at the earlier prefix, so old allowed results survive later revocation while fresh exposure refuses.
5. Original serving-root debit is exactly once. Grant issuance/revoke/gate/reopen do not create or refund a second charge. Terminal rows and exact original permission-derived destination obligations are preserved separately from service payment.
6. The independent finite instruction interpreter checks the real retained source instruction against each actual history reduction. It checks `emit`, `receive`, `branch`, `set`, `end`, literal/reference expressions, selected observations, emitted control metadata and complete successor data. This is a checked fixture slice, not a general reducer/compiler proof.
7. Custody joins authenticate actual original message admission/selection, service operation, retained result, settlement/server selection, result-bearing reply and same-generation caller selection. Equal numerical result values do not substitute originals. Selection also requires retained causal predecessors in the actual composition prefix: message source authorization, lifecycle decision, effect reservation and allowed result fact, or terminal source history. Final observation existence is insufficient. No global admission timestamp is invented; local inputs remain external input assumptions without a source composition fact. Both consumed originals, rather than terminal/ready/lifecycle markers, determine `Custody.Complete`.
8. Independent endpoint ingress bytes match immutable original wire/prepared request; committed applications and retained receipts/adapter responses agree. Contacts and unique applications remain distinct. The immutable wire's Epoch is original authorization epoch; fresh gate epoch comes from primary records and owner snapshots. Returning ordinal claims use actual local result-boundary evidence, not an invented retained result field.

## Corpus and model/progress outputs

For each frozen normal/race root the final corrected pipeline verified 48 cases, 117 raw captured phases and all 1,761 digested files. It found 43 valid final raw histories and exactly five hostile rejections. Each root preserves the sole named selection-narrowing mismatch and no projection apparatus `Error`. Raw validity is never replaced by unsupported projection.

| Actual hostile history | Independent first failed edge |
| --- | --- |
| Deleted retained grant | `lifecycle_settlement` — settlement names missing original lifecycle result |
| Forged grant source | `lifecycle_origin` |
| External selection substituted with actual result operation | `reservation` — immutable attempt/reservation disagreement |
| Rehashed primary gate with altered attempt digest | `gate_attempt_digest` |
| Receipt key substitution | `result_original` |

The eight model classifications contain 22 new selected/generated cases: four complete value pairs, one completable prefix with explicit suffix, one authority-blocked history, four missing-authority controls, three scope controls, six request/generation controls, one revoked-admission control and two causal-order controls. All unchanged 33-history/four-chain controls are retained in `Prior`. Protocol-valid but explicit-consent-unsafe S3/Cartesian cases remain so labeled; their first policy-unsafe prefix is reported without pretending protocol invalidity.

Fourteen checker-input mutations retain complete mutated JSON, original/mutated hashes, exact changed-cell references, original IDs and first failed edges: missing/forged grant, recipient/root/service/resource/request/generation alterations, reuse/result-as-authority, equal-payload key substitution, gate-before-reservation, stale activation and altered attempt digest. Witness/hash mirrors are recomputed where relevant so many failures reach policy instead of merely checksum mismatch. Exact original and mutated runtime-negative snapshot/row bytes are additionally retained in `runtime-mutation-parents-normal.json` and `runtime-mutation-parents-race.json`, resolving actual SourceCase references explicitly; deleted-grant original bytes are taken from that original raw export, not reconstructed from the desired claim.

The independent new progress query uses unchanged Initial/Successors, every reachable state/arc, safe reverse BFS and an audited actual completion suffix:

| Frozen configuration | States / arcs | Safe-completable | Exact-predicate mismatches | Longest shortest suffix |
| --- | ---: | ---: | ---: | ---: |
| S2/LateGrant | 111,065 / 840,616 | 107,213 | 0 | 23 |
| S2/Revocable | 220,564 / 1,740,832 | 193,681 | 0 | 22 |

LateGrant exact condition is no permanent BA first refusal (all reachable states are safe). Its 3,852 excluded states split into 1,926 without and 1,926 with a retained late grant. The set is not forward invariant: early first refusal can leave it. Revocable's exact condition checks both originals: no first refusal and, if revoked, already-applied or a surviving permit. The weaker no-BA-refusal condition has 22,887 noncompletable states. Unconditional completion and that weaker revocable condition are retained adverse controls. These are existential bounded graph facts, not fairness or runtime scheduling theorems. The old sixteen graph results remain untouched; this worker did not claim the new queries replace their full old export/audit regressions.

## Projection boundaries and retained mismatch

The sole named mismatch is the actual wrong-prior-selection witness. The raw checker finds a genuine previously selected BA request, exact accepted grant, no revocation and immediate predecessor ready selection; runtime refuses `authority_request_not_admitted`. The generated model witness allows Delegated authorization. Both originals remain unpaid. Quiescence/open state and service payment are separate outputs.

Malformed selected grants, despite a legitimate different grant or own alternative, are unsupported selector controls rather than variants of that named mismatch. The reverse-service result-laundering fixture genuinely serves AB first; its AB Apply is outside the frozen A-servicing/B-serial policy. The checker preserves its actual result provenance/refusal without inventing a model edge.

Nonrevoking final S2 maps two actual B action tuples/endpoints to one model B/b whole action. S1 maps its own roots. Result abstraction preserves equality while retaining per-original IDs. Ordinary request/reply admissions lack composition decision-order rows; the projection gives a permissible causal linearization after actual source authorization and before actual selection, not an asserted wall-clock transport order. Durable reply admission expands into receive-result and record with common evidence references.

Process-cut final retained service subsequences may independently audit, but `Scope` and `Reasons` explicitly mark whole-Store chronological crash recovery unsupported. No paired per-agent crash expansion has been established and no model crash is silently inserted. The cut phases and their raw/contact/owner evidence remain present. Separate-grant-plus-revocation is not a configuration in the unchanged model. Unknown result prefixes/repeated exposures cannot be recast as atomic Apply plus receipt. A serial/serial retained safe unpaid prefix is not a proof of runtime progress; its original runtime deadlock classification remains a separately supplied claim and the actual program waiting obligations remain in raw source/history evidence.

## RED evidence and corrections retained

- Initial API/test compile RED and subsequent concrete implementation failures are retained; they are not runtime semantic failures.
- Actual RED tests found missing strict raw table/column checks, duplicate original-root rows, absent/forged terminal rows and omitted terminal routes. These checks were added; no adverse test was removed or weakened.
- The first closed-schema implementation rejected sparse hostile Tables-only exports at table shape. `sparse-red.log` reproduces that apparatus error; the corrected transport reaches all five substantive hostile edges.
- Earlier expected CLI runs exited1 because reverse service order was incorrectly attempted as a forward model edge and selected-grant denials were mislabeled as the delayed-selection discrepancy. Those outputs remain in development/pre-* directories. Corrected outputs preserve explicit unsupported domains and only the genuine named mismatch.
- Parent P2 finding: deleting a current subjects row left the full application/result history unchanged and was falsely accepted. Parent candidate tar/raw/verdict/commands are preserved in `parent-missing-subject/`; `missing-subject-red.log` reproduces it. The checker now requires current subject cardinality to equal original principals, while existing unique-key and exact run/revision/owner/generation validation establishes set equality. `missing-subject-green.log` records the focused correction; final qualification includes the regression.
- Parent P2 finding: a selected receipt could precede its retained external-result fact. Parent candidate/raw/verdict/command bytes are preserved in `parent-selection-before-receipt/`; `observation-prefix-red.log` also reproduces actual false acceptance for both receipt and lifecycle decisions. The checker now requires causal-prefix availability for receipt/adapter, lifecycle, ordinary message and terminal selections. Four complete retained input controls, original/mutated hashes and exact changed rows are in `final/causal-inputs/`. The terminal control moves selection before its source while preserving source/freeze/outcome order. `final/parent-controls.json` records the final CLI exit1 and exact edge for all four controls and both original parent inputs; receipt and parent receipt fail at order18, lifecycle at7, message at11 and terminal at37. Focused positive controls remain accepted.
- Four deliberate checker-source mutants are run in separate `/tmp` copies: removing recursive duplicate-key rejection, ignoring primary attempt digest, ignoring fresh gate policy, and skipping causal-prefix checking. All are killed by assertion failures, with changed source hashes, exact commands/logs and exit1 retained in `final/checker-mutants.json`. Their complete source copies and logs are under `/tmp/alan-phase3b3-task3-checker-mutants-final/` and copied into `final/checker-mutants/` for packaging. The final source is unchanged by these experiments.

## Qualification and CLI behavior

Every Go command uses local pinned toolchain, GOPROXY=off, GOSUMDB=off, and task-specific /tmp build/Staticcheck caches. Exact final argv/environment/exit/timing is in `final/commands.json`. Commands include:

```sh
ALAN_TASK3_RAW=/tmp/alan-phase3b3-runtime-frozen/normal ALAN_TASK3_PROGRESS=1 go test ./research/delegationcorrespondence/... -count=1 -v
ALAN_TASK3_RAW=/tmp/alan-phase3b3-runtime-frozen/race ALAN_TASK3_PROGRESS=1 go test -race ./research/delegationcorrespondence/... -count=1 -v
staticcheck ./research/delegationcorrespondence/...
go run ./research/delegationcorrespondence/cmd/corpus
go run ./research/delegationcorrespondence/cmd/progress
go run ./research/delegationcorrespondence/cmd/mutations research/delegationcorrespondence/testdata/positive.json
go build -o /tmp/alan-phase3b3-task3-evidence/final/check ./research/delegationcorrespondence/cmd/check
```

Normal and race package tests, Staticcheck, model corpus, progress query, raw mutation generator and checker build all exit0. Normal/race tests explicitly enable both external raw corpus and progress query, with 41 passing test/subtest events and no skipped tests in each run. The final causal-control refinement changes only test construction; the additional `normal-tests-causal-controls`, `race-tests-causal-controls` and `staticcheck-causal-controls` command entries qualify the final test bytes.

The built checker is invoked for each normal/race root both without expectations (exit1 required) and with complete explicit `expectations.json` (exit0 required). Exit0 means declared expected findings matched, not that an invalid raw history became valid or a model mismatch became agreement. Exit2 is usage/malformed outer input/unreadable/digest/apparatus error. Relocation tests copy the complete corpus to a fresh directory, preserve absolute case/index bytes, and explicitly map original prefix to extracted root. Model expectation labels never supply missing runtime facts.

A nonfatal Go stat-cache write permission warning was observed in `build-check.stderr` (131 bytes, build exit0): `go: writing stat cache: mkdir /Users/jacob/go/pkg/mod/cache/download/github.com/!jake!f!a!u/alan-research: operation not permitted`. It is retained, not hidden by rerunning solely to suppress output. Parent final CLI builds use `-buildvcs=false` in the authorized environment. No blanket pristine-output claim is made.

## Remaining ownership and limits

Parent owns independent raw-policy/projection/progress source reviews, full module and frozen old-graph regressions, delivery source commit, final archive extraction/hash check, manuscript synchronization and build. This worker touched no old models, runtime sources or manuscript files and made no commit. Parent-owned working-tree documentation/manuscript changes were observed and left untouched.

The checker is a bounded independent evidence interpreter, not a proof of arbitrary ALAN programs, complete hostile-history detection, cryptographic provenance, exact external exposure attribution or distributed recovery. A policy-consistent fabricated unsigned history can remain internally coherent. Fixed adapters and endpoint deduplication remain declared assumptions. Format14 and feature cross-products are outside this package's qualified domain. Actual source/runtime/compiler/general congruence obligations must not be inferred from agreement on this corpus.


## Fix round 1 — independent raw-review REJECT corrections

The independent raw-policy review rejected the prior candidate for three reproduced false acceptances (R1–R3) and requested a mutation-label/coverage correction plus removal of discarded reread errors. That rejected candidate and its evidence remain unchanged. This round does not reopen the independently approved model projection/progress analysis or alter the old model/runtime. Parent independent re-review is still required; these are corrections submitted for review, not a claim of approval.

Round evidence root: `/tmp/alan-phase3b3-task3-evidence/fix-round1/`. `review-originals/` copies the exact review inputs, programs and rejected verdicts without modifying `/tmp/alan-phase3b3-task3-raw-review`. `rejected-source.json` preserves manifest SHA256 `9ca9c230e7ebbe3185474fc5a52db07fda36af0a764f006733032bbe9d5477c6`. `red-tests.go.txt` is the pre-fix regression source; `red.log` records its real assertion failures before implementation. The current source manifest is `source.json`, SHA256 `036e16e86dd06c63ad98342c98676409a5b0d8316bf4612c0e3794fcd70f00b3`, with 23 package files. Six package paths differ from the rejected source: `custody.go`, `external.go`, `files.go`, `mutations.go`, `README.md`, and new `review_fixes_test.go`. Parent authorized the package README synchronization; no parent-owned docs or manuscript were changed.

### R1: accepted route permissions

The RED regression removed each of the five accepted message routes in turn from both original/current permission mirrors while preserving program, grant, application, receipt and selection evidence. The rejected checker accepted every case. It also accepted a local input with only a nonzero-revision route. `validateAdmissions` now independently requires the exact six-field original route for every accepted ordinary message, using the committed intent's source revision. Accepted local inputs require the exact revision-zero input route. The independent source authorization/liveness check remains separate.

Covering tests: `TestAcceptedAdmissionRequiresOriginalRoute` (AB request, BA request, ready, AB reply, BA reply) and `TestAcceptedLocalInputRequiresRevisionZeroRoute`, both in `review_fixes_test.go`. The positive local-input route is accepted; the altered mirrored routes fail `admission_permission`. The original review mutant SHA256 `304ad2640f7664a6916fe4126d317e4ab583531ccf72991295ba1fb90984b4c5` remains preserved and is rerun through the built corrected CLI.

### R2: immutable source and authority across captures

The RED tests supplied individually valid snapshots with an extra original/current external permission, an added retained program, or a consistently changed original/current B owner across deployment/subject/origin rows. The rejected continuity checker returned nil for all three. The correction compares complete immutable metadata, program, subject, permission, deployment, profile, static root/member and run-origin sets. It separately preserves run IDs, program bindings and initial projections. Existing append-only operation/history checks remain intact. Current execution projections/sequence, activation epochs and observation consumption are not incorrectly treated as immutable source rows.

Covering test: `TestImmutableSourceAndAuthorityContinuity` in `review_fixes_test.go`; each changed snapshot remains independently raw-valid, then continuity fails `immutable_source_changed`. The original reviewer initial/final authority-addition pair is rerun through a copied probe under `probes/`; neither input is discarded or diverted to unsupported model projection.

### R3: owner Open, boundary and renewal joins

The RED test kept the original wire epoch2, changed the rehashed second gate and corresponding fresh-owner boundary events to epoch2, and left actual fresh-owner Open/post-open/history at epoch3. Raw historical bounds legitimately still pass; the corrected external check rejects `boundary_owner_epoch`. It first checks supplied owner Open against the actual complete post-open run set, source/program/revision/projection and namespace, then binds each scoped boundary source RunID/epoch to that owner. A nonzero event PID must match the owner; blank passive-event process fields are not invented. `Owners` retains actual Open/post-open/prior paths and hashes, supplied PID and run state; `OwnerBindings` records the file/event/operation/ordinal and owner context used for the join. These are contextual unsigned evidence checks, not authenticity claims or wire gate attribution.

Captured renewal requires exactly one epoch increment for an open run and no epoch increment for a terminal run, while preserving its sequence/projection and immutable source. `TestOwnerRenewalPreservesTerminalEpoch` covers false non-renewal and false terminal renewal with internally agreeing Open/post-open changes. `TestFreshOwnerGateEpochRequiresOpenContext` covers the self-consistent stale gate/event pair and its positive original. `TestUncapturedInitialRenewalRemainsExplicit` covers the known missing initial capture and rejects a missing actual fresh-owner post-open snapshot.

The first full round attempt correctly failed tests after an overly rigid evidence-layout assumption: `generic-unknown` and `applied-unknown-revoked-before-fresh-gate` lack an initial pre-Open snapshot, and ordinary controls capture final execution before reopened inspection without a stopped snapshot. Those failed normal/race logs and commands are retained under `pre-context-layout/`; that exploratory attempt changed source before its later CLI commands and is explicitly not a frozen qualification. Final code follows the actual captures: absent first-owner pre-Open evidence yields `RenewalChecked=false`, empty prior path/hash and an explicit limitation, while Open/post-open/boundary binding remains mandatory. A fresh owner requires the captured stopped predecessor. Standalone ordinary reopened inspection uses its captured final predecessor; process recovery uses stopped. The two missing initial captures do not establish initial renewal, and nothing inserts or proves a whole-Store model crash expansion.

### Mutation identity and verified-byte reuse

The old `altered-recipient` case actually changed `Authority.Use.Root.Run.Subject`; its retained historical output is unchanged, but the current generator correctly calls it `altered-holder`. A separate fifteenth case, `altered-recipient`, changes `lifecycle_results.descriptor.Intent.Payload.claim.Text.Recipient.Subject` from a to b and mirrors that changed request in the retained decision. It leaves the holder/root and external receipt rows unchanged. Its first rejection is `lifecycle_origin`: the changed recipient request disagrees with the actual committed source intent. This is original-source integrity evidence, not a claim that the mutation reached the later recipient-policy decision. Existing authentic refused-recipient controls remain separate policy tests. `SemanticField`, exact primary-key/column coordinates, complete before/after descriptor bytes, original/mutated IDs and input hashes make the distinction inspectable. `TestRecipientMutationChangesRecipient` checks that distinction, preserved results, coordinates and exact rejection edge.

`CheckCorpus` now caches every already-digest-verified JSON/JSONL byte slice and reuses it for projection, external context, continuity, outcomes and source records. Both discarded `os.ReadFile` rereads were removed. Initial read/path/digest failures still propagate as apparatus errors; no new mutable-file or concurrent-filesystem assumption is made. Existing full corpus and relocated corpus tests exercise the cached path.

### Round qualification

The full round command driver is `fix-round1/qualify.py`; final exact argv, environment, expected/actual exits and elapsed seconds are in `commands.json`. Ordinary and race package tests both enable `ALAN_TASK3_RAW` for their respective complete frozen corpus and `ALAN_TASK3_PROGRESS=1`. Targeted package Staticcheck, mutation CLI, a `-buildvcs=false` checker build, both normal/race unqualified corpus checks, both explicit-expectation checks and all three copied reviewer probes are included. The copied probes write only below `fix-round1/probes/`; original review evidence is untouched. Actual final results and evidence-manifest identities are recorded below after completion.


Final round result: all 12 command exits match their declared expectations. Ordinary and race suites each report **58 passing test/subtest events, zero skips, zero failures**. Targeted Staticcheck exits0. The mutation command emits 15 invalid retained-input controls, including distinct holder and actual recipient mutations. Each complete normal/race corpus again has 48 cases, 117 captured raw phases, 1,761 verified files, 43 raw-valid final histories and five semantic hostile rejections. There are no continuity failures, no external failures among raw-valid cases and no projection apparatus errors. The sole named `immediate_selection_narrows_model_admission` mismatch remains. Unqualified checks exit1; explicit expected-outcome checks exit0.

The exact original reviewer route input now fails `admission_permission` (CLI exit1). The copied continuity probe preserves `InitialValid=true` and `FinalValid=true` and now reports `immutable_source_changed` for permissions. The copied epoch probe preserves `RawValid=true` and actual fresh-owner epoch3, and now reports `ExternalValid=false` / `boundary_owner_epoch`. Their probe processes exit0 because they successfully report checker results; that is not semantic acceptance.

The holder input SHA256 is `d2443deba2b444d1ad4af30950aaef62f8b4c5414a0e0415274f1b8ef4ecdc12`, failing `first_authority_policy` at order16. The recipient input SHA256 is `20f6dd64dcdc993538e421eedccda115ac3508a9aa4cf093654e3152c30d1752`, failing `lifecycle_origin` at order0; its exact lifecycle descriptor and result-request changes are in `raw-mutations.json`. The qualified checker binary SHA256 is `8f3f5d19223546a20991f105624a70db60959479a255aeb56e3aa961641a176d`. This round uses the parent's authorized `-buildvcs=false`; its build stderr is empty. The earlier 131-byte warning remains in the original evidence and historical report.

`verification-summary.json` records final counts/verdicts/source stability. `tested-source.json` preserves the qualification-start manifest; all Go/module/test/fixture bytes remain unchanged from that manifest. A final README wording correction clarifies that the recipient mutation preserves external receipt rows while changing the claimed lifecycle result's request copy; `source.json` includes that documentation-only correction. The final evidence manifest hashes the round artifacts without replacing the original rejected evidence. Projection/progress/model sources remain unchanged from the rejected candidate; the tests still ran the exhaustive progress opt-in. No commit, subagent, runtime edit or SQLite API open occurred. This round awaits the original raw-policy reviewer's independent re-review.
