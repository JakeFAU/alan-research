import os,pathlib,json,subprocess,time,hashlib
cwd=pathlib.Path('/Users/jacob/dev/personal/alan-research');out=pathlib.Path('/tmp/alan-phase3b3-task3-evidence/final');out.mkdir(exist_ok=True);root=pathlib.Path('/tmp/alan-phase3b3-runtime-frozen/normal');entries=json.loads((root/'case-index.json').read_text());invalid={'mutation-missing-grant','mutation-forged-grant-origin','mutation-effect-use-result','mutation-gate-attempt-digest','mutation-result-link'}
expect={x['Name']:{'RawValid':x['Name'] not in invalid,'Mismatch':'immediate_selection_narrows_model_admission' if x['Name']=='control-wrong-prior-selection' else ''}for x in entries};(out/'expectations.json').write_text(json.dumps(expect,indent=2)+'\n')
env=os.environ.copy();env.update(GOTOOLCHAIN='local',GOCACHE='/tmp/alan-phase3b3-task3-build',GOPROXY='off',GOSUMDB='off',STATICCHECK_CACHE='/tmp/alan-phase3b3-task3-staticcheck');commands=json.loads((out/'commands.json').read_text())
def run(name,args,extra={},want=0):
 e=env.copy();e.update(extra);start=time.monotonic()
 with (out/(name+'.json' if name in ['model-corpus','progress','raw-mutations','normal-unqualified','normal-expected','race-unqualified','race-expected'] else name+'.log')).open('wb') as f, (out/(name+'.stderr')).open('wb') as err:p=subprocess.run(args,cwd=cwd,env=e,stdout=f,stderr=err)
 commands.append({'Name':name,'Args':args,'Environment':{k:e[k] for k in ['GOTOOLCHAIN','GOCACHE','GOPROXY','GOSUMDB','STATICCHECK_CACHE']},'ExtraEnvironment':extra,'Exit':p.returncode,'ExpectedExit':want,'ElapsedSeconds':round(time.monotonic()-start,3)})
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,p.returncode,flush=True)
run('normal-tests-causal-controls',['go','test','./research/delegationcorrespondence/...','-count=1','-v'],{'ALAN_TASK3_RAW':str(root),'ALAN_TASK3_PROGRESS':'1'})
run('race-tests-causal-controls',['go','test','-race','./research/delegationcorrespondence/...','-count=1','-v'],{'ALAN_TASK3_RAW':'/tmp/alan-phase3b3-runtime-frozen/race','ALAN_TASK3_PROGRESS':'1'})
run('staticcheck-causal-controls',['staticcheck','./research/delegationcorrespondence/...'])
