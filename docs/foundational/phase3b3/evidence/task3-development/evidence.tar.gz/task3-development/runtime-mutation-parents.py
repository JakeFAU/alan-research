import pathlib,json,hashlib,sys
root=pathlib.Path(sys.argv[1]);prefix=pathlib.Path(sys.argv[2]);index=json.loads((root/'case-index.json').read_text());out=[]
def resolve(original):return root/pathlib.Path(original).relative_to(prefix)
for entry in index:
 d=resolve(entry['Directory']);mp=d/'mutation.json'
 if not mp.exists():continue
 m=json.loads(mp.read_text());original=resolve(m['SourceCase'])/'final/inspect.json';mutated=d/'raw-tables.json';a=json.loads(original.read_text())['Tables'];b=json.loads(mutated.read_text())['Tables'];changes=[]
 for table in sorted(set(a)|set(b)):
  old=[json.dumps(x,sort_keys=True)for x in a.get(table,[])];new=[json.dumps(x,sort_keys=True)for x in b.get(table,[])]
  removed=[json.loads(x)for x in old if x not in new];added=[json.loads(x)for x in new if x not in old]
  if removed or added:changes.append({'Table':table,'OriginalRows':removed,'MutatedRows':added})
 out.append({'Name':entry['Name'],'Mutation':m,'OriginalSnapshot':str(original),'OriginalSHA256':hashlib.sha256(original.read_bytes()).hexdigest(),'MutatedSnapshot':str(mutated),'MutatedSHA256':hashlib.sha256(mutated.read_bytes()).hexdigest(),'ExactRowChanges':changes})
print(json.dumps(out,indent=2))
