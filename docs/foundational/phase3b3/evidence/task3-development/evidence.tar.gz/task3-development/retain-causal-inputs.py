import json,pathlib,hashlib,copy
base=pathlib.Path('/tmp/alan-phase3b3-task3-evidence/final');out=base/'causal-inputs';out.mkdir(exist_ok=True)
source=pathlib.Path('/Users/jacob/dev/personal/alan-research/research/delegationcorrespondence/testdata/positive.json');data=source.read_bytes();raw=json.loads(data);records=[]
for name,prov in [('receipt','resource-receipt'),('lifecycle','runtime-lifecycle'),('message','ordinary-message'),('terminal','runtime-terminal')]:
 x=copy.deepcopy(raw);t=x['Tables'];ob=next(json.loads(r['descriptor']) for r in t['observations'] if json.loads(r['descriptor'])['Provenance']==prov and r['consumed_sequence'] and (name!='message' or json.loads(r['descriptor'])['Obligation']=='grant-ready'))
 h=next(r for r in t['history'] if r['selected_observation']==ob['ID']);facts=[(r,json.loads(r['descriptor']))for r in t['composition_facts']];selected=next((r,f)for r,f in facts if f['Kind']=='execution' and f['Run']['Subject']==h['subject'] and f['Sequence']==h['sequence'])
 if name in ('receipt','lifecycle'): src=next((r,f)for r,f in facts if f['Kind']==('external_result' if name=='receipt' else 'lifecycle') and f['OperationID']==ob['Operation'])
 else:
  a=next(json.loads(r['descriptor'])for r in t['admissions'] if json.loads(r['result'])['ObservationID']==ob['ID'])
  src=next((r,f)for r,f in facts if (name=='message' and f['Kind']=='authorization' and f['OperationID']==a['IntentID'])or(name=='terminal' and f['Kind']=='execution' and f['Run']==a['Source'] and f['Sequence']==a['TerminalSequence']))
 changed=[(r,f)for r,f in facts if src[1]['Order']<=f['Order']<=selected[1]['Order']];before=[copy.deepcopy(r)for r,f in changed];lo,hi=src[1]['Order'],selected[1]['Order']
 for r,f in changed:
  f['Order']=lo if f['Order']==hi else f['Order']+1
  r['decision_order']=f['Order'];r['descriptor']=json.dumps(f,separators=(',',':'),ensure_ascii=False)
 dest=out/(name+'.json');dest.write_text(json.dumps(x,separators=(',',':'),ensure_ascii=False)+'\n')
 records.append({'Name':name,'Input':str(dest),'OriginalSHA256':hashlib.sha256(data).hexdigest(),'MutatedSHA256':hashlib.sha256(dest.read_bytes()).hexdigest(),'ObservationID':ob['ID'],'OriginalRows':before,'MutatedRows':[r for r,f in changed]})
(out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
