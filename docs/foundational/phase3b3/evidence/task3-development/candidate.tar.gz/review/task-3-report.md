# Phase 3B.3 Task 3 — independent raw correspondence checker

Status: implementation complete; final qualification includes both parent P2 corrections and four causal-selection controls. Parent independent source review, frozen whole-module regression, archive packaging and manuscript reconciliation remain parent-owned. No commit, subagent, model/runtime edit or SQLite API open was performed by this worker. Filesystem reads/copies/hash verification of immutable exported bytes are distinct from opening archives through SQLite.

## Question and bounded result

Can independent retained-evidence checking justify the actual request-bound delegation and original result custody in the frozen public runtime fixture, while preserving model mismatches and progress obstructions?

The new research-only package independently checks the actual fixed generation-one two-static-root profile13 corpus. Its raw authority/custody verdict is separate from runtime Run/Replay/Open/Inspect outcomes and from model projection. It checks every supplied captured prefix, including the hostile sparse Tables-only export. No invalid or difficult raw-history case is diverted to an unsupported model verdict as a substitute for raw checking.

The positive generated trace has both originals outstanding and actual BA Delegated authority. Raw ordinary S2 yields a 21-event retained logical service trace accepted by the unchanged model ledger; own-root S1 yields 20 events. This is a bounded trace comparison with explicit action/result abstraction. It is not permission-algebra equivalence, forward refinement, a full process-recovery correspondence, or an all-runtime-state completion theorem.

The genuine delayed-selection witness retains `immediate_selection_narrows_model_admission`: actual valid runtime refusal after BA selection then ready selection, versus unchanged LateGrant allowed delegated authorization. Explicit expectations never relabel that mismatch as agreement. Rejected grants, malformed selectors, reverse service order, separate-grant revocation, repeated exposures, unknown receipt prefixes and unproved shared-process crash expansion are separately unsupported mapping domains.

## Exact source and evidence identity

- Research source base: `31c8af68e818f97a842e790669fbc8f8c98dc8bd`; new files were uncommitted while this worker qualified them. HEAD alone does not identify the new checker.
- Frozen runtime source: `759df6e3d2505f27e1287b2cfeb07bc4290afc0a`.
- Immutable normal raw root: `/tmp/alan-phase3b3-runtime-frozen/normal`.
- Immutable race raw root: `/tmp/alan-phase3b3-runtime-frozen/race`.
- Final exact command records, source hashes and outputs: `/tmp/alan-phase3b3-task3-evidence/final/`.
- Full development RED/failure history: `/tmp/alan-phase3b3-task3-evidence/`, including retained earlier qualification attempts under `pre-sparse`, `pre-terminal-routes`, `pre-policy-edge`, `pre-current-subject`, and `pre-observation-prefix`.
- Committed-in-candidate positive fixture is the actual frozen ordinary S2 raw JSON. SHA256: `e371654a8b8b9def3ab6f29edfd067c7bc418f7c9e58a72da23fed2ff8296d18`.
- Frozen v3 contract SHA256: `f19d9c13f84c17496fabef91cb7575cf52972ff228c0b69e063cdc1c99100e12`.
- Unchanged model SHA256: model.go `11ec7401ade2c4b5b942b70929cc5df8a8f47da4d072a0b5d980b86e19034dbe`; explore.go `3916f87834709dcd7c0d55b2470daf6317fb9ab2ac637a01bcc0723a7eb0e26e`; oracle.go `06bbe53e48084a61b3b16fec8a1f096a4e35e3bb607fc58a678ea2f33f6b01dd`; oracle_corpus.go `5bffdacf8f305cd0e1877ed0142396bf7eb66457cd2828d80212310be79eb49d`.

`source.json` binds all 22 new source/fixture/README files separately from those source bases. Its SHA256 is `9ca9c230e7ebbe3185474fc5a52db07fda36af0a764f006733032bbe9d5477c6`; the qualified checker binary SHA256 is `71ec2d01b3c421550b918dbec06db2e87732010a6eb626cf9649d9465b22e55f`. `commands.json` records exact argv, environment, expected and observed exits and elapsed time. `verification-summary.json` confirms all 14 command exits match expectations, source hashes remain stable and final normal/race test event counts are 41/41 with zero skips. `manifest.json` digests the final evidence files, including complete causal controls and checker-mutant source copies. Final delivery archive/commit identities belong to the parent and must not replace executable/source/input identities.

## New files and callable interfaces

Apart from this task report, only `research/delegationcorrespondence/` repository files were authored by this worker:

- `wire.go`, `schema.go`: own exact-integer DTOs, recursive duplicate-key checks, canonical descriptor handling, closed raw schema/index checks and terminal obligations.
- `check.go`: original deployment/permissions/member roots, ordered fact reconstruction, independent lifecycle/first-effect/fresh-gate policy and serving-root accounting.
- `custody.go`: independent five-instruction slice, causal-prefix observation availability and actual request/result/settlement/reply/selection joins.
- `external.go`: endpoint contact/application reconciliation, declared trusted fixed adapter boundary, ordinal-bearing local boundary evidence, Open/post-open epoch joins and immutable-prefix continuity.
- `corpus.go`, `mutations.go`, `project.go`, `progress.go`: model histories, full retained-input mutations, raw-driven event projection and independent exhaustive progress query.
- `files.go`, `cli.go`, four command packages (`check`, `corpus`, `progress`, `mutations`), focused tests, `README.md`, and exact `testdata/positive.json`.

Public entry points are `CheckRaw([]byte) RawVerdict`, `CheckExternal([]byte,map[string][]byte) ExternalReport`, `CheckContinuity`, `CheckCorpus(root,originalPrefix)`, `ProjectRaw`, `GenerateCorpus`, `RawMutations`, `QueryProgress`, and `RunCheck`. None calls runtime authorization, Replay, a production reducer or SQLite. Model functions are used only by generator/projection/progress, never while evaluating raw authority. Dependency inspection lists only stdlib and the unchanged authorityservice/mutualobligations research packages; no public runtime or database dependency enters this package's dependency graph.

## What the independent checks establish

1. Exact raw input SHA256, canonical original descriptors, primary keys, run/generation/sequence/ordinal agreement, tagged scalar values and complete original/current identity/permission sets. Sparse hostile exports omit known zero-row tables; their absence is interpreted as zero exported rows, never filled from model expectations. Unknown tables/columns remain errors.
2. Original static root membership independently of namespace-derived candidate hashes. Actual committed lifecycle emitter, original complete tuple, source revision, recipient logical run/revision/root, exact original message and future ordinal-zero service locator determine grant/refusal. Grants never insert an A permission.
3. Mirrored facts are reconstructed from source rows and checked in both directions. First effect authority is derived at its original ordered prefix; original source authorization, nested permission witness and resource reservation are distinct. Refusal is sticky and never falls back to an unselected alternative.
4. Fresh primary gates require an original allowed reservation/debit, exact immutable attempt digest, current source state and historical activation bounds, same selected path and contiguous original-local ordinal. Revocation is interpreted at the earlier prefix, so old allowed results survive later revocation while fresh exposure refuses.
5. Original serving-root debit is exactly once. Grant issuance/revoke/gate/reopen do not create or refund a second charge. Terminal rows and exact original permission-derived destination obligations are preserved separately from service payment.
6. The independent finite instruction interpreter checks the real retained source instruction against each actual history reduction. It checks `emit`, `receive`, `branch`, `set`, `end`, literal/reference expressions, selected observations, emitted control metadata and complete successor data. This is a checked fixture slice, not a general reducer/compiler proof.
7. Custody joins authenticate actual original message admission/selection, service operation, retained result, settlement/server selection, result-bearing reply and same-generation caller selection. Equal numerical result values do not substitute originals. Selection also requires retained causal predecessors in the actual composition prefix: message source authorization, lifecycle decision, effect reservation and allowed result fact, or terminal source history. Final observation existence is insufficient. No global admission timestamp is invented; local inputs remain external input assumptions without a source composition fact. Both consumed originals, rather than terminal/ready/lifecycle markers, determine `Custody.Complete`.
8. Independent endpoint ingress bytes match immutable original wire/prepared request; committed applications and retained receipts/adapter responses agree. Contacts and unique applications remain distinct. The immutable wire's Epoch is original authorization epoch; fresh gate epoch comes from primary records and owner snapshots. Returning ordinal claims use actual local result-boundary evidence, not an invented retained result field.

## Corpus and model/progress outputs

For each frozen normal/race root the final corrected pipeline verified 48 cases, 117 raw captured phases and all 1,761 digested files. It found 43 valid final raw histories and exactly five hostile rejections. Each root preserves the sole named selection-narrowing mismatch and no projection apparatus `Error`. Raw validity is never replaced by unsupported projection.

| Actual hostile history | Independent first failed edge |
| --- | --- |
| Deleted retained grant | `lifecycle_settlement` — settlement names missing original lifecycle result |
| Forged grant source | `lifecycle_origin` |
| External selection substituted with actual result operation | `reservation` — immutable attempt/reservation disagreement |
| Rehashed primary gate with altered attempt digest | `gate_attempt_digest` |
| Receipt key substitution | `result_original` |

The eight model classifications contain 22 new selected/generated cases: four complete value pairs, one completable prefix with explicit suffix, one authority-blocked history, four missing-authority controls, three scope controls, six request/generation controls, one revoked-admission control and two causal-order controls. All unchanged 33-history/four-chain controls are retained in `Prior`. Protocol-valid but explicit-consent-unsafe S3/Cartesian cases remain so labeled; their first policy-unsafe prefix is reported without pretending protocol invalidity.

Fourteen checker-input mutations retain complete mutated JSON, original/mutated hashes, exact changed-cell references, original IDs and first failed edges: missing/forged grant, recipient/root/service/resource/request/generation alterations, reuse/result-as-authority, equal-payload key substitution, gate-before-reservation, stale activation and altered attempt digest. Witness/hash mirrors are recomputed where relevant so many failures reach policy instead of merely checksum mismatch. Exact original and mutated runtime-negative snapshot/row bytes are additionally retained in `runtime-mutation-parents-normal.json` and `runtime-mutation-parents-race.json`, resolving actual SourceCase references explicitly; deleted-grant original bytes are taken from that original raw export, not reconstructed from the desired claim.

The independent new progress query uses unchanged Initial/Successors, every reachable state/arc, safe reverse BFS and an audited actual completion suffix:

| Frozen configuration | States / arcs | Safe-completable | Exact-predicate mismatches | Longest shortest suffix |
| --- | ---: | ---: | ---: | ---: |
| S2/LateGrant | 111,065 / 840,616 | 107,213 | 0 | 23 |
| S2/Revocable | 220,564 / 1,740,832 | 193,681 | 0 | 22 |

LateGrant exact condition is no permanent BA first refusal (all reachable states are safe). Its 3,852 excluded states split into 1,926 without and 1,926 with a retained late grant. The set is not forward invariant: early first refusal can leave it. Revocable's exact condition checks both originals: no first refusal and, if revoked, already-applied or a surviving permit. The weaker no-BA-refusal condition has 22,887 noncompletable states. Unconditional completion and that weaker revocable condition are retained adverse controls. These are existential bounded graph facts, not fairness or runtime scheduling theorems. The old sixteen graph results remain untouched; this worker did not claim the new queries replace their full old export/audit regressions.

## Projection boundaries and retained mismatch

The sole named mismatch is the actual wrong-prior-selection witness. The raw checker finds a genuine previously selected BA request, exact accepted grant, no revocation and immediate predecessor ready selection; runtime refuses `authority_request_not_admitted`. The generated model witness allows Delegated authorization. Both originals remain unpaid. Quiescence/open state and service payment are separate outputs.

Malformed selected grants, despite a legitimate different grant or own alternative, are unsupported selector controls rather than variants of that named mismatch. The reverse-service result-laundering fixture genuinely serves AB first; its AB Apply is outside the frozen A-servicing/B-serial policy. The checker preserves its actual result provenance/refusal without inventing a model edge.

Nonrevoking final S2 maps two actual B action tuples/endpoints to one model B/b whole action. S1 maps its own roots. Result abstraction preserves equality while retaining per-original IDs. Ordinary request/reply admissions lack composition decision-order rows; the projection gives a permissible causal linearization after actual source authorization and before actual selection, not an asserted wall-clock transport order. Durable reply admission expands into receive-result and record with common evidence references.

Process-cut final retained service subsequences may independently audit, but `Scope` and `Reasons` explicitly mark whole-Store chronological crash recovery unsupported. No paired per-agent crash expansion has been established and no model crash is silently inserted. The cut phases and their raw/contact/owner evidence remain present. Separate-grant-plus-revocation is not a configuration in the unchanged model. Unknown result prefixes/repeated exposures cannot be recast as atomic Apply plus receipt. A serial/serial retained safe unpaid prefix is not a proof of runtime progress; its original runtime deadlock classification remains a separately supplied claim and the actual program waiting obligations remain in raw source/history evidence.

## RED evidence and corrections retained

- Initial API/test compile RED and subsequent concrete implementation failures are retained; they are not runtime semantic failures.
- Actual RED tests found missing strict raw table/column checks, duplicate original-root rows, absent/forged terminal rows and omitted terminal routes. These checks were added; no adverse test was removed or weakened.
- The first closed-schema implementation rejected sparse hostile Tables-only exports at table shape. `sparse-red.log` reproduces that apparatus error; the corrected transport reaches all five substantive hostile edges.
- Earlier expected CLI runs exited1 because reverse service order was incorrectly attempted as a forward model edge and selected-grant denials were mislabeled as the delayed-selection discrepancy. Those outputs remain in development/pre-* directories. Corrected outputs preserve explicit unsupported domains and only the genuine named mismatch.
- Parent P2 finding: deleting a current subjects row left the full application/result history unchanged and was falsely accepted. Parent candidate tar/raw/verdict/commands are preserved in `parent-missing-subject/`; `missing-subject-red.log` reproduces it. The checker now requires current subject cardinality to equal original principals, while existing unique-key and exact run/revision/owner/generation validation establishes set equality. `missing-subject-green.log` records the focused correction; final qualification includes the regression.
- Parent P2 finding: a selected receipt could precede its retained external-result fact. Parent candidate/raw/verdict/command bytes are preserved in `parent-selection-before-receipt/`; `observation-prefix-red.log` also reproduces actual false acceptance for both receipt and lifecycle decisions. The checker now requires causal-prefix availability for receipt/adapter, lifecycle, ordinary message and terminal selections. Four complete retained input controls, original/mutated hashes and exact changed rows are in `final/causal-inputs/`. The terminal control moves selection before its source while preserving source/freeze/outcome order. `final/parent-controls.json` records the final CLI exit1 and exact edge for all four controls and both original parent inputs; receipt and parent receipt fail at order18, lifecycle at7, message at11 and terminal at37. Focused positive controls remain accepted.
- Four deliberate checker-source mutants are run in separate `/tmp` copies: removing recursive duplicate-key rejection, ignoring primary attempt digest, ignoring fresh gate policy, and skipping causal-prefix checking. All are killed by assertion failures, with changed source hashes, exact commands/logs and exit1 retained in `final/checker-mutants.json`. Their complete source copies and logs are under `/tmp/alan-phase3b3-task3-checker-mutants-final/` and copied into `final/checker-mutants/` for packaging. The final source is unchanged by these experiments.

## Qualification and CLI behavior

Every Go command uses local pinned toolchain, GOPROXY=off, GOSUMDB=off, and task-specific /tmp build/Staticcheck caches. Exact final argv/environment/exit/timing is in `final/commands.json`. Commands include:

```sh
ALAN_TASK3_RAW=/tmp/alan-phase3b3-runtime-frozen/normal ALAN_TASK3_PROGRESS=1 go test ./research/delegationcorrespondence/... -count=1 -v
ALAN_TASK3_RAW=/tmp/alan-phase3b3-runtime-frozen/race ALAN_TASK3_PROGRESS=1 go test -race ./research/delegationcorrespondence/... -count=1 -v
staticcheck ./research/delegationcorrespondence/...
go run ./research/delegationcorrespondence/cmd/corpus
go run ./research/delegationcorrespondence/cmd/progress
go run ./research/delegationcorrespondence/cmd/mutations research/delegationcorrespondence/testdata/positive.json
go build -o /tmp/alan-phase3b3-task3-evidence/final/check ./research/delegationcorrespondence/cmd/check
```

Normal and race package tests, Staticcheck, model corpus, progress query, raw mutation generator and checker build all exit0. Normal/race tests explicitly enable both external raw corpus and progress query, with 41 passing test/subtest events and no skipped tests in each run. The final causal-control refinement changes only test construction; the additional `normal-tests-causal-controls`, `race-tests-causal-controls` and `staticcheck-causal-controls` command entries qualify the final test bytes.

The built checker is invoked for each normal/race root both without expectations (exit1 required) and with complete explicit `expectations.json` (exit0 required). Exit0 means declared expected findings matched, not that an invalid raw history became valid or a model mismatch became agreement. Exit2 is usage/malformed outer input/unreadable/digest/apparatus error. Relocation tests copy the complete corpus to a fresh directory, preserve absolute case/index bytes, and explicitly map original prefix to extracted root. Model expectation labels never supply missing runtime facts.

A nonfatal Go stat-cache write permission warning was observed in `build-check.stderr` (131 bytes, build exit0): `go: writing stat cache: mkdir /Users/jacob/go/pkg/mod/cache/download/github.com/!jake!f!a!u/alan-research: operation not permitted`. It is retained, not hidden by rerunning solely to suppress output. Parent final CLI builds use `-buildvcs=false` in the authorized environment. No blanket pristine-output claim is made.

## Remaining ownership and limits

Parent owns independent raw-policy/projection/progress source reviews, full module and frozen old-graph regressions, delivery source commit, final archive extraction/hash check, manuscript synchronization and build. This worker touched no old models, runtime sources or manuscript files and made no commit. Parent-owned working-tree documentation/manuscript changes were observed and left untouched.

The checker is a bounded independent evidence interpreter, not a proof of arbitrary ALAN programs, complete hostile-history detection, cryptographic provenance, exact external exposure attribution or distributed recovery. A policy-consistent fabricated unsigned history can remain internally coherent. Fixed adapters and endpoint deduplication remain declared assumptions. Format14 and feature cross-products are outside this package's qualified domain. Actual source/runtime/compiler/general congruence obligations must not be inferred from agreement on this corpus.
