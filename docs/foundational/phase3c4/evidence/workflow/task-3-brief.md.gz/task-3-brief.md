### Task 3: Qualification, manuscript reconciliation and requested corrections

**Files:**
- Create `docs/foundational/phase3c4/04-results.md`, `05-qualification.md`, `evidence/qualification/`, `evidence/manuscript/` and an artifact/source/alignment verifier.
- Modify `docs/foundational/phase3/README.md`, `paper/alan-dissertation.md`, `paper/alan-dissertation.tex`, `paper/references.bib` only as warranted, and rebuild `paper/alan-dissertation.pdf`.

**Interfaces:**
- Consumes accepted Task 1/2 records and controller handoff `/tmp/alan-phase3c4/task3-handoff.md`; baseline `/tmp/alan-phase3c4/baseline-inputs.json` has 683 tracked inputs already matched to current bytes and actual merged Git blobs. Fresh root checks will be captured under `/tmp/alan-phase3c4/qualification/` after Task 1 source freezes.
- Produces scoped results, qualification and synchronized changed manuscript content/PDF; reviewer/delivery records remain controller-owned.

- [ ] Check new claims against owning source/evidence: derivative unions insufficient, profile equality sufficient for contextual nonblocking and closed only under the declared product, generic strictness, and nonblocking versus inevitable completion. Distinguish new abstract evidence from historical concrete captures and unestablished full-agent/runtime behavior.
- [ ] Archive exact controller build/module/package checks. Recheck all 683 baseline inputs and newly accepted Go/checker/source identities, including pinned predecessor bindings. Compare fresh package roster with actual merged prior roster, not a guessed full-suite count. Attribute historical tests/lint accurately; no fresh whole-root/global-clean claim.
- [ ] Write results/qualification with actual measured counts, retained RED/hostile evidence, source identity and limitations. Check bibliography implications against controller's inspected primary-literature note; no invented citation or stronger borrowed theorem claim.
- [ ] Read/apply PDF skill and coordinate its one-time operation marker with controller before source authoring. Align new section and changed Abstract/Conclusion in Markdown and LaTeX. Correct the eleven-form count and the overstatement in Markdown 3.4; inspect equivalent condensed TeX locations and include concise aligned clarification. Keep historical theorem numbering/open status and disclose remaining inherited format differences.
- [ ] Build baseline/current PDF with cached tooling, extract text, compare pages/warnings and visually inspect all changed pages plus relevant continuations. Record hashes, commands/exits and scoped visual coverage; preserve any initial failures/repairs. No unrelated global normalization.
- [ ] Execute the deterministic source/artifact/alignment verifier; check new local links, corrected count and congruence wording, exact input hashes and actual evidence counts. Inspect complete task diff, commit only Task 3, and report remaining obligations and review inputs.
