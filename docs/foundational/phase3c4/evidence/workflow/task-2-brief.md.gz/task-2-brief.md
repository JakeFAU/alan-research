### Task 2: Independent profile, product and witness audit

**Files:**
- Create `docs/foundational/phase3c4/tools/audit.py`, `test_audit.py`, `03-independent-audit.md` and `evidence/task2/`.

**Interfaces:**
- Consumes frozen contract/schema and Task 1 exact export, not Go guards or verdicts.
- May import unchanged `docs/foundational/phase3c3/tools/audit.py` constructors with explicit attribution and source hashes for it and its Python dependencies. New profile/language/reachability/witness logic is independent of Go; old product/outcome fields are not an oracle.
- Produces `python3 docs/foundational/phase3c4/tools/audit.py PATH`, accepting exact plain JSON/gzip. Valid complete evidence exits 0; malformed/false evidence exits nonzero with a specific reason. Produces source/archive manifests, exact accepted/rejected CLI inputs and command records.

- [ ] Read contract/schema before implementation. Reconstruct all inherited/new descriptors from written definitions and source-bound Python constructors; check pinned predecessor compressed/raw bytes and source manifest. Implement strict types/keys, duplicate detection and finite schema normalization without bool/int equivalence.
- [ ] Independently reconstruct all cross-state language decisions, complete profile subset graphs, shortest mismatch prefixes and every unmatched-state separator. Reconstruct all 2,772 product graphs, every CanComplete/nonblocking label and contextual substitution row. Verify true and false contexts without treating a mismatch as a necessary contextual separator.
- [ ] Independently validate each negative path, actual loop prefix/cycle/escape and generic strictness example. Verify cycle closure, unpaid debt, marks and complete escape. No post-capture editing, no new physical-history claim.
- [ ] Write positive and hostile tests for all Review Focus items and contract attack categories. Include repaired-count/missing-non-tree-edge input, union-for-profile forgery, missing coverage/separator, bad shortest prefix, dead/unreachable confusion, forged marks/tau, external veto, identity/root mismatch, invented nonblocking and invalid lasso/escape. Retain JSON duplicate-key/nonfinite/type controls. Preserve every initially accepted attack before repair.
- [ ] Capture a third fresh producer export and compare exact bytes/source identities. Run `python3 -m unittest discover -s docs/foundational/phase3c4/tools -p 'test_*.py' -v`, valid plain/gzip audit and every exact hostile CLI input. Archive argv/environment/output/exits and hash all inputs/checker dependencies. Do not replace CLI checks by test-only assertions.
- [ ] Report independent versus reused semantics, actual counts, falsifications and limits. Inspect full task diff, commit only Task 2, and provide the task report for review/qualification.

