# Phase 3C.4 reconnaissance: residual-language profiles

Prepared as a read-only design investigation on 2026-11-14. No repository files, Git state, runtime code or historical evidence were changed. The controller supplied the merged base identity `c369e25c8db268d418ab7c11573d46dbc1d9425f`; this reconnaissance did not independently perform Git verification. The only new artifact is this proposal.

## Recommendation

Use equality of trace-indexed **sets of residual marked languages** as a sufficient continuation-monitor interface for every-reachable-state existential completion. Keep the exact Phase 3C.3 synchronization boundary and the unchanged whole K. Add the two proposed all-marked release-first variants for duplicate residual states and an escapable private cycle. Retain the doomed monitor as the negative control. Do not add antichain reduction, full-agent factoring, runtime captures, priorities, hiding or a general conflict-equivalence decision procedure.

The research question is: under the existing finite synchronized-product rules, what interface preserves `for every reachable state, there exists a finite legal completion suffix` after replacing M? The proposed result is a conditional source argument for that finite automata semantics, supplemented by exact finite decisions and independent product reconstruction. It is not an inevitable-completion theorem.

## Owning sources and inherited boundary

- [Phase 3C.3 argument, premises](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/docs/foundational/phase3c3/01-argument.md:12) fixes the shared alphabet, exact immutable signatures, disjoint private state, independent tau moves, synchronized visible actions and conjunctive marks. Its [intersection proof](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/docs/foundational/phase3c3/01-argument.md:29) already provides the residual-language fact needed below.
- [The product implementation](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/research/componentinterfaces/product.go:41) synchronizes visible actions and advances exactly one factor on tau. It classifies all reachable states by reverse reachability and sets `Nonblocking` when every node can complete at line 131.
- [The language implementation](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/research/componentinterfaces/language.go:29) supplies epsilon closure, closed-subset advance and exact language comparison. The complete subset-pair BFS begins at line 75; it retains every alphabet arc after discovering a separator.
- [Role validation](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/research/componentinterfaces/automaton.go:51) restricts M to reserve/apply AB and commit BC, and D to commit AB and apply BC. Every externally owned event must remain a private-state self-loop. Exact signature checking occurs at line 104.
- [The frozen five monitors](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/research/componentinterfaces/fixtures.go:9) have all states marked. [The 324 controllers](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/research/componentinterfaces/fixtures.go:61) retain all mark masks and transition choices.
- [The plant adapter](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/research/componentinterfaces/plant.go:14) still delegates to unchanged `capacitycomposition` semantics. K retains all agent service guards, bindings, stage and Q transitions. Replacing M does not replace B.
- [The doomed residual argument](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/docs/foundational/phase3c3/01-argument.md:143) already demonstrates equal initial marked languages with a reachable noncompletable product state. [Concrete projection/lifting limits](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/docs/foundational/phase3c3/01-argument.md:106) remain inherited premises rather than newly qualified behavior.
- [The manuscript's Theorem 4.8](/Users/jacob/.codex/worktrees/phase3b4-research/alan-research/paper/alan-dissertation.md:500) remains an open general claim. A congruence for the finite synchronized automata below does not discharge its ALAN hypotheses.

## Mathematical target and proof

Fix a finite common visible alphabet Sigma and the inherited exact signature. Write `q =>w q'` for a finite path whose visible projection is w, allowing finite leading, intervening and trailing tau segments. For a pointed finite marked automaton X define:

```
R_X(w) = { q | initial_X =>w q }
L_X(q) = { v | some marked q' satisfies q =>v q' }
P_X(w) = { L_X(q) | q in R_X(w) }
```

The braces in P denote a set of languages, not a multiset of state names. Equal languages contributed by distinct states count once. The empty profile `{}` means that w has no execution. The profile `{empty_language}` means there is an execution ending in a state with no completion suffix; these must remain different.

**Reachability factorization.** Under the inherited rules,

```
R_(X || Y)(w) = R_X(w) x R_Y(w).
```

For the forward direction, project a product path. For the reverse direction, choose any finite X and Y paths with visible word w. Split each around the matching visible letters and independently interleave the finite private segments before synchronizing each letter. This reaches the selected pair. The reasoning covers epsilon and arbitrary finite nondeterministic choices. It fails if private steps read shared state, if the synchronization scheduler imposes an additional joint guard, or if priorities preempt a local witness.

**Residual completion.** The existing finite-path intersection proof can start at arbitrary states, so

```
L_(X || Y)((x,y)) = L_X(x) intersect L_Y(y).
```

Together these give the profile composition identity

```
P_(X || Y)(w) = { L intersect H | L in P_X(w), H in P_Y(w) }.
```

**Nonblocking characterization.** A product is nonblocking exactly when

```
for every w in Sigma*, every L in P_X(w), every H in P_Y(w):
    L intersect H is nonempty.
```

Every reachable pair belongs to the Cartesian reach set of its finite visible history. Its completion language is the indicated intersection. Quantification is universal over reachable states but existential over a finite completion suffix from each state. A word unrealizable in either factor contributes no reachable product state and hence imposes no condition.

**Sufficient substitution and congruence.** If `P_M(w)=P_N(w)` for every w, then for every compatible finite X,

```
P_(X || M)(w) = P_(X || N)(w) for every w,
NB(X || M) iff NB(X || N).
```

Take X to be K or K||D. This is stronger than merely equality of the final nonblocking booleans: profile equality itself is closed under this product, and induction permits further compatible finite factors. Keep the term congruence qualified by this explicit synchronized-automata grammar. It is not a congruence result for arbitrary ALAN programs, priorities, action hiding, changing authority or shared private state.

The guarantee does not provide a node bijection, equal state counts, equal numbers of CanComplete states, or a bisimulation matching each individual step. Duplicate residual states can match one state on the other side. It also does not preserve immediate markedness, refusals, divergence, fairness, inevitability or exact cost. It preserves the stated completion-language profiles and the derived nonblocking property.

**Why union profiles cannot fix Phase 3C.3.** For every w,

```
union P_X(w) = { v | wv in Lm(X) } = w^-1 Lm(X).
```

This follows by splitting an accepting path after w, or concatenating a weak prefix with a weak marked suffix. Therefore equality of the unions after every prefix is exactly ordinary initial marked-language equality, not an intermediate strengthening. The existing doomed witness falsifies its proposed nonblocking implication without needing another runtime experiment.

## Exact finite decision and reviewable certificates

The smallest implementation does not need canonical minimal DFAs or a global language-class numbering scheme.

For each monitor pair M,N:

1. For every state pair `(m,n)`, decide `L_M(m)=L_N(n)` by exact epsilon-NFA language comparison, using m/n as pointed initial states. Retain the complete subset-pair graph and shortest acceptance separator for each unequal residual pair. The original automata must not be mutated by changing Initial in shared storage.
2. Traverse the complete reachable pairs `(U,V)` of epsilon-closed subsets from the original initial closures, advancing both subsets on each of the eight visible labels. This is the same finite determinization graph used for ordinary language comparison.
3. At each pair, test bidirectional coverage under the residual equality relation:

   ```
   every m in U has some n in V with equal residual language;
   every n in V has some m in U with equal residual language.
   ```

   This tests equality of sets of residual languages without requiring state identity or multiplicity equality. Empty sets are handled by the quantifiers; `{}` cannot match a reachable state whose language is empty.
4. The profiles are equal iff coverage holds at every reachable subset pair. BFS supplies a shortest visible prefix witnessing a profile mismatch. Retain every subset pair and every label arc, even on inequality.

For a mismatch certificate, report the prefix w, an unmatched reached state on one side, and the exact residual-language comparisons against **each** opposite reached state. Those comparisons may need different suffix separators. A single suffix need not distinguish the unmatched residual from the union of all opposite residuals. In the doomed example the two unions are equal. Do not label a profile-distinguishing prefix as a language-distinguishing word.

This is an exact finite decision, potentially exponential because determinization can produce exponentially many subsets. No performance improvement or practical minimality follows. Source-level correctness is proved by induction on visible word length, with complete finite certificates independently reconstructed.

The independently generated full product graphs and their reverse CanComplete labels should remain a separate check of the substitution result. Do not derive both the claimed interface equality and the claimed contextual nonblocking from one producer Boolean. A negative profile decision does not imply the two products differ in any particular K/D context.

## Frozen fixture candidates and attacks

Keep the old five monitors. In the following r is reserve-capacity:AB, a is apply:AB, c is commit:BC; O is the other five labels. All states are marked, and every O label self-loops at every state.

- `release-first-duplicate`: states 0,1,2,3, initial 0; `0-r->1`, `1-a->2`, `1-a->3`; r/a/c self-loop at both 2 and 3. States 2 and 3 contribute the same residual language, testing that profile equality ignores multiplicity.
- `release-first-loop`: states 0,1,2,3, initial 0; `0-r->1`, `1-a->2`, `1-tau->3`, `3-tau->1`, `3-a->2`; r/a/c self-loop at 2. States 1 and 3 have the same marked residual language, and their private cycle can always be escaped through a.

Expected profile-equivalence class: release-first, release-first-tau, release-first-duplicate and release-first-loop. The doomed monitor has the same initial marked language but a smaller residual language O* at its state 3 after r. At that prefix the ordinary release-first residual also allows a followed by arbitrary visible actions.

The shortest standalone monitor-profile mismatch for release-first versus doomed is `[r]`. This word is not itself an executable K prefix: the actual core K witness is `[commit:AB, r]` followed by the doomed private move. Keep those two kinds of witness distinct.

For the loop, retain a complete product prefix to `(W,U,true,false,1)`, the unmarked cycle `1-tau->3-tau->1`, and a genuine finite completion escape. Repeating the cycle gives an infinite noncompletion execution in the finite model, even though every reachable product state still has some completion suffix. A prefix-plus-cycle certificate supports this specific divergence claim; a stalled finite schedule alone would not.

The proposed full roster is the 72 inherited K configurations times seven M, plus core K times all 324 D times seven M: 2,772 product descriptors by construction. There are 21 unordered monitor pairs. Actual graph, residual-certificate and subset counts must be measured. Reuse old grouping evidence with explicit source attribution, or freshly check any new grouping claim; neither is a new full-agent result.

Necessary generic algorithm diagnostics, clearly separate from the role-restricted ALAN roster:

1. Epsilon acceptance through tau from an unmarked state; leading/trailing tau and tau cycles; nondeterministic visible edges; distinctions beyond shallow prefix sampling.
2. Dead residual versus unreachable profile. Let A have a single unmarked state and no edges. Let B have an unmarked initial state and an a-edge to an unmarked dead state, with no marks anywhere. Their initial languages and epsilon profiles agree, but after a, A has `{}` and B has `{empty_language}`. This also shows full profile equality is not necessary for contextual nonblocking: every product of either automaton is blocking because neither can ever contribute a mark. A profile mismatch is not automatically a contextual nonblocking separator, even in an unrestricted tester grammar.
3. Trace indexing cannot be dropped. Use three all-marked states s,p,q, with p allowing only a among r/a/c and q allowing none; all O actions self-loop. Both monitors have s-r->p and s-c->p. Add s-r->q to M and s-c->q to N. They have equal initial languages and the same unindexed set of residual languages, but different profiles after r and c. An unrestricted finite tester requiring r then a separates nonblocking: M can reach q after r and block; N cannot take its q branch in that tester. Explicitly label this tester outside the ALAN K/D roster.
4. Doomed branch retention: deleting the bad branch, merging its residual language with the good branch, or replacing profile comparison with union acceptance must fail a preserved false hypothesis.

Suggested hostile certificate controls: a false residual-equality entry; a forged suffix separator or its acceptance result; omission of a reachable subset, a non-tree subset arc or an unmatched residual; counts adjusted after an omitted product arc; an empty-language state silently converted into an empty reach set; class multiplicities mistaken for semantic distinctions; altered marks; missing tau closure; missing externally owned self-loops; a forged signature/root; and altered loop prefix/cycle/escape endpoints. Retain malformed-schema controls and strict Boolean/integer distinctions if evidence is accepted as JSON.

## Smallest honest reuse boundary

Recommend a new package and new Phase 3C.4 evidence directory. Keep predecessor source and evidence unchanged. The predecessor package exports only Export; changing it or adding new production files there would change the predecessor source manifest. Broad model extraction is unnecessary for this slice.

Consume the **pinned predecessor export** as an immutable fixture source for old automata/configurations. The inspected predecessor artifact manifest records:

```
raw bytes: 25,384,964
raw SHA-256: a073a22fe8ac62e05f2d15b0f5146b19db9606e38ce4619261e7e4108e27269d
gzip bytes: 403,411
gzip SHA-256: 86a9d22f9808a67dd0066b6b77dd2b3c01a2125d10863c6fbe1369097f6624c8
```

Bind both byte representations and verify the exact predecessor source manifest. State the extraction contract and whether this is a fixed trusted fixture input or a supported untrusted parser; do not accidentally advertise a general import API. A fixed exact-hash fixture need not grow into a universal parser. Independently reconstruct the extracted automata and check complete role/signature contracts, especially for the newly authored monitors.

New Go work should freshly construct product graphs from the descriptors and freshly calculate reverse completion labels. Do not treat the imported predecessor Products or Nonblocking fields as the new oracle. New source manifests must include the pinned artifact and actual compiled dependencies, as well as frozen new contract/argument/schema.

Independent Python can import the source-bound unchanged predecessor `plant`, `monitor` and `controller` specification functions, with explicit attribution. Its new residual/profile algorithm must not call Go, and its contextual verdict should use independent full-product reachability. The old Python product reconstruction can be reused if attributed; if modified, keep the old source intact and place the extension in the new packet.

Invoking `componentinterfaces.Export` and decoding it is also semantically sound, but it regenerates the whole predecessor packet, including 1,620 full grouping pairs and eight histories. The inspected historical manifest records roughly 0.6–0.9 seconds for those runs; these are historical measurements, not current benchmarks. Such invocation is useful as an optional pinned-input freshness check, not needed as the new semantic dependency.

New concrete captures add little here. Old history 8 already preserves doomed control through crash/recovery; history 6 preserves the successful private bookkeeping variant. The new interface does not change custody, physical availability or lifting semantics. Reusing or replaying those eight captures must be labeled inherited evidence. No new concrete-product or runtime qualification should be claimed.

## Exploratory checks actually executed

Read AGENTS.md, the Phase 3C.2/3C.3 contracts and arguments, current model source/tests, predecessor schema/results/manifest, old independent Python reconstruction, and the manuscript/roadmap statements relevant to the open boundary. No new Go tests, full roster qualification, PDF build or runtime experiment was run by this subagent.

One read-only Python heredoc ran with `PYTHONDONTWRITEBYTECODE=1` from `/tmp`, importing the unchanged Phase 3C.3 auditor by absolute path. It built the two proposed fixture descriptors in memory, called the old exact comparison for each residual state pair, evaluated bidirectional profile coverage on the old complete subset-pair graphs, and used the old product reconstruction on core K. It exited 0. This is a design probe, not Phase 3C.4 implementation qualification.

The probe found six profile-equal pairs among the four release-first variants and ten initial-language-equal pairs among those four plus doomed. Core K results were:

| Monitor | States | Arcs | Initial CanComplete | Nonblocking |
| --- | ---: | ---: | --- | --- |
| free | 24 | 34 | true | false |
| commit-first | 4 | 3 | false | false |
| release-first | 13 | 16 | true | true |
| release-first-tau | 14 | 17 | true | true |
| release-first-doomed | 14 | 17 | true | false |
| release-first-duplicate | 23 | 30 | true | true |
| release-first-loop | 14 | 19 | true | true |

The loop product's `(W,U,true,false,1)` and `(W,U,true,false,3)` nodes both had `Marked=false`, `CanComplete=true`, an apply:AB escape to `(P,U,false,false,2)`, and a tau edge to the other debt node. No repository files were created by imports.

For literature context, I opened the publisher full text of [Tang and Moor, 2024](https://link.springer.com/article/10.1007/s10626-024-00394-2). The introduction, Definitions 2.2.2, 2.3.1 and 2.3.5 distinguish nonblocking from initial completion, describe synchronization with independent silent moves, and define contextual conflict equivalence in their prioritized semantics. The proposed profile relation is a sufficient relation for the narrower unprioritized product specified here. Do not claim a new general process theorem or instantiate their priority abstraction results. The existing bibliography entry is adequate background; no new citation is required solely by this proposal.

## Limits and later alternatives

Full residual-language profiles deliberately retain more information than contextual nonblocking may need. For a finite profile, a language that strictly contains another profile member is redundant for the universal intersection-nonemptiness condition: hitting the smaller member already hits the larger one. Inclusion-minimal antichains are therefore a plausible future coarsening. Exact inclusion certificates, separate equality semantics and contextual completeness questions would enlarge this task; omit them now.

All conclusions remain conditional on finite automata, exact shared signatures, complete visible synchronization, independent private moves, conjunctive marking, and finite existential suffixes. Keep atomic application/result retention/Q release, recoverability and sufficient other resources inherited and visible. Do not claim full-agent substitution, arbitrary ALAN context closure, necessity, weakest interfaces, full abstraction, deterministic scheduling, inevitability, fairness, runtime refinement, distributed allocation/recovery, split unknown effects, hidden external effects or verification-cost reduction.
