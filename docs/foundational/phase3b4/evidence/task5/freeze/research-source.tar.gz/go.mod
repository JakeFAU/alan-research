module github.com/JakeFAU/alan-research

go 1.27.3

require github.com/mattn/go-sqlite3 v1.14.52
