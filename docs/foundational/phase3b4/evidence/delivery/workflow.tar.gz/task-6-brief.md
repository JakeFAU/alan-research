### Task 6: Reconcile the manuscript and deliver reviewed drafts

**Files:** Research `docs/foundational/phase3b4/08-results.md`, `09-reviews.md`, evidence/review index, `paper/alan-dissertation.md`, `.tex`, rebuilt PDF and `references.bib` only if needed. Runtime public docs/qualification summary. No unrelated source changes.

**Interfaces:** Consume exact executable pair, all reviews and qualification results. Produce bounded final claims, synchronized manuscript/PDF and cross-linked draft PRs. Any correctness source fix returns to affected qualification; documentation-only delivery commits are separate from executable qualification.

- [ ] Answer the packet's six disposition questions explicitly, with proved/proof-sketch/bounded-model/tested/open categories, and recommend only one next question. Preserve old discovery history and remaining whole-Store crash, separate-grant revocation and applied-unrecorded gaps.
- [ ] Synchronize Markdown/LaTeX Abstract, affected body and Conclusion. Check bibliography implications without inventing references. Controller obtains substantive manuscript/whole-change review before final PDF build, then applies PDF skill build and visual inspection to changed pages and continuations. Rebuild after correctness edits.
- [ ] Inspect status/full diff and required checks before final commits. Archive this plan's ledger, briefs, reports and review artifacts without secrets; remove only its scratch workspace when the finishing skill directs.
- [ ] Controller pushes task branches and opens cross-linked draft PRs. State exact bases, executable and delivery commits, versions, scope/invariant/implementation, RED evidence, verification, remaining risks, reviews/rejections/skips and absence of unrelated changes. No automatic merge. Attach both PR artifacts to this chat. If main advanced, qualify an explicit prospective combined tree only when necessary and report its exact identity.
