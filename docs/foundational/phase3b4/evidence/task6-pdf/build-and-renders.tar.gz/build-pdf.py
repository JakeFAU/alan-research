#!/usr/bin/env python3
"""Build reviewed manuscript sources in disposable storage; record exact inputs."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import time

root = pathlib.Path('/Users/jacob/.codex/worktrees/phase3b4-research/alan-research')
out = pathlib.Path('/tmp/alan-phase3b4-pdf-final')
out.mkdir(exist_ok=False)
inputs = ['alan-dissertation.md', 'alan-dissertation.tex', 'references.bib']
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
before = {n: digest(root / 'paper' / n) for n in inputs}
for name in inputs:
    shutil.copy2(root / 'paper' / name, out / name)
argv = ['/opt/homebrew/bin/tectonic', '--only-cached', '--keep-logs', 'alan-dissertation.tex']
start = time.time()
with (out / 'build.stdout.log').open('wb') as log:
    result = subprocess.run(argv, cwd=out, stdout=log, stderr=subprocess.STDOUT, timeout=300)
after = {n: digest(root / 'paper' / n) for n in inputs}
record = {
    'research_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'argv': argv, 'cwd': str(out), 'exit': result.returncode,
    'elapsed_seconds': time.time() - start,
    'source_sha256_before': before, 'source_sha256_after': after,
    'source_unchanged': before == after,
    'build_log_sha256': digest(out / 'build.stdout.log'),
    'previous_pdf_sha256': digest(root / 'paper' / 'alan-dissertation.pdf'),
}
pdf = out / 'alan-dissertation.pdf'
if pdf.exists():
    record['pdf_sha256'] = digest(pdf)
(out / 'build-record.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
if result.returncode or before != after or not pdf.exists():
    raise SystemExit('Build or source-identity check failed; no repository PDF replaced')
