### Task 2: Independently audit the exported graphs and concrete witnesses

**Files:** Create `docs/foundational/phase3c1/tools/{audit.py,test_audit.py}`, `03-independent-audit.md`, `evidence/task2/`; consume frozen Task 1 schema/exports without changing them.

**Interfaces:** Read `00-contract.md` and `02-evidence-schema.md`; independently encode Python successor/guard, compatibility and concrete ledger checks without importing/calling Go reducers. `python3 docs/foundational/phase3c1/tools/audit.py INPUT.json` prints a deterministic audit result and exits nonzero on rejection. Tests run via `python3 -m unittest discover -s docs/foundational/phase3c1/tools -p 'test_*.py'`.

- [ ] Write failing tests for each named hostile control before the validator accepts/rejects it. Validate schema, exact config roster and IDs/bindings, reachability from initial state, the complete expected transition relation including incoming arcs, independently computed Complete/CanComplete, both grouped constructions, dependency claims and all reported counts.
- [ ] Replay all concrete witness events independently from initial state, enforce shared availability and receipt custody, compare reported states/projections and recompute R0/R1 predicates. Verify retry-cycle and assumption classification. Reject forged binding, missing/extra arcs, dropped hidden debt, wrong guard/progress verdict, premature release and repeated application for specific reasons. Genuine records remain unchanged.
- [ ] Run fresh export and audit; retain compressed full graphs, command logs, raw digest manifest and hostile rejection report. Explicitly distinguish abstract exhaustiveness, factored Go checks and selected concrete replay. Any substantiated model defect returns to its owner and must be fixed/re-reviewed; do not compensate in the oracle.
- [ ] Run Python tests and inspect all changes; commit only assigned paths and write a report for independent task review.

